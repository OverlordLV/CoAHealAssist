--[[
CoA Heal Assist v0.9.3
Made by Overlord - Homeless Guild
Standalone Healium-style healer frames for Conquest of Azeroth / Project Ascension.

Design goals:
* Click-to-cast configurable spell buttons for party/raid units.
* Real spell cooldown sweeps + numeric countdowns.
* Buff/HoT tracking per spell slot.
* Visible green HoT/shield/buff icons with remaining duration on each player row (your casts only).
* Long-duration buffs (30 minutes, hours, etc.) are tracked and auto-learned too.
* Curse, Disease, Poison, Magic and Bleed visibility.
* Buff/HoT buttons grey out while their tracked aura is active.
* Cleanse buttons pulse extra-bright red ONLY when that exact visible bar spell can remove an active debuff.
* Automatically reads spell tooltips to fill cleanse types (Curse/Disease/Poison/Magic/Bleed).
* Compact Healium-inspired rows with tight icon-only spell buttons.
* Healium-style frame visibility controls for Party, Me, Pets, Friends, roles and Raid Groups 1-8.
* Displays Blizzard raid target markers (Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull) on unit rows.
* Helpful aura icons cache the exact source spell-button texture at cast time, with API/slot fallbacks.
* Custom bleed spell-ID list for Conquest of Azeroth custom auras.
* Shift + right-click a spell button to clear that slot out of combat.
* Optional spell-button tooltips can be disabled for a completely clean mouseover.
* Mirrors default action-bar proc/free-cast readiness as a steady bright-gold healer spell highlight.
* Independent raid-group/tank panels preserve exact manual positions without snapping.
* The main CoA Heal Assist toolbar attaches to the top of your own raid subgroup frame.
* Reset controls, movable/lockable frame and test mode.

This addon does not bypass protected actions. Secure spell attributes and unit assignments are
only changed out of combat; protected frame visibility/layout is also frozen during combat and queued until combat ends.
--]]

local ADDON_NAME = "CoAHealAssist"
local VERSION = "0.10.1"
local AUTHOR = "Overlord - Homeless Guild"

-- Internal namespace for late UI/control functions.  Keeping these functions
-- off the main Lua chunk local stack avoids the Lua 5.1 200-local limit used
-- by the Conquest of Azeroth client while retaining a single addon package.
CoAHealAssistInternal = CoAHealAssistInternal or {}
CoAHealAssistInternal.procCheckAccumulator = CoAHealAssistInternal.procCheckAccumulator or 0
CoAHealAssistInternal.actionButtonMissUntil = CoAHealAssistInternal.actionButtonMissUntil or {}
CoAHealAssistInternal.buttonChargeRegionCache = CoAHealAssistInternal.buttonChargeRegionCache or setmetatable({}, { __mode = "k" })
CoAHealAssistInternal.buttonProcVisualCache = CoAHealAssistInternal.buttonProcVisualCache or setmetatable({}, { __mode = "k" })
CoAHealAssistInternal.buttonProcBaselineCache = CoAHealAssistInternal.buttonProcBaselineCache or setmetatable({}, { __mode = "k" })
CoAHealAssistInternal.buttonProcBaselineReady = CoAHealAssistInternal.buttonProcBaselineReady or setmetatable({}, { __mode = "k" })
CoAHealAssistInternal.procDiscoverySlot = CoAHealAssistInternal.procDiscoverySlot or 1
CoAHealAssistInternal.chargeDiscoverySlot = CoAHealAssistInternal.chargeDiscoverySlot or 1
CoAHealAssistInternal.spellProcCache = CoAHealAssistInternal.spellProcCache or {}
CoAHealAssistInternal.activeProcAlerts = CoAHealAssistInternal.activeProcAlerts or {}
-- Proc stability state. Ascension activation borders pulse their alpha, so a
-- single low-alpha sample must not instantly clear a proc that is still ready.
CoAHealAssistInternal.procOffSince = CoAHealAssistInternal.procOffSince or {}
CoAHealAssistInternal.procEventActive = CoAHealAssistInternal.procEventActive or {}
CoAHealAssistInternal.procHoldSeconds = CoAHealAssistInternal.procHoldSeconds or 0.65
CoAHealAssistInternal.actionButtonFrameCache = CoAHealAssistInternal.actionButtonFrameCache or {}
CoAHealAssistInternal.manualActionButtonBindings = CoAHealAssistInternal.manualActionButtonBindings or {}
-- Session-long ownership map for custom CoA helpful auras. UnitBuff can lose
-- caster/icon metadata on later refreshes; once we know which configured spell
-- produced an aura, keep that relationship so its small row icon stays stable.
CoAHealAssistInternal.auraSourceSlotByName = CoAHealAssistInternal.auraSourceSlotByName or {}
CoAHealAssistInternal.auraSourceSlotByID = CoAHealAssistInternal.auraSourceSlotByID or {}
CoAHealAssistInternal.auraSourceIconByName = CoAHealAssistInternal.auraSourceIconByName or {}
CoAHealAssistInternal.auraSourceIconByID = CoAHealAssistInternal.auraSourceIconByID or {}
-- Ascension safe mode: the Aug 2026 CoA client can hard-crash inside native
-- CharacterAdvancement code when addons aggressively walk/query the custom
-- spellbook during login or SPELLS_CHANGED. Keep automatic discovery off.
CoAHealAssistInternal.ascensionSafeMode = true
local MAX_SPELL_SLOTS = 14
local MAX_UNIT_ROWS = 48 -- 40 raid rows + up to 8 duplicate Main Tank/Tank rows
local MAX_DISPLAY_BUFFS = 5
local DEFAULT_SPELL_BUTTON_COUNT = 8
local DEFAULT_BUTTON_SIZE = 32
local MIN_BUTTON_SIZE = 22
local MAX_BUTTON_SIZE = 48
local DEFAULT_BUTTON_SPACING = 5
local MIN_BUTTON_SPACING = 0
local MAX_BUTTON_SPACING = 12

-- Healium-inspired compact row layout. Spell buttons are icon-only so the
-- healing bar stays tight even with many configured slots.
local UNIT_PANEL_WIDTH = 144
local AURA_ICON_SIZE = 13
local AURA_ICON_SPACING = 1

local CHA = CreateFrame("Frame", "CoAHealAssistEventFrame")
local main, config, minimapButton, frameOptions
local DumpDebuffs, ListBleeds
local UpdateMinimapButtonPosition, RefreshMinimapButtonVisibility
local RebuildUnits
local ApplyMainPosition
local RefreshSpellUsability
local RefreshFrameOptions, ToggleFrameOptions, CreateFrameOptionsFrame
local rows = {}
local raidGroupPanels = {}
local tankPanel
local petPanel
local assignedPanelKeys = {}
local pendingSecureRefresh = false
-- Snapshot of the exact unit tokens currently bound to secure spell buttons.
-- During combat visual refreshes MUST use this snapshot rather than rebuilding
-- the roster, otherwise the visible row could drift away from its protected unit.
local assignedUnits = {}
local assignedIsTest = false
local assignedCount = 0
local auraLearnAccumulator = 0
local timerAccumulator = 0
local statusAccumulator = 0
local fallbackAuraAccumulator = 0
local cleansePulseAccumulator = 0
local fallbackRowIndex = 1
local activeCleanseAlerts = {}
local cooldownCache = {}
local spellSlotIconCache = {}
local spellManaCache = {}
local spellChargeCache = {}
local manaCheckAccumulator = 0
local chargeCheckAccumulator = 0
local actionButtonChargeCache = {}
local actionChargeKnown = {}
local longAuraHintCache = {}
local lastPlayerMana = -1
local pendingAuraLearns = {}
local ownedAuraClaims = {}
local FindSpellBookSlot
local activeCharacterKey

local DEFAULTS = {
    version = VERSION,
    locked = false,
    shown = true,
    hideSolo = false,
    showGCD = false,
    showSpellTooltips = true,
    showProcGlow = true,
    showBuffIcons = true,
    showShieldOverlay = true,
    useBackground = true,
    backgroundAlpha = 0.22,
    scale = 0.90,
    point = "CENTER",
    relativePoint = "CENTER",
    x = 0,
    y = 20,
    testMode = false,
    spellButtonCount = DEFAULT_SPELL_BUTTON_COUNT,
    buttonSize = DEFAULT_BUTTON_SIZE,
    buttonSpacing = DEFAULT_BUTTON_SPACING,
    minimap = { hide = false, angle = 225 },
    frames = {
        party = true,
        me = true,
        pets = false,
        friends = false,
        tanks = false,
        healers = false,
        damagers = false,
        raidGroups = { true, true, true, true, true, true, true, true },
        raidGroupPositions = {},
        tankPosition = {},
        petPosition = {},
        friendNames = {},
    },
    spellSlots = {
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
        { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 },
    },
    customBleeds = {},
}

local TYPE_COLORS = {
    Curse   = {0.62, 0.28, 0.86},
    Disease = {0.72, 0.55, 0.18},
    Poison  = {0.18, 0.78, 0.28},
    Magic   = {0.18, 0.48, 0.95},
    Bleed   = {0.90, 0.16, 0.16},
    Other   = {0.62, 0.62, 0.62},
}

local TYPE_SHORT = {
    Curse = "C",
    Disease = "D",
    Poison = "P",
    Magic = "M",
    Bleed = "B",
    -- Unknown/custom CoA debuff types still get a neutral border + icon.
    -- Do not stamp a question mark over the unit frame when type is omitted.
    Other = "",
}

local BLEED_NAME_HINTS = {
    "bleed", "bleeding", "rend", "rupture", "garrote", "lacerate",
    "deep wound", "deep wounds", "rip", "hemorrhage", "gash", "bloodletting",
}

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff56b4ffCoA Heal Assist:|r " .. tostring(msg))
end

local function Trim(s)
    if not s then return "" end
    return (string.gsub(string.gsub(s, "^%s+", ""), "%s+$", ""))
end

local function ClampSpellButtonCount(value)
    local n = math.floor(tonumber(value) or DEFAULT_SPELL_BUTTON_COUNT)
    if n < 1 then n = 1 end
    if n > MAX_SPELL_SLOTS then n = MAX_SPELL_SLOTS end
    return n
end

local function ClampButtonSize(value)
    local n = math.floor(tonumber(value) or DEFAULT_BUTTON_SIZE)
    if n < MIN_BUTTON_SIZE then n = MIN_BUTTON_SIZE end
    if n > MAX_BUTTON_SIZE then n = MAX_BUTTON_SIZE end
    return n
end

local function ClampButtonSpacing(value)
    local n = math.floor(tonumber(value) or DEFAULT_BUTTON_SPACING)
    if n < MIN_BUTTON_SPACING then n = MIN_BUTTON_SPACING end
    if n > MAX_BUTTON_SPACING then n = MAX_BUTTON_SPACING end
    return n
end

local function CopyDefaults(src)
    local out = {}
    for k, v in pairs(src) do
        if type(v) == "table" then
            out[k] = CopyDefaults(v)
        else
            out[k] = v
        end
    end
    return out
end

local function MergeDefaults(dst, src)
    for k, v in pairs(src) do
        if dst[k] == nil then
            if type(v) == "table" then dst[k] = CopyDefaults(v) else dst[k] = v end
        elseif type(v) == "table" and type(dst[k]) == "table" then
            MergeDefaults(dst[k], v)
        end
    end
end

local function GetCharacterProfileKey()
    local name = UnitName and UnitName("player") or nil
    name = Trim(name or "")
    if name == "" then name = "UnknownCharacter" end

    local realm = ""
    if GetRealmName then
        local ok, value = pcall(GetRealmName)
        if ok then realm = Trim(value or "") end
    end
    if realm == "" and GetCVar then
        local ok, value = pcall(GetCVar, "realmName")
        if ok then realm = Trim(value or "") end
    end
    if realm == "" then realm = "UnknownRealm" end
    return realm .. " - " .. name
end

local function NormalizeProfile(profile)
    if type(profile) ~= "table" then profile = CopyDefaults(DEFAULTS) end
    MergeDefaults(profile, DEFAULTS)
    profile.version = VERSION
    profile.spellButtonCount = ClampSpellButtonCount(profile.spellButtonCount)
    profile.buttonSize = ClampButtonSize(profile.buttonSize)
    profile.buttonSpacing = ClampButtonSpacing(profile.buttonSpacing)
    if type(profile.minimap) ~= "table" then profile.minimap = { hide = false, angle = 225 } end
    if profile.minimap.hide == nil then profile.minimap.hide = false end
    if tonumber(profile.minimap.angle) == nil then profile.minimap.angle = 225 end
    for i = 1, MAX_SPELL_SLOTS do
        if type(profile.spellSlots[i]) ~= "table" then
            profile.spellSlots[i] = { spell = "", aura = "", auraSource = "", removes = "", bookSlot = 0, bookType = "", spellID = 0 }
        end
    end
    return profile
end

-- v0.6.7 moves the addon from one account-wide healer bar to a profile per
-- Realm + Character. The old global profile is kept unclaimed until we can
-- identify the character whose spellbook actually matches it. This prevents a
-- newly-created alt from inheriting a healer's spell bar simply because that
-- alt happened to be the first character logged in after upgrading.
local function LegacyProfileMatchesCurrentCharacter(profile)
    if CoAHealAssistInternal.ascensionSafeMode then return false end
    if type(profile) ~= "table" or type(profile.spellSlots) ~= "table" then return false end
    local configured, matched = 0, 0
    for i = 1, MAX_SPELL_SLOTS do
        local slot = profile.spellSlots[i]
        local spell = slot and Trim(slot.spell or "") or ""
        if spell ~= "" then
            configured = configured + 1
            if FindSpellBookSlot then
                local bookSlot = FindSpellBookSlot(spell)
                if bookSlot then matched = matched + 1 end
            end
        end
    end
    if configured == 0 then return true end
    if configured <= 2 then return matched >= 1 end
    -- Require a meaningful majority. This tolerates a few talent/spec changes
    -- while rejecting an unrelated alt whose buttons would otherwise be ?.
    return matched >= math.max(2, math.ceil(configured * 0.50))
end

local function EnsureProfileRoot()
    local key = GetCharacterProfileKey()
    activeCharacterKey = key

    if type(CoAHealAssistDB) ~= "table" then
        CoAHealAssistDB = { schemaVersion = 2, profiles = {} }
    elseif type(CoAHealAssistDB.profiles) ~= "table" then
        -- Preserve the complete pre-v0.6.7 global setup as a one-time legacy
        -- profile. It will only be claimed by a character whose spellbook
        -- actually matches the configured spells.
        local legacy = CoAHealAssistDB
        CoAHealAssistDB = {
            schemaVersion = 2,
            profiles = {},
            legacyProfile = legacy,
            legacyClaimedBy = nil,
        }
    end

    CoAHealAssistDB.schemaVersion = 2
    if type(CoAHealAssistDB.profiles) ~= "table" then CoAHealAssistDB.profiles = {} end

    if type(CoAHealAssistDB.profiles[key]) ~= "table" then
        if type(CoAHealAssistDB.legacyProfile) == "table"
            and not CoAHealAssistDB.legacyClaimedBy
            and LegacyProfileMatchesCurrentCharacter(CoAHealAssistDB.legacyProfile) then
            CoAHealAssistDB.profiles[key] = CoAHealAssistDB.legacyProfile
            CoAHealAssistDB.legacyClaimedBy = key
            CoAHealAssistDB.legacyProfile = nil
        else
            -- Brand-new character = genuinely blank healer bar and fresh layout.
            CoAHealAssistDB.profiles[key] = CopyDefaults(DEFAULTS)
        end
    end
    return CoAHealAssistDB, key
end

local function GetDB()
    local root, key = EnsureProfileRoot()
    local profile = NormalizeProfile(root.profiles[key])
    root.profiles[key] = profile
    return profile
end

local function IsInCombatSafe()
    return InCombatLockdown and InCombatLockdown()
end

local function NormalizeSpell(input)
    input = Trim(input)
    if input == "" then return nil, nil, nil end
    local n = tonumber(input)
    if n then
        local name, _, icon = GetSpellInfo(n)
        if name then return name, n, icon end
    end
    local name, _, icon = GetSpellInfo(input)
    if name then return name, nil, icon end
    return input, nil, nil
end

local function IsValidTextureValue(texture)
    if texture == nil then return false end
    if type(texture) == "string" then
        local value = Trim(texture)
        return value ~= "" and value ~= "0"
    end
    if type(texture) == "number" then return texture > 0 end
    return false
end

-- Project Ascension mixes APIs from different client eras. A few of those
-- helpers can throw from SharedXML when an optional numeric flag is nil. Keep
-- those client-side errors contained and fall back to conservative values.
local function SafeCall(func, ...)
    if type(func) ~= "function" then return false end
    local function Pack(...) return { n = select("#", ...), ... } end
    local results = Pack(pcall(func, ...))
    if not results[1] then return false end
    return true, unpack(results, 2, results.n)
end

local function SafeRaidCount()
    if not GetNumRaidMembers then return 0 end
    local ok, value = SafeCall(GetNumRaidMembers)
    return ok and (tonumber(value) or 0) or 0
end

local function SafePartyCount()
    if not GetNumPartyMembers then return 0 end
    local ok, value = SafeCall(GetNumPartyMembers)
    return ok and (tonumber(value) or 0) or 0
end

local function SafeRaidSubgroup(index)
    if not GetRaidRosterInfo then return 1 end
    local ok, name, rank, subgroup = SafeCall(GetRaidRosterInfo, index)
    local group = ok and tonumber(subgroup) or 1
    if not group or group < 1 or group > 8 then group = 1 end
    return group
end

local function SafeRaidRosterRole(index)
    if not GetRaidRosterInfo then return "" end
    local ok, name, rank, subgroup, level, class, fileName, zone, online, isDead, role = SafeCall(GetRaidRosterInfo, index)
    if not ok or role == nil then return "" end
    role = string.upper(tostring(role))
    return role
end

local function RaidIndexFromUnit(unit)
    if type(unit) ~= "string" then return nil end
    local idx = string.match(unit, "^raid(%d+)$")
    idx = tonumber(idx)
    if idx and idx >= 1 and idx <= 40 then return idx end
    if UnitIsUnit and SafeRaidCount() > 0 then
        for i = 1, math.min(SafeRaidCount(), 40) do
            local raidUnit = "raid" .. i
            local ok, same = pcall(UnitIsUnit, unit, raidUnit)
            if ok and same then return i end
        end
    end
    return nil
end

local function PlayerRaidSubgroup()
    if SafeRaidCount() <= 0 then return nil end
    local idx = RaidIndexFromUnit("player")
    if idx then return SafeRaidSubgroup(idx) end

    -- Name fallback for custom clients where UnitIsUnit does not resolve the
    -- player against raidN tokens correctly.
    local playerName = UnitName and UnitName("player") or nil
    if playerName and GetRaidRosterInfo then
        for i = 1, math.min(SafeRaidCount(), 40) do
            local ok, name, rank, subgroup = SafeCall(GetRaidRosterInfo, i)
            if ok and name then
                local short = string.match(tostring(name), "^([^%-]+)") or tostring(name)
                if short == playerName then
                    local g = tonumber(subgroup) or 1
                    if g < 1 or g > 8 then g = 1 end
                    return g
                end
            end
        end
    end
    return nil
end

-- Normalizes custom/older-client aura timestamps. Some CoA auras have returned
-- an expiration value in a different time base; if it is impossible relative
-- to the reported duration, rebuild expiration from duration instead of showing
-- a bogus 1h+ countdown.
local function NormalizeAuraTiming(duration, expirationTime)
    local now = GetTime()
    duration = tonumber(duration) or 0
    expirationTime = tonumber(expirationTime) or 0
    if duration < 0 then duration = 0 end
    if expirationTime < 0 then expirationTime = 0 end

    if duration > 0 then
        local remaining = expirationTime - now
        local tolerance = math.max(5, duration * 0.05)
        if expirationTime <= 0 or remaining < -2 or remaining > (duration + tolerance) then
            expirationTime = now + duration
        end
    elseif expirationTime > 0 then
        local remaining = expirationTime - now
        -- No duration + a wildly distant expiration is not trustworthy on the
        -- custom client. Treat it as untimed instead of inventing an hours timer.
        if remaining < -2 or remaining > (7 * 24 * 60 * 60) then expirationTime = 0 end
    end
    return duration, expirationTime
end

local function GetSpellIconSafe(spellInput)
    local name, spellID, icon = NormalizeSpell(spellInput)
    if IsValidTextureValue(icon) then return icon end

    if GetSpellTexture then
        local candidates = { tonumber(spellInput), spellID, name, spellInput }
        for i = 1, #candidates do
            local candidate = candidates[i]
            if candidate then
                local ok, texture = pcall(GetSpellTexture, candidate)
                if ok and IsValidTextureValue(texture) then return texture end
            end
        end
    end
    return nil
end

-- Resolve the icon from the configured spell slot itself. This is more reliable
-- than UnitBuff's texture on Ascension custom auras: the spellbook/action icon
-- can render correctly while the aura API returns nil or a non-rendering id.
local function ResolveConfiguredSlotIcon(slotIndex)
    slotIndex = tonumber(slotIndex)
    if not slotIndex then return nil end
    local db = GetDB()
    local slot = db and db.spellSlots and db.spellSlots[slotIndex]
    if not slot then return nil end

    -- Exact spellbook texture is the strongest source for custom CoA spells.
    if slot.bookSlot and GetSpellBookItemTexture then
        local ok, texture = SafeCall(GetSpellBookItemTexture, tonumber(slot.bookSlot), slot.bookType or (BOOKTYPE_SPELL or "spell"))
        if ok and IsValidTextureValue(texture) then return texture end
    end

    -- Reuse an icon already proven to render on our secure spell button.
    if IsValidTextureValue(spellSlotIconCache[slotIndex]) then
        return spellSlotIconCache[slotIndex]
    end

    if slot.spellID then
        local icon = GetSpellIconSafe(slot.spellID)
        if IsValidTextureValue(icon) then return icon end
    end
    local icon = GetSpellIconSafe(slot.spell)
    if IsValidTextureValue(icon) then return icon end
    return nil
end

local function FormatTime(seconds)
    if not seconds or seconds <= 0 then return "" end
    if seconds >= 3600 then
        local hours = math.floor(seconds / 3600)
        local minutes = math.floor((seconds % 3600) / 60)
        if minutes > 0 then return string.format("%dh%02dm", hours, minutes) end
        return string.format("%dh", hours)
    elseif seconds >= 60 then
        return string.format("%dm", math.ceil(seconds / 60))
    elseif seconds >= 10 then
        return tostring(math.ceil(seconds))
    else
        return string.format("%.1f", seconds)
    end
end

local function ParseRemoves(text)
    local set = {}
    text = string.lower(text or "")
    for token in string.gmatch(text, "[^,%s/]+") do
        if token == "curse" or token == "c" then set.Curse = true end
        if token == "disease" or token == "d" then set.Disease = true end
        if token == "poison" or token == "p" then set.Poison = true end
        if token == "magic" or token == "m" then set.Magic = true end
        if token == "bleed" or token == "b" then set.Bleed = true end
    end
    return set
end

local function SpellButtonWidth(buttonSize)
    -- Icon-only buttons: width follows the configured button size exactly.
    return ClampButtonSize(buttonSize)
end

-- Reads the real spellbook tooltip so custom CoA cleanses do not need a
-- hard-coded spell list. Ascension is based on a 3.3.5 client but its custom
-- spellbook can expose tooltip data differently from stock WoW, so the scanner
-- deliberately tries several routes and also reads every FontString region on
-- the hidden tooltip instead of relying on one template naming convention.
local scanTooltip
local function GetScanTooltip()
    if scanTooltip then return scanTooltip end
    scanTooltip = CreateFrame("GameTooltip", "CoAHealAssistSpellScanTooltip", UIParent, "GameTooltipTemplate")
    scanTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    scanTooltip:SetAlpha(0)
    scanTooltip:Hide()
    return scanTooltip
end

local function NormalizeSpellNameForMatch(name)
    name = string.lower(Trim(name or ""))
    name = string.gsub(name, "%s+", " ")
    return name
end

local function SpellBookNameAt(slot, bookType)
    if not slot then return nil end
    local name
    if GetSpellName then
        local ok, value = pcall(GetSpellName, slot, bookType or (BOOKTYPE_SPELL or "spell"))
        if ok then name = value end
    end
    if not name and GetSpellBookItemName then
        local ok, value = pcall(GetSpellBookItemName, slot, bookType or (BOOKTYPE_SPELL or "spell"))
        if ok then name = value end
    end
    return name
end

local function SpellBookIDAt(slot, bookType)
    if not slot or not GetSpellBookItemInfo then return nil end
    local ok, a, b, c, d = pcall(GetSpellBookItemInfo, slot, bookType or (BOOKTYPE_SPELL or "spell"))
    if not ok then return nil end
    -- Different 3.3.5/custom clients return the spell id in different positions.
    for _, value in ipairs({b, c, d, a}) do
        if type(value) == "number" and value > 0 then return value end
    end
    return nil
end

FindSpellBookSlot = function(spellName)
    if CoAHealAssistInternal.ascensionSafeMode then
        return nil, BOOKTYPE_SPELL or "spell", nil
    end
    spellName = Trim(spellName)
    if spellName == "" then return nil, BOOKTYPE_SPELL or "spell", nil end
    local wanted = NormalizeSpellNameForMatch(spellName)
    local bookType = BOOKTYPE_SPELL or "spell"

    -- Normal spell-tab walk first.
    if GetNumSpellTabs and GetSpellTabInfo then
        local tabCount = GetNumSpellTabs() or 0
        for tab = 1, tabCount do
            local _, _, offset, numSpells = GetSpellTabInfo(tab)
            offset = tonumber(offset) or 0
            numSpells = tonumber(numSpells) or 0
            for i = 1, numSpells do
                local slot = offset + i
                local name = SpellBookNameAt(slot, bookType)
                if name and NormalizeSpellNameForMatch(name) == wanted then
                    return slot, bookType, SpellBookIDAt(slot, bookType)
                end
            end
        end
    end

    -- CoA custom books have occasionally exposed entries outside the normal tab
    -- accounting. Brute-force a safe range as a compatibility fallback.
    for slot = 1, 800 do
        local name = SpellBookNameAt(slot, bookType)
        if name and NormalizeSpellNameForMatch(name) == wanted then
            return slot, bookType, SpellBookIDAt(slot, bookType)
        end
    end
    return nil, bookType, nil
end

local function TooltipText(tooltip)
    local out, seen = {}, {}
    local function add(text)
        text = Trim(text)
        if text ~= "" and not seen[text] then
            seen[text] = true
            table.insert(out, text)
        end
    end

    local tooltipName = tooltip and tooltip.GetName and tooltip:GetName()
    local count = (tooltip and tooltip.NumLines and tooltip:NumLines()) or 0
    if tooltipName then
        for i = 1, count do
            local left = _G[tooltipName .. "TextLeft" .. i]
            local right = _G[tooltipName .. "TextRight" .. i]
            if left and left.GetText then add(left:GetText()) end
            if right and right.GetText then add(right:GetText()) end
        end
    end

    -- Some Ascension tooltip templates do not populate the conventional global
    -- line names. Read all FontString regions as a second path.
    if tooltip and tooltip.GetRegions then
        local regions = {tooltip:GetRegions()}
        for _, region in ipairs(regions) do
            if region and region.GetText then
                local ok, text = pcall(region.GetText, region)
                if ok then add(text) end
            end
        end
    end
    return table.concat(out, " ")
end

local function DetectRemovesFromText(text)
    text = string.lower(tostring(text or ""))
    text = string.gsub(text, "[%c]+", " ")
    text = string.gsub(text, "%s+", " ")
    if text == "" then return "" end

    local found = {}
    local actions = {
        "remove", "remov", "cure", "curing", "cleanse", "cleansing", "cleans",
        "dispel", "purif", "abolish", "neutraliz", "decurs", "antidote"
    }
    local kinds = {
        {key="Curse", words={"curse", "curses", "cursed"}},
        {key="Disease", words={"disease", "diseases", "diseased"}},
        {key="Poison", words={"poison", "poisons", "poisoned"}},
        {key="Magic", words={"magic effect", "magic effects", "magical effect", "magical effects", "magic debuff", "magic debuffs", "harmful magic"}},
        {key="Bleed", words={"bleed", "bleeds", "bleeding"}},
    }

    local function hasAction(segment)
        for _, action in ipairs(actions) do
            local x = string.find(segment, action, 1, true)
            if x then
                local prefix = string.sub(segment, math.max(1, x - 28), x - 1)
                if not string.find(prefix, "cannot", 1, true)
                   and not string.find(prefix, "can't", 1, true)
                   and not string.find(prefix, "unable", 1, true)
                   and not string.find(prefix, "does not", 1, true)
                   and not string.find(prefix, "doesn't", 1, true) then
                    return true
                end
            end
        end
        return false
    end

    for _, kind in ipairs(kinds) do
        for _, word in ipairs(kind.words) do
            local at = 1
            while true do
                local x, y = string.find(text, word, at, true)
                if not x then break end
                local segment = string.sub(text, math.max(1, x - 220), math.min(string.len(text), y + 220))
                if hasAction(segment) then
                    found[kind.key] = true
                    break
                end
                at = y + 1
            end
            if found[kind.key] then break end
        end
    end

    local ordered = {}
    for _, kind in ipairs({"Curse", "Disease", "Poison", "Magic", "Bleed"}) do
        if found[kind] then table.insert(ordered, kind) end
    end
    return table.concat(ordered, ",")
end

-- Tiny CoA compatibility safety-net for cleanse spells whose custom tooltip is
-- not exposed to addons at all. Normal tooltip parsing always wins first.
-- These entries are only used when every in-client tooltip route returns no
-- usable cleanse text.
local KNOWN_COA_CLEANSE_FALLBACK = {
    ["antivenom"] = "Poison,Curse",
    ["blight antidote"] = "Curse",
}

local function PrimeAndReadTooltip(tooltip, setter)
    if not tooltip or not setter then return "" end
    tooltip:Hide()
    tooltip:ClearLines()
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetAlpha(0)
    local ok = pcall(setter)
    if not ok then return "" end
    -- On several 3.3.5/custom tooltip implementations the FontStrings are not
    -- fully populated until Show() has run at least once.
    tooltip:Show()
    local text = TooltipText(tooltip)
    tooltip:Hide()
    return text
end

local function DetectSpellRemoves(spellInput, bookSlot, bookType, explicitSpellID)
    local spellName, normalizedID = NormalizeSpell(spellInput)
    local spellID = tonumber(explicitSpellID) or tonumber(normalizedID)
    local resolvedSlot = tonumber(bookSlot)
    local resolvedType = bookType or (BOOKTYPE_SPELL or "spell")

    if spellName and spellName ~= "" and not resolvedSlot then
        local foundSlot, foundType, foundID = FindSpellBookSlot(spellName)
        resolvedSlot = foundSlot
        resolvedType = foundType or resolvedType
        if not spellID then spellID = foundID end
    end
    if resolvedSlot and not spellID then spellID = SpellBookIDAt(resolvedSlot, resolvedType) end
    if (not spellName or spellName == "") and spellID and GetSpellInfo then spellName = GetSpellInfo(spellID) end
    if (not spellName or spellName == "") and not resolvedSlot and not spellID then return "", "", "none" end

    local tooltip = GetScanTooltip()
    local attempts = {}
    local function check(source, text)
        text = text or ""
        if text ~= "" then table.insert(attempts, source .. ": " .. text) end
        local parsed = DetectRemovesFromText(text)
        if parsed ~= "" then return parsed, text, source end
        return nil
    end

    -- Exact spellbook slot is the most faithful source for ranked/custom spells.
    if resolvedSlot and tooltip.SetSpellBookItem then
        local text = PrimeAndReadTooltip(tooltip, function()
            tooltip:SetSpellBookItem(resolvedSlot, resolvedType)
        end)
        local a,b,c = check("spellbook", text); if a then return a,b,c end
    end

    -- Ask the spellbook API for an id after SetSpellBookItem; custom clients may
    -- provide the id here even when GetCursorInfo did not.
    if resolvedSlot and not spellID then spellID = SpellBookIDAt(resolvedSlot, resolvedType) end

    if spellID and GetSpellDescription then
        local ok, desc = pcall(GetSpellDescription, spellID)
        if ok and desc and desc ~= "" then
            local a,b,c = check("description", desc); if a then return a,b,c end
        end
    end

    if spellID and tooltip.SetSpellByID then
        local text = PrimeAndReadTooltip(tooltip, function() tooltip:SetSpellByID(spellID) end)
        local a,b,c = check("spell-id", text); if a then return a,b,c end
    end

    if spellID and tooltip.SetHyperlink then
        local text = PrimeAndReadTooltip(tooltip, function() tooltip:SetHyperlink("spell:" .. tostring(spellID)) end)
        local a,b,c = check("spell-link-id", text); if a then return a,b,c end
    end

    -- GetSpellLink can succeed by id or name even when direct hyperlink building
    -- does not on a custom spell.
    if tooltip.SetHyperlink and GetSpellLink then
        local candidates = {spellID, spellName}
        for _, candidate in ipairs(candidates) do
            if candidate then
                local ok, link = pcall(GetSpellLink, candidate)
                if ok and link and link ~= "" then
                    local text = PrimeAndReadTooltip(tooltip, function() tooltip:SetHyperlink(link) end)
                    local a,b,c = check("GetSpellLink", text); if a then return a,b,c end
                end
            end
        end
    end

    local fallback = KNOWN_COA_CLEANSE_FALLBACK[NormalizeSpellNameForMatch(spellName)]
    if fallback then return fallback, table.concat(attempts, " | "), "coa-fallback" end
    return "", table.concat(attempts, " | "), "unresolved"
end

local function AutoFillBlankRemoves(quiet, detailed)
    local db = GetDB()
    local filled, unresolved = 0, 0
    for i = 1, MAX_SPELL_SLOTS do
        local slot = db.spellSlots[i]
        if slot and Trim(slot.spell) ~= "" and Trim(slot.removes) == "" then
            local detected, rawText, source = DetectSpellRemoves(slot.spell, slot.bookSlot, slot.bookType, slot.spellID)
            if detected ~= "" then
                slot.removes = detected
                filled = filled + 1
                if detailed then Print("Slot " .. tostring(i) .. " " .. tostring(slot.spell) .. " -> " .. detected .. " [" .. tostring(source) .. "]") end
            else
                unresolved = unresolved + 1
                if detailed then
                    if rawText and rawText ~= "" then
                        local preview = string.sub(string.gsub(rawText, "%s+", " "), 1, 170)
                        Print("Slot " .. tostring(i) .. " " .. tostring(slot.spell) .. ": no cleanse type found. Tooltip: " .. preview)
                    else
                        Print("Slot " .. tostring(i) .. " " .. tostring(slot.spell) .. ": tooltip text was not exposed to the addon.")
                    end
                end
            end
        end
    end
    if not quiet and not detailed then
        if filled > 0 then
            Print("Auto-filled Removes for " .. tostring(filled) .. " spell slot" .. (filled == 1 and "." or "s."))
        else
            Print("No additional cleanse types were detected from the current spell tooltips.")
        end
    elseif not quiet and detailed then
        Print("Scan complete: " .. tostring(filled) .. " filled, " .. tostring(unresolved) .. " blank/non-cleanse slots.")
    end
    return filled, unresolved
end

local function IsBleed(name, spellID, debuffType)
    if debuffType and string.lower(tostring(debuffType)) == "bleed" then return true end
    local db = GetDB()
    if spellID and db.customBleeds[tonumber(spellID)] then return true end
    local lower = string.lower(name or "")
    for i = 1, #BLEED_NAME_HINTS do
        if string.find(lower, BLEED_NAME_HINTS[i], 1, true) then return true end
    end
    return false
end

local function NormalizeDebuffType(name, spellID, debuffType)
    if IsBleed(name, spellID, debuffType) then return "Bleed" end
    if debuffType == "Curse" or debuffType == "Disease" or debuffType == "Poison" or debuffType == "Magic" then
        return debuffType
    end
    return "Other"
end

local function UnitAuraData(unit, index, helpful)
    local ok, name, rank, icon, count, debuffType, duration, expirationTime, caster, stealable, consolidate, spellID
    if helpful then
        if not UnitBuff then return nil end
        ok, name, rank, icon, count, debuffType, duration, expirationTime, caster, stealable, consolidate, spellID = SafeCall(UnitBuff, unit, index)
    else
        if not UnitDebuff then return nil end
        ok, name, rank, icon, count, debuffType, duration, expirationTime, caster, stealable, consolidate, spellID = SafeCall(UnitDebuff, unit, index)
    end
    if not ok or not name then return nil end
    duration, expirationTime = NormalizeAuraTiming(duration, expirationTime)
    return {
        name = name,
        icon = icon,
        count = tonumber(count) or 0,
        rawType = debuffType,
        duration = duration,
        expiration = expirationTime,
        caster = caster,
        spellID = tonumber(spellID) or spellID,
        index = index,
    }
end

local function FindHelpfulAura(unit, auraName)
    auraName = Trim(auraName)
    if auraName == "" then return nil end
    local wantedName = NormalizeSpell(auraName)
    wantedName = wantedName or auraName
    for i = 1, 40 do
        local a = UnitAuraData(unit, i, true)
        if not a then break end
        if a.name == wantedName or string.lower(a.name) == string.lower(auraName) then return a end
    end
    return nil
end

local function CollectHelpfulAuras(unit)
    local map, list = {}, {}
    for i = 1, 40 do
        local a = UnitAuraData(unit, i, true)
        if not a then break end
        list[#list + 1] = a
        if a.name then
            map[a.name] = a
            map[string.lower(a.name)] = a
        end
    end
    return map, list
end

local function IsPlayerCaster(caster)
    if not caster then return false end
    if caster == "player" then return true end
    if UnitIsUnit and UnitExists and UnitExists(caster) then
        local ok, same = pcall(UnitIsUnit, caster, "player")
        if ok and same then return true end
    end
    return false
end

local function AuraKey(aura)
    if not aura then return nil end
    if aura.spellID then return "id:" .. tostring(aura.spellID) end
    return "name:" .. string.lower(aura.name or "")
end

local function UnitClaimKey(unit)
    if not unit then return nil end
    local guid = UnitGUID and UnitGUID(unit)
    if guid and guid ~= "" then return tostring(guid) end
    local name = UnitName and UnitName(unit)
    if name and name ~= "" then return string.lower(name) end
    return tostring(unit)
end

-- Remember which configured healer slot produced a custom helpful aura.  This
-- deliberately lives on the internal namespace instead of adding more top-level
-- locals (the 3.3.5/Lua 5.1 client has a hard 200-local chunk limit).
function CoAHealAssistInternal.RememberAuraSource(aura, slotIndex, sourceIcon)
    slotIndex = tonumber(slotIndex)
    if not aura or not slotIndex then return end
    local nameKey = NormalizeSpellNameForMatch(aura.name or "")
    local spellID = tonumber(aura.spellID)
    if nameKey ~= "" then
        CoAHealAssistInternal.auraSourceSlotByName[nameKey] = slotIndex
        if IsValidTextureValue(sourceIcon) then CoAHealAssistInternal.auraSourceIconByName[nameKey] = sourceIcon end
    end
    if spellID then
        CoAHealAssistInternal.auraSourceSlotByID[spellID] = slotIndex
        if IsValidTextureValue(sourceIcon) then CoAHealAssistInternal.auraSourceIconByID[spellID] = sourceIcon end
    end
end

function CoAHealAssistInternal.ResolveRememberedAuraSource(aura)
    if not aura then return nil, nil end
    local spellID = tonumber(aura.spellID)
    if spellID and CoAHealAssistInternal.auraSourceSlotByID[spellID] then
        return CoAHealAssistInternal.auraSourceSlotByID[spellID], CoAHealAssistInternal.auraSourceIconByID[spellID]
    end
    local nameKey = NormalizeSpellNameForMatch(aura.name or "")
    if nameKey ~= "" and CoAHealAssistInternal.auraSourceSlotByName[nameKey] then
        return CoAHealAssistInternal.auraSourceSlotByName[nameKey], CoAHealAssistInternal.auraSourceIconByName[nameKey]
    end
    return nil, nil
end

-- Ascension custom auras occasionally omit the caster token. In that case we
-- only treat an aura as ours when CoA Heal Assist directly observed it appear
-- or refresh immediately after we clicked a spell on that exact unit. This
-- keeps the green buff strip strict: random raid/food/world buffs never leak in.
local function MarkOwnedAuraClaim(unit, aura, slotIndex, sourceIcon)
    local unitKey = UnitClaimKey(unit)
    local auraKey = AuraKey(aura)
    if not unitKey or not auraKey then return end
    ownedAuraClaims[unitKey] = ownedAuraClaims[unitKey] or {}
    local expires = tonumber(aura.expiration) or 0
    if expires <= 0 then
        local duration = tonumber(aura.duration) or 0
        expires = GetTime() + ((duration > 0 and duration) or 30)
    end
    CoAHealAssistInternal.RememberAuraSource(aura, slotIndex, sourceIcon)
    ownedAuraClaims[unitKey][auraKey] = {
        slot = slotIndex,
        name = aura.name,
        spellID = aura.spellID,
        -- CoA can report a perfectly valid helpful aura but no usable aura
        -- texture. Cache the texture that was ACTUALLY visible on the secure
        -- spell button when we cast it; this is the most reliable icon source.
        icon = IsValidTextureValue(sourceIcon) and sourceIcon or nil,
        expires = expires + 2,
    }
end

local function GetOwnedAuraClaim(unit, aura)
    local unitKey = UnitClaimKey(unit)
    local auraKey = AuraKey(aura)
    local claims = unitKey and ownedAuraClaims[unitKey]
    local claim = claims and auraKey and claims[auraKey]
    if claim and claim.expires and claim.expires < GetTime() then
        claims[auraKey] = nil
        return nil
    end
    return claim
end

local function IsOwnedAuraClaim(unit, aura, slotIndex)
    if not aura then return false end
    if IsPlayerCaster(aura.caster) then return true end
    local claim = GetOwnedAuraClaim(unit, aura)
    if not claim then return false end
    if slotIndex and claim.slot and claim.slot ~= slotIndex then return false end
    return true
end

local function TooltipAdvertisedAuraDuration(spellInput, bookSlot, bookType, explicitSpellID)
    local key = tostring(explicitSpellID or "") .. "|" .. NormalizeSpellNameForMatch(spellInput or "")
    if longAuraHintCache[key] ~= nil then return longAuraHintCache[key] end

    local _, rawText = DetectSpellRemoves(spellInput, bookSlot, bookType, explicitSpellID)
    local text = string.lower(tostring(rawText or ""))
    text = string.gsub(text, "[%c]+", " ")
    text = string.gsub(text, "%s+", " ")
    local best = 0

    local function consider(pattern, mult)
        local start = 1
        while true do
            local a, b, num = string.find(text, pattern, start)
            if not a then break end
            local prefix = string.sub(text, math.max(1, a - 28), a - 1)
            -- Only treat a number as an aura duration when the nearby tooltip
            -- language actually describes an effect lasting/remaining for it.
            if string.find(prefix, "last", 1, true)
               or string.find(prefix, "for ", 1, true)
               or string.find(prefix, "duration", 1, true)
               or string.find(prefix, "remain", 1, true)
               or string.find(prefix, "over ", 1, true) then
                local seconds = (tonumber(num) or 0) * mult
                if seconds > best then best = seconds end
            end
            start = b + 1
        end
    end

    consider("(%d+)%s*sec", 1)
    consider("(%d+)%s*second", 1)
    consider("(%d+)%s*min", 60)
    consider("(%d+)%s*minute", 60)
    consider("(%d+)%s*hour", 3600)
    longAuraHintCache[key] = best
    return best
end

local function LongTrackedAuraIsPlausible(slot, spellName, spellID, aura, unit, slotIndex)
    if not aura then return false end
    local duration = tonumber(aura.duration) or 0
    local remaining = 0
    if (tonumber(aura.expiration) or 0) > 0 then remaining = (tonumber(aura.expiration) or 0) - GetTime() end
    local observed = math.max(duration, remaining)
    if observed <= 600 then return true end

    -- Long auras on the player's own row need stricter validation. Ascension
    -- has self/passive/proc auras which can share a spell name with a castable
    -- heal. Treating an empty Track Aura field as automatic confirmation was
    -- the cause of bogus 20m-50m grey buttons on only the player's row.
    local isSelf = unit == "player"
    if not isSelf and unit and UnitIsUnit then
        local ok, same = pcall(UnitIsUnit, unit, "player")
        if ok and same then isSelf = true end
    end
    -- Some Ascension builds do not reliably resolve UnitIsUnit(raidN, "player").
    -- Fall back to GUID, then short name, so the player's own raid/party row still
    -- receives the stricter self-aura rules.
    if not isSelf and unit and UnitGUID then
        local okA, unitGUID = pcall(UnitGUID, unit)
        local okB, playerGUID = pcall(UnitGUID, "player")
        if okA and okB and unitGUID and playerGUID and unitGUID == playerGUID then isSelf = true end
    end
    if not isSelf and unit and UnitName then
        local okA, unitName = pcall(UnitName, unit)
        local okB, playerName = pcall(UnitName, "player")
        if okA and okB and unitName and playerName then
            local unitShort = string.match(tostring(unitName), "^([^%-]+)") or tostring(unitName)
            local playerShort = string.match(tostring(playerName), "^([^%-]+)") or tostring(playerName)
            if unitShort == playerShort then isSelf = true end
        end
    end

    -- A direct bar cast that created/refreshed this exact aura is always
    -- trustworthy, including long self buffs.
    local claim = GetOwnedAuraClaim(unit, aura)
    if claim and (not slotIndex or not claim.slot or tonumber(claim.slot) == tonumber(slotIndex)) then return true end

    local tracked = Trim(slot and slot.aura or "")

    -- v0.7.5: Never auto-guess a long aura on the player's own row. Ascension
    -- can expose long self/passive/proc auras that look related to a castable
    -- heal (sometimes even sharing a name or spell id). Those were responsible
    -- for the persistent 18m/23m grey buttons. A long self aura is accepted only
    -- when it was directly observed from this bar cast (claim above), or when
    -- the user explicitly typed/edited the Track Buff/HoT/Shield field.
    if isSelf then
        local source = slot and tostring(slot.auraSource or "") or ""
        if source == "manual" and tracked ~= "" and aura.name and NormalizeSpellNameForMatch(tracked) == NormalizeSpellNameForMatch(aura.name) then
            return true
        end
        return false
    end

    -- Non-self rows can still use the tooltip-duration compatibility fallback.
    local advertised = TooltipAdvertisedAuraDuration(slot and slot.spell or spellName, slot and slot.bookSlot, slot and slot.bookType, slot and slot.spellID or spellID)
    if advertised and advertised >= 600 then
        local tolerance = math.max(60, advertised * 0.20)
        if observed <= advertised + tolerance then return true end
    end

    if tracked ~= "" and aura.name and NormalizeSpellNameForMatch(tracked) == NormalizeSpellNameForMatch(aura.name) then return true end
    if aura.spellID and spellID and tonumber(aura.spellID) == tonumber(spellID) then return true end
    if tracked == "" and aura.name and NormalizeSpellNameForMatch(aura.name) == NormalizeSpellNameForMatch(spellName or "") then return true end
    return false
end

-- Build the helpful-aura strip shown on each player row. It intentionally
-- shows ONLY buffs that are known to be ours: either the API reports the player
-- as caster, or the addon observed the aura from a direct healer-bar cast.
local function CollectDisplayBuffs(unit, helpfulMap, helpfulList)
    local list, seen = {}, {}
    local db = GetDB()

    local function addAura(aura, sourceSlot)
        if not aura or not aura.name then return end
        local key = AuraKey(aura)
        if not key or seen[key] then return end
        seen[key] = true
        local claim = GetOwnedAuraClaim(unit, aura)
        local rememberedSlot, rememberedIcon = CoAHealAssistInternal.ResolveRememberedAuraSource(aura)
        sourceSlot = tonumber(sourceSlot) or tonumber(claim and claim.slot) or tonumber(aura.sourceSlot) or tonumber(rememberedSlot)

        -- If the aura arrived through the generic "my buffs" pass, recover the
        -- spell slot it came from. Without this, custom CoA auras with blank
        -- textures display as empty green timer boxes even though the casting
        -- spell icon is known and visible on our bar.
        if not sourceSlot then
            local auraNameKey = NormalizeSpellNameForMatch(aura.name or "")
            local auraID = tonumber(aura.spellID)
            for slotIndex = 1, MAX_SPELL_SLOTS do
                local slot = db.spellSlots[slotIndex]
                if slot and Trim(slot.spell) ~= "" then
                    local tracked = Trim(slot.aura)
                    local trackedKey = tracked ~= "" and NormalizeSpellNameForMatch(tracked) or ""
                    local spellKey = NormalizeSpellNameForMatch(NormalizeSpell(slot.spell) or slot.spell or "")
                    local slotID = tonumber(slot.spellID)
                    if (trackedKey ~= "" and trackedKey == auraNameKey)
                       or (auraID and slotID and auraID == slotID)
                       or (trackedKey == "" and spellKey ~= "" and spellKey == auraNameKey) then
                        sourceSlot = slotIndex
                        break
                    end
                end
            end
        end

        aura.sourceSlot = sourceSlot
        aura.sourceIcon = (claim and claim.icon) or rememberedIcon or ResolveConfiguredSlotIcon(sourceSlot) or aura.sourceIcon
        if sourceSlot then CoAHealAssistInternal.RememberAuraSource(aura, sourceSlot, aura.sourceIcon) end
        table.insert(list, aura)
    end

    -- First show buffs/HoTs/shields explicitly associated with configured slots.
    for slotIndex = 1, MAX_SPELL_SLOTS do
        local slot = db.spellSlots[slotIndex]
        if slot then
            local spellName = NormalizeSpell(slot.spell)
            local wanted = Trim(slot.aura)
            if wanted == "" then wanted = spellName or "" end
            if wanted ~= "" then
                local normalized = NormalizeSpell(wanted) or wanted
                local aura = helpfulMap and (helpfulMap[normalized] or helpfulMap[string.lower(normalized)] or helpfulMap[string.lower(wanted)])
                if aura and IsOwnedAuraClaim(unit, aura, slotIndex) then addAura(aura, slotIndex) end
            end
        end
        if #list >= MAX_DISPLAY_BUFFS then return list end
    end

    -- Reuse the already-collected helpful aura list instead of calling UnitBuff
    -- another 80 times per unit. One aura scan now feeds every buff decision.
    for _, a in ipairs(helpfulList or {}) do
        if IsPlayerCaster(a.caster) and ((a.duration or 0) > 0 or (a.expiration or 0) > 0) then
            addAura(a, nil)
        elseif not a.caster and IsOwnedAuraClaim(unit, a, nil) then
            addAura(a, nil)
        end
        if #list >= MAX_DISPLAY_BUFFS then return list end
    end

    return list
end

-- CoA custom helpful auras sometimes return nil, 0, or an empty string for
-- their texture. Resolve the display icon through several trustworthy fallbacks
-- so the green buff timer never becomes a blank box.
local function ResolveHelpfulAuraIcon(aura)
    if not aura then return "Interface\\Icons\\INV_Misc_QuestionMark" end

    local db = GetDB()
    local rememberedSlot, rememberedIcon = CoAHealAssistInternal.ResolveRememberedAuraSource(aura)
    local sourceSlot = tonumber(aura.sourceSlot) or tonumber(rememberedSlot)
    if not IsValidTextureValue(aura.sourceIcon) and IsValidTextureValue(rememberedIcon) then aura.sourceIcon = rememberedIcon end

    -- 1) Prefer the configured source spell's exact spellbook/cached icon. A
    -- custom aura can return a texture value that SetTexture accepts but renders
    -- transparent, while its casting spell icon renders perfectly.
    if sourceSlot then
        local texture = ResolveConfiguredSlotIcon(sourceSlot)
        if IsValidTextureValue(texture) then return texture end
    end

    -- 2) Exact texture captured from the spell button at cast time.
    if IsValidTextureValue(aura.sourceIcon) then return aura.sourceIcon end

    -- 3) Runtime texture already proven to render on one of our spell buttons.
    if sourceSlot and IsValidTextureValue(spellSlotIconCache[sourceSlot]) then
        return spellSlotIconCache[sourceSlot]
    end

    -- 4) Spell ID/name lookups often return a usable path even when UnitBuff's
    -- icon field is unusable on the custom client.
    if aura.spellID then
        local _, _, texture = GetSpellInfo(aura.spellID)
        if IsValidTextureValue(texture) then return texture end
        if GetSpellTexture then
            local ok, fallback = pcall(GetSpellTexture, aura.spellID)
            if ok and IsValidTextureValue(fallback) then return fallback end
        end
    end

    if aura.name and aura.name ~= "" then
        local _, _, texture = GetSpellInfo(aura.name)
        if IsValidTextureValue(texture) then return texture end
        if GetSpellTexture then
            local ok, fallback = pcall(GetSpellTexture, aura.name)
            if ok and IsValidTextureValue(fallback) then return fallback end
        end

        -- Match a learned Track Buff/HoT/Shield aura back to its casting slot.
        local auraLower = string.lower(aura.name)
        for slotIndex = 1, MAX_SPELL_SLOTS do
            local slot = db.spellSlots[slotIndex]
            if slot then
                local tracked = Trim(slot.aura)
                if tracked == "" then tracked = NormalizeSpell(slot.spell) or Trim(slot.spell) end
                if tracked ~= "" and string.lower(tracked) == auraLower then
                    if IsValidTextureValue(spellSlotIconCache[slotIndex]) then
                        return spellSlotIconCache[slotIndex]
                    end
                    local fallback = ResolveConfiguredSlotIcon(slotIndex) or GetSpellIconSafe(slot.spell)
                    if IsValidTextureValue(fallback) then return fallback end
                end
            end
        end
    end

    -- 5) Raw aura icon last. Prefer string paths over numeric IDs on this client.
    if type(aura.icon) == "string" and IsValidTextureValue(aura.icon) then return aura.icon end
    if IsValidTextureValue(aura.icon) then return aura.icon end

    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function SnapshotHelpfulAuraKeys(unit)
    local keys = {}
    if not unit or not UnitExists(unit) then return keys end
    for i = 1, 40 do
        local a = UnitAuraData(unit, i, true)
        if not a then break end
        local key = AuraKey(a)
        if key then
            keys[key] = {
                expiration = tonumber(a.expiration) or 0,
                duration = tonumber(a.duration) or 0,
                count = tonumber(a.count) or 0,
            }
        end
    end
    return keys
end

local function QueueAuraLearn(button)
    if not button or not button.unitToken or not button.slotNumber or not button.spellName then return end
    if not UnitExists(button.unitToken) then return end
    local slot = GetDB().spellSlots[button.slotNumber]
    if not slot then return end
    local sourceIcon
    if button.icon and button.icon.GetTexture then
        local ok, texture = pcall(button.icon.GetTexture, button.icon)
        if ok and IsValidTextureValue(texture) then sourceIcon = texture end
    end
    if not IsValidTextureValue(sourceIcon) then sourceIcon = GetSpellIconSafe(button.spellName) end
    table.insert(pendingAuraLearns, {
        unit = button.unitToken,
        slot = button.slotNumber,
        spellName = button.spellName,
        sourceIcon = sourceIcon,
        before = button.preCastAuraKeys or SnapshotHelpfulAuraKeys(button.unitToken),
        started = GetTime(),
        expires = GetTime() + 4.0,
    })
end

local function ProcessPendingAuraLearns()
    if #pendingAuraLearns == 0 then return end
    local now = GetTime()
    for n = #pendingAuraLearns, 1, -1 do
        local pending = pendingAuraLearns[n]
        if now > pending.expires or not pending.unit or not UnitExists(pending.unit) then
            table.remove(pendingAuraLearns, n)
        elseif now - pending.started >= 0.10 then
            local confirmed, unknown = {}, {}
            local matchingConfigured
            local db = GetDB()
            local slot = db.spellSlots[pending.slot]
            local configuredAura = slot and Trim(slot.aura) or ""
            local configuredNormalized = configuredAura ~= "" and (NormalizeSpell(configuredAura) or configuredAura) or nil

            -- A direct heal with charges is not automatically a buff/HoT. Older
            -- versions could learn a passive/proc aura that happened to refresh
            -- after the cast, then show that aura's 18m/23m timer on the heal.
            -- If this slot is a multi-charge spell and the tooltip advertises no
            -- lasting effect, do not auto-learn an aura. Manual Track Aura entries
            -- remain fully supported for legitimate charged HoTs/shields.
            local chargeInfo = spellChargeCache[pending.slot]
            if slot and tostring(slot.auraSource or "") ~= "manual"
               and chargeInfo and tonumber(chargeInfo.maximum) and tonumber(chargeInfo.maximum) > 1 then
                local advertised = TooltipAdvertisedAuraDuration(slot.spell or pending.spellName, slot.bookSlot, slot.bookType, slot.spellID)
                if not advertised or advertised <= 0 then
                    table.remove(pendingAuraLearns, n)
                    slot.aura = ""
                    slot.auraSource = ""
                end
            end

            if pendingAuraLearns[n] == pending then
            for i = 1, 40 do
                local a = UnitAuraData(pending.unit, i, true)
                if not a then break end
                local key = AuraKey(a)
                local timed = ((tonumber(a.duration) or 0) > 0 or (tonumber(a.expiration) or 0) > 0)
                if timed and slot and not LongTrackedAuraIsPlausible(slot, pending.spellName, slot.spellID, a, pending.unit, pending.slot) then
                    timed = false
                end
                local before = key and pending.before[key] or nil
                local refreshed = false
                if before and a.expiration and before.expiration then
                    refreshed = math.abs((tonumber(a.expiration) or 0) - (tonumber(before.expiration) or 0)) > 0.5
                end
                if key and timed and (not before or refreshed) then
                    if IsPlayerCaster(a.caster) then
                        table.insert(confirmed, a)
                    elseif not a.caster then
                        table.insert(unknown, a)
                    end
                end
                if configuredNormalized and a.name and (a.name == configuredNormalized or string.lower(a.name) == string.lower(configuredAura)) then
                    matchingConfigured = a
                end
            end

            local learned
            if #confirmed == 1 then learned = confirmed[1]
            elseif #confirmed == 0 and #unknown == 1 then learned = unknown[1] end

            -- If this slot already has a Track Buff/HoT name, use the matching
            -- aura as the ownership target after our bar click. Prefer API caster
            -- confirmation; otherwise require it to be newly applied/refreshed.
            local owned = learned
            if configuredAura ~= "" and matchingConfigured then
                local key = AuraKey(matchingConfigured)
                local before = key and pending.before[key] or nil
                local refreshed = not before
                if before and matchingConfigured.expiration and before.expiration then
                    refreshed = math.abs((tonumber(matchingConfigured.expiration) or 0) - (tonumber(before.expiration) or 0)) > 0.5
                end
                if IsPlayerCaster(matchingConfigured.caster) or refreshed then owned = matchingConfigured end
            end

            if owned then MarkOwnedAuraClaim(pending.unit, owned, pending.slot, pending.sourceIcon) end

            if learned and learned.name and slot and Trim(slot.aura) == "" then
                slot.aura = learned.name
                slot.auraSource = "auto"
                Print("Learned Track Buff / HoT for slot " .. tostring(pending.slot) .. ": " .. tostring(learned.name))
                if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
            end

            if owned or learned then
                table.remove(pendingAuraLearns, n)
            end
            end -- pending entry still active after charged-direct-heal guard
        end
    end
end

local function GetCachedCooldown(spellName)
    local cached = cooldownCache[spellName]
    if cached then return cached.start, cached.duration, cached.enabled end
    local start, duration, enabled = 0, 0, 0
    if GetSpellCooldown then
        local ok, a, b, c = SafeCall(GetSpellCooldown, spellName)
        if ok then start, duration, enabled = tonumber(a) or 0, tonumber(b) or 0, c end
    end
    cooldownCache[spellName] = { start=start, duration=duration, enabled=enabled }
    return start, duration, enabled
end

local ACTION_BUTTON_PREFIXES = {
    "ActionButton",
    "BonusActionButton",
    "MultiBarBottomLeftButton",
    "MultiBarBottomRightButton",
    "MultiBarRightButton",
    "MultiBarLeftButton",
    "OverrideActionBarButton",
}

local function NormalizeTextureForMatch(texture)
    if texture == nil then return nil end
    if type(texture) == "number" then return "#" .. tostring(texture) end
    if type(texture) ~= "string" then return nil end
    local value = string.lower(texture)
    value = string.gsub(value, "/", "\\")
    return value
end

local function ActionButtonIconTexture(button, globalName)
    if not button then return nil end
    local icon = button.icon or button.Icon or (globalName and _G[globalName .. "Icon"])
    if icon and icon.GetTexture then
        local ok, texture = pcall(icon.GetTexture, icon)
        if ok and IsValidTextureValue(texture) then return texture end
    end
    return nil
end

local function ActionButtonCountText(button, globalName, allowDeep)
    if not button then return nil end

    -- Ascension action bars do not consistently expose the little charge number
    -- through Blizzard's normal <Button>Count field.  Prefer a standalone number
    -- anchored in the lower-right portion of the button, then fall back to common
    -- named fields.  This keeps keybind labels such as "A2" or top-right "2"
    -- from being mistaken for a spell charge.
    local function ReadNumericRegion(region)
        if not region or not region.GetText then return nil end
        local ok, text = pcall(region.GetText, region)
        if not ok or text == nil then return nil end
        local raw = tostring(text)
        local number = tonumber(string.match(raw, "^%s*(%d+)%s*$"))
        if number ~= nil and number >= 0 and number <= 99 then return number, raw end
        return nil
    end

    -- Fast path: once a charge FontString has been discovered, normal updates
    -- only read that one object. Do not recursively rescan the action bar.
    local cachedRegion = CoAHealAssistInternal.buttonChargeRegionCache[button]
    if cachedRegion then
        local number = ReadNumericRegion(cachedRegion)
        if number ~= nil then return number end
        return nil
    end

    local function RegionBottomRightScore(region, number, root)
        if number == nil then return -999 end
        local score = (number <= 9) and 2 or 0
        if region and region.GetName then
            local ok, name = pcall(region.GetName, region)
            if ok and name then
                name = string.lower(tostring(name))
                if string.find(name, "count", 1, true) or string.find(name, "charge", 1, true) then score = score + 8 end
                if string.find(name, "hotkey", 1, true) or string.find(name, "keybind", 1, true) then score = score - 20 end
            end
        end
        if root and root.GetCenter and region and region.GetCenter then
            local ok1, bx, by = pcall(root.GetCenter, root)
            local ok2, rx, ry = pcall(region.GetCenter, region)
            if ok1 and ok2 and bx and by and rx and ry then
                local bw, bh = 40, 40
                if root.GetWidth then local okw, v = pcall(root.GetWidth, root); if okw and tonumber(v) then bw = tonumber(v) end end
                if root.GetHeight then local okh, v = pcall(root.GetHeight, root); if okh and tonumber(v) then bh = tonumber(v) end end
                local dx, dy = rx - bx, ry - by
                -- Reject numbers belonging to neighboring buttons.  The charge
                -- number in Ascension sits inside (or just a few pixels outside)
                -- the matched button's lower-right corner.
                if math.abs(dx) > bw * 0.80 or math.abs(dy) > bh * 0.80 then return -999 end
                if dx >= -bw * 0.10 and dy <= bh * 0.15 then score = score + 14 end
                if dx < -bw * 0.20 then score = score - 6 end
                if dy > bh * 0.20 then score = score - 10 end
            end
        end
        return score
    end

    local bestNumber, bestScore, bestRegion = nil, -999, nil
    local visited = {}
    local function Consider(region, root)
        if not region or visited[region] then return end
        visited[region] = true
        local number = ReadNumericRegion(region)
        if number ~= nil then
            local score = RegionBottomRightScore(region, number, root)
            if score > bestScore then bestNumber, bestScore, bestRegion = number, score, region end
        end
    end

    -- Standard/backported fields first.
    Consider(button.Count, button); Consider(button.count, button)
    Consider(button.Charges, button); Consider(button.charges, button)
    Consider(button.ChargeCount, button); Consider(button.chargeCount, button)
    Consider(button.SpellCount, button); Consider(button.spellCount, button)
    if globalName then
        Consider(_G[globalName .. "Count"], button)
        Consider(_G[globalName .. "Charges"], button)
        Consider(_G[globalName .. "ChargeCount"], button)
        Consider(_G[globalName .. "SpellCount"], button)
    end

    if bestNumber ~= nil and bestScore >= 4 then
        if bestRegion then CoAHealAssistInternal.buttonChargeRegionCache[button] = bestRegion end
        return bestNumber
    end
    if not allowDeep then return nil end

    -- Scan all FontStrings on the button and up to three levels of child frames.
    -- CoA commonly places the visible charge text on an anonymous child rather
    -- than directly on ActionButtonN.
    local function ScanObject(obj, root, depth)
        if not obj or depth < 0 or visited[obj] then return end
        visited[obj] = true
        if obj.GetText then
            local number = ReadNumericRegion(obj)
            if number ~= nil then
                local score = RegionBottomRightScore(obj, number, root)
                if score > bestScore then bestNumber, bestScore, bestRegion = number, score, obj end
            end
        end
        if obj.GetRegions then
            local regions = { obj:GetRegions() }
            for i = 1, #regions do Consider(regions[i], root) end
        end
        if depth > 0 and obj.GetChildren then
            local children = { obj:GetChildren() }
            for i = 1, #children do ScanObject(children[i], root, depth - 1) end
        end
    end
    ScanObject(button, button, 3)

    -- Ascension can render the charge number in a sibling overlay owned by the
    -- action-bar container instead of as a child of the actual button.  Scan the
    -- button's parent/grandparent too, but RegionBottomRightScore rejects text
    -- that is not physically inside this exact button.
    if button.GetParent then
        local okp, parent = pcall(button.GetParent, button)
        if okp and parent and parent ~= UIParent then
            ScanObject(parent, button, 2)
            if parent.GetParent then
                local okg, grand = pcall(parent.GetParent, parent)
                if okg and grand and grand ~= UIParent then
                    local gw, gh = 0, 0
                    if grand.GetWidth then local ok, v = pcall(grand.GetWidth, grand); if ok and tonumber(v) then gw = tonumber(v) end end
                    if grand.GetHeight then local ok, v = pcall(grand.GetHeight, grand); if ok and tonumber(v) then gh = tonumber(v) end end
                    if gw <= 900 and gh <= 500 then ScanObject(grand, button, 2) end
                end
            end
        end
    end

    -- Require a reasonably charge-like location/name.  This intentionally
    -- rejects a bare top-right hotkey number even though it is numeric.
    if bestNumber ~= nil and bestScore >= 4 then
        if bestRegion then CoAHealAssistInternal.buttonChargeRegionCache[button] = bestRegion end
        return bestNumber
    end
    return nil
end

local function SpellIconForChargeMatch(spellName, spellID, slotIndex)
    -- Prefer the exact texture already proven to render in this healer slot.
    if slotIndex and IsValidTextureValue(spellSlotIconCache[slotIndex]) then
        local cached = spellSlotIconCache[slotIndex]
        local isQuestion = type(cached) == "string" and string.find(string.lower(cached), "inv_misc_questionmark", 1, true)
        if not isQuestion then return cached end
    end

    local icon
    if GetSpellInfo then
        local ok, name, rank, texture = SafeCall(GetSpellInfo, spellID or spellName)
        if ok and IsValidTextureValue(texture) then icon = texture end
        if not icon and spellName and spellID then
            ok, name, rank, texture = SafeCall(GetSpellInfo, spellName)
            if ok and IsValidTextureValue(texture) then icon = texture end
        end
    end
    return icon
end

function CoAHealAssistInternal.FrameContainsTexture(frame, wantedTexture, depth)
    if not frame or not wantedTexture or (depth or 0) < 0 then return false end

    local direct = NormalizeTextureForMatch(ActionButtonIconTexture(frame, frame.GetName and frame:GetName() or nil))
    if direct and direct == wantedTexture then return true end

    if frame.GetRegions then
        local regions = { frame:GetRegions() }
        for i = 1, #regions do
            local region = regions[i]
            if region and region.GetTexture then
                local ok, texture = pcall(region.GetTexture, region)
                if ok and NormalizeTextureForMatch(texture) == wantedTexture then return true end
            end
        end
    end

    if (depth or 0) > 0 and frame.GetChildren then
        local children = { frame:GetChildren() }
        for i = 1, #children do
            if CoAHealAssistInternal.FrameContainsTexture(children[i], wantedTexture, depth - 1) then return true end
        end
    end
    return false
end

function CoAHealAssistInternal.IsLikelyActionButtonFrame(frame)
    if not frame or frame.coaHealAssistSpellButton then return false end
    if CoAHealAssistInternal.UIObjectIsVisiblyActive and not CoAHealAssistInternal.UIObjectIsVisiblyActive(frame) then return false end
    if not frame.GetWidth or not frame.GetHeight then return false end
    local okW, w = pcall(frame.GetWidth, frame)
    local okH, h = pcall(frame.GetHeight, frame)
    if not okW or not okH or not w or not h or w < 18 or h < 18 or w > 90 or h > 90 then return false end
    local ratio = w / math.max(h, 1)
    if ratio < 0.65 or ratio > 1.55 then return false end
    return true
end

-- Ascension's custom action buttons can render the correct spell while exposing
-- a texture identifier that does not compare equal to the spellbook texture.
-- The user's default bar also exposes stable visible hotkey text (for example
-- A1/A2/A3).  On a deep discovery pass only, use that text as a low-cost
-- fallback and cache the resulting frame.  Normal updates never rescan for it.
function CoAHealAssistInternal.FrameContainsExactText(frame, wantedText, depth, visited)
    if not frame or not wantedText or (depth or 0) < 0 then return false end
    visited = visited or {}
    if visited[frame] then return false end
    visited[frame] = true

    local wanted = string.upper(Trim(tostring(wantedText)))
    local function MatchesText(obj)
        if not obj or not obj.GetText then return false end
        local ok, value = pcall(obj.GetText, obj)
        if not ok or value == nil then return false end
        return string.upper(Trim(tostring(value))) == wanted
    end

    if MatchesText(frame) then return true end
    if frame.GetRegions then
        local regions = { frame:GetRegions() }
        for i = 1, #regions do
            if MatchesText(regions[i]) then return true end
        end
    end

    if (depth or 0) > 0 and frame.GetChildren then
        local children = { frame:GetChildren() }
        for i = 1, #children do
            if CoAHealAssistInternal.FrameContainsExactText(children[i], wanted, depth - 1, visited) then
                return true
            end
        end
    end
    return false
end

function CoAHealAssistInternal.FindVisibleActionButtonByHotkeyHint(slotIndex)
    slotIndex = tonumber(slotIndex)
    if not slotIndex or slotIndex < 1 or slotIndex > 14 or not EnumerateFrames then return nil, nil end

    -- The bar layout shown by this Ascension UI uses A1..A5 for the healing
    -- abilities that mirror Heal Assist slots 1..5.  Restrict this fallback to
    -- the exact visible label and require a square action-button-sized frame.
    local wanted = "A" .. tostring(slotIndex)
    local frame = EnumerateFrames()
    local inspected = 0
    while frame and inspected < 5000 do
        inspected = inspected + 1
        if CoAHealAssistInternal.IsLikelyActionButtonFrame(frame)
           and CoAHealAssistInternal.FrameContainsExactText(frame, wanted, 2, {}) then
            local name = frame.GetName and frame:GetName() or nil
            return frame, name
        end
        frame = EnumerateFrames(frame)
    end
    return nil, nil
end


-- Manual mouse binding ---------------------------------------------------------------
-- Ascension can render action buttons through custom frames that do not expose the
-- same spell icon identifier as the spellbook.  A one-time mouse bind gives us the
-- exact on-screen frame without adding any continuous scanner cost.  Named frames
-- (or anonymous children beneath a named frame) are saved per character and can be
-- resolved again after /reload.
function CoAHealAssistInternal.BuildActionMirrorBinding(frame)
    if not frame then return nil end
    if frame.GetName then
        local ok, name = pcall(frame.GetName, frame)
        if ok and name and name ~= "" then return { name = name } end
    end

    local path = {}
    local current = frame
    for depth = 1, 7 do
        if not current or not current.GetParent then break end
        local okp, parent = pcall(current.GetParent, current)
        if not okp or not parent or parent == current then break end
        local childIndex
        if parent.GetChildren then
            local children = { parent:GetChildren() }
            for i = 1, #children do
                if children[i] == current then childIndex = i; break end
            end
        end
        if not childIndex then break end
        table.insert(path, childIndex)
        if parent.GetName then
            local okn, parentName = pcall(parent.GetName, parent)
            if okn and parentName and parentName ~= "" and parent ~= UIParent then
                local forward = {}
                for i = #path, 1, -1 do table.insert(forward, path[i]) end
                return { root = parentName, path = forward }
            end
        end
        if parent == UIParent then break end
        current = parent
    end
    return nil
end

function CoAHealAssistInternal.ResolveActionMirrorBinding(binding)
    if type(binding) ~= "table" then return nil end
    if binding.name and _G[binding.name] then return _G[binding.name] end
    if not binding.root or not _G[binding.root] then return nil end
    local current = _G[binding.root]
    local path = binding.path
    if type(path) ~= "table" then return current end
    for i = 1, #path do
        if not current or not current.GetChildren then return nil end
        local children = { current:GetChildren() }
        current = children[tonumber(path[i]) or -1]
        if not current then return nil end
    end
    return current
end

function CoAHealAssistInternal.PickMouseActionButton(slotIndex)
    if not GetMouseFocus then return nil end
    local ok, focus = pcall(GetMouseFocus)
    if not ok or not focus or focus == UIParent or focus == WorldFrame then return nil end

    local wanted = "A" .. tostring(slotIndex or "")
    local best, bestScore = nil, -999
    local current = focus
    for depth = 0, 8 do
        if not current then break end
        local score = -depth
        if CoAHealAssistInternal.IsLikelyActionButtonFrame(current) then score = score + 30 end
        if current.GetWidth and current.GetHeight then
            local okw, w = pcall(current.GetWidth, current)
            local okh, h = pcall(current.GetHeight, current)
            w, h = tonumber(w), tonumber(h)
            if okw and okh and w and h and w >= 24 and h >= 24 and w <= 70 and h <= 70 then
                score = score + 15 - math.min(10, math.abs(w - h))
            end
        end
        if current.GetName then
            local okn, name = pcall(current.GetName, current)
            if okn and name then
                local lower = string.lower(tostring(name))
                if string.find(lower, "action", 1, true) or string.find(lower, "button", 1, true) then score = score + 10 end
            end
        end
        if CoAHealAssistInternal.FrameContainsExactText(current, wanted, 2, {}) then score = score + 25 end
        if score > bestScore then best, bestScore = current, score end
        if not current.GetParent then break end
        local okp, parent = pcall(current.GetParent, current)
        if not okp or not parent or parent == current or parent == UIParent then break end
        current = parent
    end
    return best
end

function CoAHealAssistInternal.BindMouseActionButton(slotIndex, mirrorMode)
    slotIndex = tonumber(slotIndex) or 1
    mirrorMode = string.lower(Trim(mirrorMode or ""))
    if mirrorMode == "" or mirrorMode == "auto" then mirrorMode = "both" end
    if mirrorMode ~= "both" and mirrorMode ~= "proc" and mirrorMode ~= "charge" then
        Print("Usage: /cha barbind <1-14> [both|proc|charge]")
        return
    end
    if slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then Print("Usage: /cha barbind <1-14> [both|proc|charge] while the mouse is over the matching normal action-bar button"); return end
    local db = GetDB()
    local slot = db.spellSlots and db.spellSlots[slotIndex]
    local spellName, spellID = NormalizeSpell(slot and slot.spell or "")
    if slot and tonumber(slot.spellID) then spellID = tonumber(slot.spellID) end
    if not spellName or spellName == "" then Print("Bar bind: Heal Assist slot " .. tostring(slotIndex) .. " is empty."); return end

    local button = CoAHealAssistInternal.PickMouseActionButton(slotIndex)
    if not button then
        Print("Bar bind failed: keep the mouse directly over the NORMAL action-bar spell icon while pressing Enter and typing /cha barbind " .. tostring(slotIndex) .. ".")
        return
    end

    local key = tostring(spellID or "") .. "|" .. NormalizeSpellNameForMatch(spellName or "") .. "|" .. tostring(slotIndex)
    CoAHealAssistInternal.manualActionButtonBindings[slotIndex] = button
    CoAHealAssistInternal.actionButtonFrameCache[key] = button
    CoAHealAssistInternal.actionButtonMissUntil[key] = nil
    CoAHealAssistInternal.buttonChargeRegionCache[button] = nil
    CoAHealAssistInternal.buttonProcVisualCache[button] = nil
    CoAHealAssistInternal.buttonProcBaselineCache[button] = nil
    CoAHealAssistInternal.buttonProcBaselineReady[button] = nil

    local binding = CoAHealAssistInternal.BuildActionMirrorBinding(button)
    if slot then
        slot.actionMirrorBinding = binding
        -- Keep proc mirroring and charge mirroring independent. Ascension may
        -- draw a neighboring charge number on a shared overlay container; a
        -- proc-only binding must never inherit that number.
        slot.actionMirrorMode = mirrorMode
    end

    local globalName = button.GetName and button:GetName() or nil
    local count = ActionButtonCountText(button, globalName, true)
    local wantedTexture = NormalizeTextureForMatch(SpellIconForChargeMatch(spellName, spellID, slotIndex))
    local proc = CoAHealAssistInternal.ActionButtonHasProcGlow and CoAHealAssistInternal.ActionButtonHasProcGlow(button, globalName, wantedTexture, true) or false
    local w, h = 0, 0
    if button.GetWidth then local ok2, v = pcall(button.GetWidth, button); if ok2 then w = tonumber(v) or 0 end end
    if button.GetHeight then local ok2, v = pcall(button.GetHeight, button); if ok2 then h = tonumber(v) or 0 end end
    local persisted = binding and "saved" or "runtime-only"
    Print("Bound Heal Assist slot " .. tostring(slotIndex) .. " (" .. tostring(spellName) .. ") to mouse frame=" .. tostring(globalName or "<anonymous>") .. " " .. tostring(math.floor(w+0.5)) .. "x" .. tostring(math.floor(h+0.5)) .. " mode=" .. tostring(mirrorMode) .. " chargeText=" .. tostring(count) .. " procGlow=" .. tostring(proc) .. " [" .. persisted .. "]")

    -- Force the next lightweight refresh to consume the newly bound frame.
    spellChargeCache[slotIndex] = nil
    CoAHealAssistInternal.spellProcCache[slotIndex] = nil
end

function CoAHealAssistInternal.UnbindActionButton(slotIndex)
    slotIndex = tonumber(slotIndex) or 1
    if slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then Print("Usage: /cha barunbind <1-14>"); return end
    local db = GetDB()
    local slot = db.spellSlots and db.spellSlots[slotIndex]
    if slot then
        slot.actionMirrorBinding = nil
        slot.actionMirrorMode = nil
    end
    CoAHealAssistInternal.manualActionButtonBindings[slotIndex] = nil
    CoAHealAssistInternal.actionButtonFrameCache = {}
    CoAHealAssistInternal.buttonChargeRegionCache = setmetatable({}, { __mode = "k" })
    CoAHealAssistInternal.buttonProcVisualCache = setmetatable({}, { __mode = "k" })
    CoAHealAssistInternal.buttonProcBaselineCache = setmetatable({}, { __mode = "k" })
    CoAHealAssistInternal.buttonProcBaselineReady = setmetatable({}, { __mode = "k" })
    actionButtonChargeCache = {}
    actionChargeKnown = {}
    spellChargeCache[slotIndex] = nil
    CoAHealAssistInternal.spellProcCache[slotIndex] = nil
    Print("Cleared action-bar binding for Heal Assist slot " .. tostring(slotIndex) .. ".")
end

function CoAHealAssistInternal.SetActionMirrorMode(slotIndex, mirrorMode)
    slotIndex = tonumber(slotIndex) or 0
    mirrorMode = string.lower(Trim(mirrorMode or ""))
    if slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS or (mirrorMode ~= "both" and mirrorMode ~= "proc" and mirrorMode ~= "charge") then
        Print("Usage: /cha barmode <1-14> both|proc|charge")
        return
    end
    local db = GetDB()
    local slot = db.spellSlots and db.spellSlots[slotIndex]
    if not slot or not slot.actionMirrorBinding then
        Print("Slot " .. tostring(slotIndex) .. " has no saved action-bar binding. Use /cha barbind " .. tostring(slotIndex) .. " first.")
        return
    end
    slot.actionMirrorMode = mirrorMode
    spellChargeCache[slotIndex] = nil
    CoAHealAssistInternal.spellProcCache[slotIndex] = nil
    Print("Heal Assist slot " .. tostring(slotIndex) .. " action mirror mode set to " .. string.upper(mirrorMode) .. ".")
end

local function FindVisibleActionButtonForSpell(spellName, spellID, slotIndex, allowDeep)
    local key = tostring(spellID or "") .. "|" .. NormalizeSpellNameForMatch(spellName or "") .. "|" .. tostring(slotIndex or "")

    -- Explicit mouse binding wins.  This is the reliable Ascension fallback and
    -- costs nothing during normal updates after the one-time bind.
    local manual = slotIndex and CoAHealAssistInternal.manualActionButtonBindings[slotIndex] or nil
    if manual and CoAHealAssistInternal.IsLikelyActionButtonFrame(manual) then
        CoAHealAssistInternal.actionButtonFrameCache[key] = manual
        return manual, manual.GetName and manual:GetName() or nil
    end
    if slotIndex then
        local db = GetDB()
        local slot = db.spellSlots and db.spellSlots[slotIndex]
        local resolved = slot and CoAHealAssistInternal.ResolveActionMirrorBinding(slot.actionMirrorBinding) or nil
        if resolved and CoAHealAssistInternal.IsLikelyActionButtonFrame(resolved) then
            CoAHealAssistInternal.manualActionButtonBindings[slotIndex] = resolved
            CoAHealAssistInternal.actionButtonFrameCache[key] = resolved
            return resolved, resolved.GetName and resolved:GetName() or nil
        end
    end

    local wantedTexture = NormalizeTextureForMatch(SpellIconForChargeMatch(spellName, spellID, slotIndex))
    if not wantedTexture then return nil, nil end

    local now = (GetTime and GetTime()) or 0
    local missUntil = CoAHealAssistInternal.actionButtonMissUntil[key]
    if missUntil and now < missUntil then return nil, nil end

    -- Anonymous/custom Ascension action buttons are cached by object reference.
    local cachedFrame = CoAHealAssistInternal.actionButtonFrameCache[key]
    if cachedFrame and CoAHealAssistInternal.IsLikelyActionButtonFrame(cachedFrame) then
        -- The cache is invalidated on spell/action-bar changes. Trust the object
        -- here instead of recursively searching its texture tree every poll.
        return cachedFrame, cachedFrame.GetName and cachedFrame:GetName() or nil
    end
    CoAHealAssistInternal.actionButtonFrameCache[key] = nil

    local cachedName = actionButtonChargeCache[key]
    if cachedName then
        local cached = _G[cachedName]
        local visible = cached and (not CoAHealAssistInternal.UIObjectIsVisiblyActive or CoAHealAssistInternal.UIObjectIsVisiblyActive(cached))
        local texture = visible and NormalizeTextureForMatch(ActionButtonIconTexture(cached, cachedName)) or nil
        if cached and texture == wantedTexture then return cached, cachedName end
        actionButtonChargeCache[key] = nil
    end

    local firstMatch, firstName
    for _, prefix in ipairs(ACTION_BUTTON_PREFIXES) do
        for i = 1, 12 do
            local globalName = prefix .. tostring(i)
            local button = _G[globalName]
            local visible = button and (not CoAHealAssistInternal.UIObjectIsVisiblyActive or CoAHealAssistInternal.UIObjectIsVisiblyActive(button))
            if visible then
                local texture = NormalizeTextureForMatch(ActionButtonIconTexture(button, globalName))
                if texture and texture == wantedTexture then
                    local count = ActionButtonCountText(button, globalName, allowDeep)
                    if count ~= nil then
                        actionButtonChargeCache[key] = globalName
                        CoAHealAssistInternal.actionButtonFrameCache[key] = button
                        return button, globalName
                    end
                    if not firstMatch then firstMatch, firstName = button, globalName end
                end
            end
        end
    end

    -- Last-resort compatibility path for custom action-bar addons/Ascension UI.
    -- This scans only visible, roughly square frames and never calls GetActionInfo,
    -- GetActionCount or other action-slot APIs that previously hit CoA's bit.lua.
    if allowDeep and EnumerateFrames then
        local frame = EnumerateFrames()
        local inspected = 0
        local textureOnly, textureOnlyName
        while frame and inspected < 5000 do
            inspected = inspected + 1
            if CoAHealAssistInternal.IsLikelyActionButtonFrame(frame)
               and CoAHealAssistInternal.FrameContainsTexture(frame, wantedTexture, 2) then
                local name = frame.GetName and frame:GetName() or nil
                local count = ActionButtonCountText(frame, name, true)
                if count ~= nil then
                    CoAHealAssistInternal.actionButtonFrameCache[key] = frame
                    if name then actionButtonChargeCache[key] = name end
                    return frame, name
                end
                if not textureOnly then textureOnly, textureOnlyName = frame, name end
            end
            frame = EnumerateFrames(frame)
        end
        if textureOnly then
            CoAHealAssistInternal.actionButtonFrameCache[key] = textureOnly
            if textureOnlyName then actionButtonChargeCache[key] = textureOnlyName end
            return textureOnly, textureOnlyName
        end
    end

    -- Some Ascension UI packs do not expose their action buttons through
    -- EnumerateFrames in the same way as Blizzard frames.  Walk visible UIParent
    -- descendants on a cache miss and look for a square frame containing the
    -- exact spell texture.  This runs only until a button is found, then the
    -- object reference is cached.
    if allowDeep and not firstMatch and UIParent and UIParent.GetChildren then
        local visited, inspected = {}, 0
        local function Walk(obj, depth)
            if not obj or depth < 0 or visited[obj] or inspected >= 6000 then return nil end
            visited[obj] = true; inspected = inspected + 1
            if CoAHealAssistInternal.IsLikelyActionButtonFrame(obj)
               and CoAHealAssistInternal.FrameContainsTexture(obj, wantedTexture, 2) then
                return obj
            end
            if depth > 0 and obj.GetChildren then
                local children = { obj:GetChildren() }
                for i = 1, #children do
                    local found = Walk(children[i], depth - 1)
                    if found then return found end
                end
            end
            return nil
        end
        local found = Walk(UIParent, 6)
        if found then
            local name = found.GetName and found:GetName() or nil
            CoAHealAssistInternal.actionButtonFrameCache[key] = found
            if name then actionButtonChargeCache[key] = name end
            return found, name
        end
    end

    -- Texture matching can fail on Ascension even when the on-screen icon is
    -- visibly identical (one side may expose a file ID while the other exposes
    -- a texture path).  Use the visible A1/A2/A3... hotkey label as the final
    -- discovery fallback, then cache that exact button for fast normal reads.
    if allowDeep and not firstMatch and slotIndex then
        local hinted, hintedName = CoAHealAssistInternal.FindVisibleActionButtonByHotkeyHint(slotIndex)
        if hinted then
            CoAHealAssistInternal.actionButtonFrameCache[key] = hinted
            if hintedName then actionButtonChargeCache[key] = hintedName end
            CoAHealAssistInternal.actionButtonMissUntil[key] = nil
            return hinted, hintedName
        end
    end

    if firstMatch then
        actionButtonChargeCache[key] = firstName
        CoAHealAssistInternal.actionButtonFrameCache[key] = firstMatch
        CoAHealAssistInternal.actionButtonMissUntil[key] = nil
    elseif allowDeep then
        -- A configured spell that is not on an action bar must not trigger a
        -- thousands-of-frames discovery scan every scheduler tick.
        CoAHealAssistInternal.actionButtonMissUntil[key] = now + 30
    end
    return firstMatch, firstName
end


-- Proc/free-cast activation mirroring -------------------------------------------------
-- CoA's custom client already knows when a spell should light up on the normal
-- action bar.  Instead of trying to reverse-engineer every custom aura/talent, we
-- inspect the already-rendered action-button alert.  This avoids protected action
-- APIs and also automatically follows custom CoA proc rules.
function CoAHealAssistInternal.UIObjectIsVisiblyActive(obj)
    if not obj then return false end
    if obj.IsVisible then
        local ok, visible = pcall(obj.IsVisible, obj)
        if ok and not visible then return false end
    elseif obj.IsShown then
        local ok, shown = pcall(obj.IsShown, obj)
        if ok and not shown then return false end
    end
    if obj.GetAlpha then
        local ok, alpha = pcall(obj.GetAlpha, obj)
        if ok and tonumber(alpha) and tonumber(alpha) <= 0.05 then return false end
    end
    return true
end

function CoAHealAssistInternal.UIObjectLooksLikeProcGlow(obj)
    if not CoAHealAssistInternal.UIObjectIsVisiblyActive(obj) then return false end
    local name
    if obj.GetName then
        local ok, value = pcall(obj.GetName, obj)
        if ok and value then name = string.lower(tostring(value)) end
    end
    if name and (
        string.find(name, "spellactivation", 1, true)
        or string.find(name, "procglow", 1, true)
        or string.find(name, "proc_glow", 1, true)
        or string.find(name, "activationalert", 1, true)
        or string.find(name, "overlayglow", 1, true)
        or string.find(name, "proc", 1, true) and string.find(name, "glow", 1, true)
    ) then
        return true
    end

    if obj.GetTexture then
        local ok, texture = pcall(obj.GetTexture, obj)
        if ok and type(texture) == "string" then
            texture = string.lower(texture)
            if string.find(texture, "spellactivation", 1, true)
                or string.find(texture, "procglow", 1, true)
                or string.find(texture, "proc_glow", 1, true)
                or string.find(texture, "activationalert", 1, true)
                or string.find(texture, "ants", 1, true)
            then
                return true
            end
        end
    end
    return false
end

function CoAHealAssistInternal.UIObjectOverlapsActionButton(obj, button)
    if not obj or not button or not obj.GetCenter or not button.GetCenter then return false end
    local okB, bx, by = pcall(button.GetCenter, button)
    local okO, ox, oy = pcall(obj.GetCenter, obj)
    if not okB or not okO or not bx or not by or not ox or not oy then return false end
    local bw, bh, ow, oh = 36, 36, 0, 0
    if button.GetWidth then local ok, v = pcall(button.GetWidth, button); if ok and tonumber(v) then bw = tonumber(v) end end
    if button.GetHeight then local ok, v = pcall(button.GetHeight, button); if ok and tonumber(v) then bh = tonumber(v) end end
    if obj.GetWidth then local ok, v = pcall(obj.GetWidth, obj); if ok and tonumber(v) then ow = tonumber(v) end end
    if obj.GetHeight then local ok, v = pcall(obj.GetHeight, obj); if ok and tonumber(v) then oh = tonumber(v) end end
    if ow > 0 and (ow < bw * 0.55 or ow > bw * 2.8) then return false end
    if oh > 0 and (oh < bh * 0.55 or oh > bh * 2.8) then return false end
    return math.abs(ox - bx) <= bw * 0.65 and math.abs(oy - by) <= bh * 0.65
end

function CoAHealAssistInternal.UITextureLooksLikeAscensionProc(obj, button, wantedTexture)
    if not obj or not CoAHealAssistInternal.UIObjectIsVisiblyActive(obj) then return false end
    if not CoAHealAssistInternal.UIObjectOverlapsActionButton(obj, button) then return false end

    local textureName
    if obj.GetTexture then
        local ok, tex = pcall(obj.GetTexture, obj)
        if ok and tex ~= nil then
            local normalized = NormalizeTextureForMatch(tex)
            if normalized and wantedTexture and normalized == wantedTexture then return false end
            if type(tex) == "string" then textureName = string.lower(tex) end
        end
    end

    -- Custom Ascension activation effects are commonly anonymous additive
    -- textures.  Detect that visual without touching protected action-slot APIs.
    local additive = false
    if obj.GetBlendMode then
        local ok, blend = pcall(obj.GetBlendMode, obj)
        if ok and blend and string.upper(tostring(blend)) == "ADD" then additive = true end
    end

    local goldTint = false
    if obj.GetVertexColor then
        local ok, r, g, b = pcall(obj.GetVertexColor, obj)
        r, g, b = tonumber(r), tonumber(g), tonumber(b)
        if ok and r and g and b and r >= 0.70 and g >= 0.32 and b <= 0.55 and r > b * 1.25 then
            goldTint = true
        end
    end

    local nameHint = false
    if obj.GetName then
        local ok, name = pcall(obj.GetName, obj)
        if ok and name then
            name = string.lower(tostring(name))
            nameHint = string.find(name, "glow", 1, true)
                or string.find(name, "shine", 1, true)
                or string.find(name, "spark", 1, true)
                or string.find(name, "alert", 1, true)
                or string.find(name, "overlay", 1, true)
                or string.find(name, "proc", 1, true)
        end
    end
    local textureHint = textureName and (
        string.find(textureName, "glow", 1, true)
        or string.find(textureName, "shine", 1, true)
        or string.find(textureName, "spark", 1, true)
        or string.find(textureName, "alert", 1, true)
        or string.find(textureName, "overlay", 1, true)
        or string.find(textureName, "proc", 1, true)
        or string.find(textureName, "spellactivation", 1, true)
    )

    -- ADD is the strongest generic signal for the animated border shown by CoA.
    -- A gold-tinted glow/overlay is also accepted for UI packs using BLEND.
    return additive or ((goldTint and (nameHint or textureHint)) and true or false)
end

function CoAHealAssistInternal.GetUIObjectAlpha(obj)
    if not obj or not obj.GetAlpha then return 1 end
    local ok, alpha = pcall(obj.GetAlpha, obj)
    if ok and tonumber(alpha) then return tonumber(alpha) end
    return 1
end

function CoAHealAssistInternal.ProcVisualAboveBaseline(obj, button)
    local baseline = button and CoAHealAssistInternal.buttonProcBaselineCache[button]
    local state = baseline and baseline[obj]
    if not state then return true end

    -- If a texture that was present during calibration disappears, it is no
    -- longer considered part of the permanent button chrome. The next time it
    -- appears it may legitimately be Ascension's temporary proc overlay.
    if not CoAHealAssistInternal.UIObjectIsVisiblyActive(obj) then
        baseline[obj] = nil
        if CoAHealAssistInternal.buttonProcVisualCache[button] == obj then
            CoAHealAssistInternal.buttonProcVisualCache[button] = nil
        end
        return false
    end

    -- Some UI packs keep the same glow texture shown at a low idle alpha and
    -- brighten it for a proc. Only a meaningful alpha increase counts.
    local alpha = CoAHealAssistInternal.GetUIObjectAlpha(obj)
    local baseAlpha = tonumber(state.alpha) or 1
    if baseAlpha >= 0.74 then return false end
    return alpha >= (baseAlpha + 0.25)
end

function CoAHealAssistInternal.IsActiveProcCandidate(obj, button, wantedTexture)
    if not obj or not CoAHealAssistInternal.ProcVisualAboveBaseline(obj, button) then return false end
    return ((CoAHealAssistInternal.UIObjectLooksLikeProcGlow(obj) and CoAHealAssistInternal.UIObjectOverlapsActionButton(obj, button))
        or CoAHealAssistInternal.UITextureLooksLikeAscensionProc(obj, button, wantedTexture)) and true or false
end

function CoAHealAssistInternal.CollectActionButtonProcBaseline(obj, button, wantedTexture, depth, visited, baseline)
    if not obj or (depth or 0) < 0 then return end
    visited = visited or {}
    baseline = baseline or {}
    if visited[obj] then return end
    visited[obj] = true

    local function remember(candidate)
        if not candidate or baseline[candidate] then return end
        local active = (CoAHealAssistInternal.UIObjectLooksLikeProcGlow(candidate) and CoAHealAssistInternal.UIObjectOverlapsActionButton(candidate, button))
            or CoAHealAssistInternal.UITextureLooksLikeAscensionProc(candidate, button, wantedTexture)
        if active then
            baseline[candidate] = { alpha = CoAHealAssistInternal.GetUIObjectAlpha(candidate) }
        end
    end

    remember(obj)
    if obj.GetRegions then
        local regions = { obj:GetRegions() }
        for i = 1, #regions do
            local region = regions[i]
            if not visited[region] then
                visited[region] = true
                remember(region)
            end
        end
    end

    if (depth or 0) > 0 and obj.GetChildren then
        local children = { obj:GetChildren() }
        for i = 1, #children do
            CoAHealAssistInternal.CollectActionButtonProcBaseline(children[i], button, wantedTexture, depth - 1, visited, baseline)
        end
    end
end

function CoAHealAssistInternal.EnsureActionButtonProcBaseline(button, wantedTexture, allowDeep)
    if not button then return false end
    if CoAHealAssistInternal.buttonProcBaselineReady[button] then
        -- Retire any baseline object that has actually disappeared. This arms it
        -- so a later reappearance can be treated as a genuine proc.
        local baseline = CoAHealAssistInternal.buttonProcBaselineCache[button]
        if baseline then
            for obj in pairs(baseline) do
                CoAHealAssistInternal.ProcVisualAboveBaseline(obj, button)
            end
        end
        return false
    end

    -- Baseline calibration is intentionally only done on the staggered/deep
    -- discovery pass. Normal 0.18s polling remains cached and lightweight.
    if not allowDeep then return true end

    local baseline = {}
    local visited = {}
    CoAHealAssistInternal.CollectActionButtonProcBaseline(button, button, wantedTexture, 4, visited, baseline)

    if button.GetParent then
        local okp, parent = pcall(button.GetParent, button)
        if okp and parent and parent ~= UIParent then
            CoAHealAssistInternal.CollectActionButtonProcBaseline(parent, button, wantedTexture, 3, visited, baseline)
            if parent.GetParent then
                local okg, grand = pcall(parent.GetParent, parent)
                if okg and grand and grand ~= UIParent then
                    local gw, gh = 0, 0
                    if grand.GetWidth then local ok, v = pcall(grand.GetWidth, grand); if ok and tonumber(v) then gw = tonumber(v) end end
                    if grand.GetHeight then local ok, v = pcall(grand.GetHeight, grand); if ok and tonumber(v) then gh = tonumber(v) end end
                    if gw <= 900 and gh <= 500 then
                        CoAHealAssistInternal.CollectActionButtonProcBaseline(grand, button, wantedTexture, 3, visited, baseline)
                    end
                end
            end
        end
    end

    CoAHealAssistInternal.buttonProcBaselineCache[button] = baseline
    CoAHealAssistInternal.buttonProcBaselineReady[button] = true
    CoAHealAssistInternal.buttonProcVisualCache[button] = nil
    return true
end

function CoAHealAssistInternal.ScanActionButtonForProcVisual(obj, button, wantedTexture, depth, visited)
    if not obj or (depth or 0) < 0 then return false end
    visited = visited or {}
    if visited[obj] then return false end
    visited[obj] = true

    if CoAHealAssistInternal.IsActiveProcCandidate(obj, button, wantedTexture) then
        return obj
    end

    if obj.GetRegions then
        local regions = { obj:GetRegions() }
        for i = 1, #regions do
            local region = regions[i]
            if not visited[region] then
                visited[region] = true
                if CoAHealAssistInternal.IsActiveProcCandidate(region, button, wantedTexture) then
                    return region
                end
            end
        end
    end

    if (depth or 0) > 0 and obj.GetChildren then
        local children = { obj:GetChildren() }
        for i = 1, #children do
            local found = CoAHealAssistInternal.ScanActionButtonForProcVisual(children[i], button, wantedTexture, depth - 1, visited)
            if found then return found end
        end
    end
    return false
end

function CoAHealAssistInternal.ActionButtonHasProcGlow(button, globalName, wantedTexture, allowDeep)
    if not button then return false end

    -- v0.8.4 could mistake Ascension's permanently-visible button chrome for a
    -- proc, making every manually-bound spell glow forever. Calibrate the
    -- button's idle visual state once, then only accept visuals that appear or
    -- brighten beyond that baseline.
    if CoAHealAssistInternal.EnsureActionButtonProcBaseline(button, wantedTexture, allowDeep) then
        return false
    end

    -- Fast path: once a real temporary proc overlay has been discovered, normal
    -- polling checks only that object instead of recursively walking the bar.
    local cachedVisual = CoAHealAssistInternal.buttonProcVisualCache[button]
    if cachedVisual then
        return CoAHealAssistInternal.IsActiveProcCandidate(cachedVisual, button, wantedTexture)
    end

    -- Common Blizzard/backport field names used by different client generations.
    local candidates = {
        button.SpellActivationAlert,
        button.spellActivationAlert,
        button.SpellActivationOverlay,
        button.spellActivationOverlay,
        button.ProcGlow,
        button.procGlow,
        button.OverlayGlow,
        button.overlayGlow,
        button.Glow,
        button.glow,
    }
    if globalName then
        candidates[#candidates + 1] = _G[globalName .. "SpellActivationAlert"]
        candidates[#candidates + 1] = _G[globalName .. "SpellActivationOverlay"]
        candidates[#candidates + 1] = _G[globalName .. "ProcGlow"]
        candidates[#candidates + 1] = _G[globalName .. "OverlayGlow"]
        candidates[#candidates + 1] = _G[globalName .. "Glow"]
        candidates[#candidates + 1] = _G[globalName .. "Flash"]
    end
    for i = 1, #candidates do
        local candidate = candidates[i]
        if CoAHealAssistInternal.IsActiveProcCandidate(candidate, button, wantedTexture) then
            if candidate then CoAHealAssistInternal.buttonProcVisualCache[button] = candidate end
            return true
        end
    end

    if not allowDeep then return false end

    -- Ascension can build the activation border from anonymous child frames or
    -- textures several levels deep.  First scan the button itself.
    local foundVisual = CoAHealAssistInternal.ScanActionButtonForProcVisual(button, button, wantedTexture, 4, {})
    if foundVisual then
        CoAHealAssistInternal.buttonProcVisualCache[button] = foundVisual
        return true
    end

    -- The gold instant-cast border used by several Ascension UI layouts is a
    -- sibling overlay owned by the bar container, not by the button.  Scan the
    -- immediate parent and a reasonably-sized grandparent; the overlap test in
    -- ScanActionButtonForProcVisual ensures a proc on a neighboring spell cannot
    -- light this healer button.
    if button.GetParent then
        local okp, parent = pcall(button.GetParent, button)
        if okp and parent and parent ~= UIParent then
            foundVisual = CoAHealAssistInternal.ScanActionButtonForProcVisual(parent, button, wantedTexture, 3, {})
            if foundVisual then
                CoAHealAssistInternal.buttonProcVisualCache[button] = foundVisual
                return true
            end
            if parent.GetParent then
                local okg, grand = pcall(parent.GetParent, parent)
                if okg and grand and grand ~= UIParent then
                    local gw, gh = 0, 0
                    if grand.GetWidth then local ok, v = pcall(grand.GetWidth, grand); if ok and tonumber(v) then gw = tonumber(v) end end
                    if grand.GetHeight then local ok, v = pcall(grand.GetHeight, grand); if ok and tonumber(v) then gh = tonumber(v) end end
                    if gw <= 900 and gh <= 500 then
                        foundVisual = CoAHealAssistInternal.ScanActionButtonForProcVisual(grand, button, wantedTexture, 3, {})
                        if foundVisual then
                            CoAHealAssistInternal.buttonProcVisualCache[button] = foundVisual
                            return true
                        end
                    end
                end
            end
        end
    end
    return false
end

function CoAHealAssistInternal.QuerySpellProcReady(spellName, spellID, slotIndex, allowDeep)
    if not spellName or spellName == "" then return false end

    -- Prefer the client's spell-activation SHOW/HIDE event when Ascension
    -- exposes it. This is steadier than sampling a pulsing gold texture.
    if spellID and CoAHealAssistInternal.procEventActive[tostring(spellID)] then return true end
    if CoAHealAssistInternal.procEventActive[NormalizeSpellNameForMatch(spellName)] then return true end
    if slotIndex then
        local db = GetDB()
        local slot = db.spellSlots and db.spellSlots[slotIndex]
        if slot and slot.actionMirrorBinding and slot.actionMirrorMode == "charge" then return false end
    end

    -- CoA/Ascension builds which backport Blizzard's spell-activation system may
    -- expose IsSpellOverlayed even though the rest of the client is 3.3.5 based.
    -- This is the cleanest source of truth and matches the default action bar.
    if IsSpellOverlayed then
        if spellID then
            local ok, ready = SafeCall(IsSpellOverlayed, spellID)
            if ok and ready then return true end
        end
        local ok, ready = SafeCall(IsSpellOverlayed, spellName)
        if ok and ready then return true end
    end

    local button, globalName = FindVisibleActionButtonForSpell(spellName, spellID, slotIndex, allowDeep)
    if not button then return false end
    local wantedTexture = NormalizeTextureForMatch(SpellIconForChargeMatch(spellName, spellID, slotIndex))
    return CoAHealAssistInternal.ActionButtonHasProcGlow(button, globalName, wantedTexture, allowDeep)
end

local function QueryVisibleActionButtonChargeCount(spellName, spellID, slotIndex, allowDeep)
    if slotIndex then
        local db = GetDB()
        local slot = db.spellSlots and db.spellSlots[slotIndex]
        if slot and slot.actionMirrorBinding and slot.actionMirrorMode == "proc" then return nil, false end
    end
    local key = tostring(spellID or "") .. "|" .. NormalizeSpellNameForMatch(spellName or "") .. "|" .. tostring(slotIndex or "")
    local button, globalName = FindVisibleActionButtonForSpell(spellName, spellID, slotIndex, allowDeep)
    if not button then return nil, false end
    local count = ActionButtonCountText(button, globalName, allowDeep)
    if count and count > 0 then actionChargeKnown[key] = true end
    -- Blizzard/Ascension hides the count text at zero. Once we have seen a
    -- positive count for this spell, a blank count means zero charges.
    if count ~= nil then return math.max(0, count), true end
    if actionChargeKnown[key] then return 0, true end
    return nil, false
end

local function QuerySpellCharges(spellName, spellID, slotIndex, allowDeep)
    if slotIndex then
        local db = GetDB()
        local slot = db.spellSlots and db.spellSlots[slotIndex]
        -- PROC-only means exactly that: never show a charge number in this
        -- healer slot, even if Ascension's custom GetSpellCharges or a nearby
        -- action-bar overlay returns a misleading count.
        if slot and slot.actionMirrorBinding and slot.actionMirrorMode == "proc" then return nil, nil, 0, 0 end
    end
    local current, maximum, start, duration
    -- Prefer a direct charge API when this custom client exposes one. Keep this
    -- call protected and do not use C_Spell/GetActionInfo/GetActionCount paths;
    -- those have crossed Ascension SharedXML bit-flag code on some builds.
    if GetSpellCharges then
        local ok, a, b, c, d = SafeCall(GetSpellCharges, spellID or spellName)
        if ok then current, maximum, start, duration = a, b, c, d end
        if (not maximum or tonumber(maximum) == nil) and spellName and spellID then
            ok, a, b, c, d = SafeCall(GetSpellCharges, spellName)
            if ok then current, maximum, start, duration = a, b, c, d end
        end
    end
    current, maximum = tonumber(current), tonumber(maximum)
    if current and maximum and maximum > 1 then
        if current < 0 then current = 0 end
        if current > maximum then current = maximum end
        return current, maximum, tonumber(start) or 0, tonumber(duration) or 0
    end

    -- CoA custom charge abilities often expose the correct number only on the
    -- normal action button. Mirror the already-rendered count text instead of
    -- querying action-slot APIs, which avoids the client's nil bitmask path.
    local actionCount, hasActionCharges = QueryVisibleActionButtonChargeCount(spellName, spellID, slotIndex, allowDeep)
    if hasActionCharges then
        return actionCount, math.max(2, actionCount or 0), 0, 0
    end
    return nil, nil, 0, 0
end

local function GetCachedCharges(slotIndex, spellName, spellID)
    local cached = spellChargeCache[slotIndex]
    if cached then return cached.current, cached.maximum, cached.start, cached.duration end
    local current, maximum, start, duration = QuerySpellCharges(spellName, spellID, slotIndex, false)
    spellChargeCache[slotIndex] = { current=current, maximum=maximum, start=start, duration=duration }
    return current, maximum, start, duration
end

local function CollectDebuffs(unit)
    local list = {}
    for i = 1, 40 do
        local a = UnitAuraData(unit, i, false)
        if not a then break end
        a.type = NormalizeDebuffType(a.name, a.spellID, a.rawType)
        a.priority = (a.type == "Disease" and 1)
            or (a.type == "Curse" and 2)
            or (a.type == "Poison" and 3)
            or (a.type == "Magic" and 4)
            or (a.type == "Bleed" and 5)
            or 9
        table.insert(list, a)
    end
    table.sort(list, function(a, b)
        if a.priority == b.priority then return a.index < b.index end
        return a.priority < b.priority
    end)
    return list
end

local function GetRole(unit)
    if UnitGroupRolesAssigned then
        local ok, role = SafeCall(UnitGroupRolesAssigned, unit)
        if ok and role and role ~= "NONE" then return role end
    end

    -- Wrath/Ascension raid rosters can expose MAINTANK/MAINASSIST only through
    -- GetRaidRosterInfo's old "role" return, even when UnitGroupRolesAssigned
    -- is blank. This is the same assignment shown by the built-in Raid window.
    local raidIndex = RaidIndexFromUnit(unit)
    if raidIndex then
        local raidRole = SafeRaidRosterRole(raidIndex)
        if raidRole == "MAINTANK" or raidRole == "MAIN TANK" or raidRole == "TANK" then
            return "TANK"
        elseif raidRole == "MAINASSIST" or raidRole == "MAIN ASSIST" then
            return "ASSIST"
        end
    end

    if GetPartyAssignment then
        local ok, isTank = SafeCall(GetPartyAssignment, "MAINTANK", unit)
        if ok and isTank then return "TANK" end
    end
    return ""
end

local function UnitDisplayName(unit)
    if not unit or not UnitName then return nil end
    local name, realm = UnitName(unit)
    if not name then return nil end
    if realm and realm ~= "" then return name .. "-" .. realm end
    return name
end

local function FriendKey(name)
    name = Trim(name or "")
    if name == "" then return "" end
    return string.lower(name)
end

local function IsConfiguredFriendUnit(unit)
    local db = GetDB()
    local frames = db.frames or {}
    local list = frames.friendNames or {}
    local name = UnitDisplayName(unit)
    if not name then return false end
    local key = FriendKey(name)
    if list[key] then return true end
    local short = string.match(key, "^([^%-]+)")
    return short and list[short] and true or false
end

local function AddHealFriend(name)
    name = Trim(name or "")
    if name == "" then return false end
    local db = GetDB()
    db.frames.friendNames = db.frames.friendNames or {}
    db.frames.friendNames[FriendKey(name)] = name
    return true
end

local function RemoveHealFriend(name)
    name = Trim(name or "")
    if name == "" then return false end
    local db = GetDB()
    db.frames.friendNames = db.frames.friendNames or {}
    local key = FriendKey(name)
    local removed = false
    if db.frames.friendNames[key] then db.frames.friendNames[key] = nil; removed = true end
    local short = string.match(key, "^([^%-]+)")
    if short and db.frames.friendNames[short] then db.frames.friendNames[short] = nil; removed = true end
    return removed
end

local function ListHealFriends()
    local db = GetDB()
    local list = db.frames.friendNames or {}
    local names = {}
    for _, display in pairs(list) do table.insert(names, display) end
    table.sort(names)
    if #names == 0 then Print("Healium Friends list is empty."); return end
    Print("Healium Friends (shown only while in your party/raid):")
    for i = 1, #names do Print(tostring(i) .. ". " .. tostring(names[i])) end
end

local function GetClassColor(unit)
    local _, classToken = UnitClass(unit)
    if classToken and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classToken] then
        local c = RAID_CLASS_COLORS[classToken]
        return c.r, c.g, c.b
    end
    return 0.20, 0.65, 0.90
end

local function SetBackdrop(frame, borderR, borderG, borderB, borderA)
    frame:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 10,
        insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    frame:SetBackdropColor(0.04, 0.05, 0.07, 0.94)
    frame:SetBackdropBorderColor(borderR or 0.20, borderG or 0.55, borderB or 0.85, borderA or 0.90)
end

local function EffectiveFrameBackgroundAlpha()
    local db = GetDB()
    if not db or db.useBackground == false then return 0 end
    local alpha = tonumber(db.backgroundAlpha)
    if not alpha then alpha = 0.22 end
    if alpha < 0 then alpha = 0 elseif alpha > 1 then alpha = 1 end
    return alpha
end

local function ApplyRosterPanelBackground(panel)
    if not panel or not panel.bg then return end
    panel.bg:SetTexture(0.025, 0.028, 0.035, EffectiveFrameBackgroundAlpha())
end

local function RefreshRosterPanelBackgrounds()
    for i = 1, 8 do ApplyRosterPanelBackground(raidGroupPanels[i]) end
    ApplyRosterPanelBackground(tankPanel)
    ApplyRosterPanelBackground(petPanel)
end

local function CreateText(parent, size, justify)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    local font, _, flags = fs:GetFont()
    fs:SetFont(font, size or 11, flags)
    fs:SetJustifyH(justify or "LEFT")
    return fs
end

local function MakeButton(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetWidth(width or 80)
    b:SetHeight(height or 22)
    b:SetText(text or "")
    return b
end

local function SetCooldownVisual(cd, start, duration)
    if not cd then return end
    start = tonumber(start) or 0
    duration = tonumber(duration) or 0
    if start <= 0 or duration <= 0 then
        cd:SetAlpha(0)
        return
    end
    -- CooldownFrame is parented to a SecureActionButton. Calling Show/Hide on
    -- it during combat can taint protected visibility on 3.3.5/custom clients.
    -- Keep it shown permanently and use alpha for visual visibility instead.
    cd:SetAlpha(1)
    if cd.SetCooldown then
        cd:SetCooldown(start, duration)
    elseif CooldownFrame_SetTimer then
        CooldownFrame_SetTimer(cd, start, duration, 1)
    end
end

local function ClearCooldownVisual(cd)
    if cd then cd:SetAlpha(0) end
end

local function SetSpellCleanseAlert(button, shown)
    if not button or not button.cleanseAlert then return end
    local alert = button.cleanseAlert
    if shown then
        alert.active = true
        activeCleanseAlerts[alert] = true
        alert:SetAlpha(1)
    else
        alert.active = false
        activeCleanseAlerts[alert] = nil
        alert:SetAlpha(0)
        if alert.fill and alert.fill.SetAlpha then alert.fill:SetAlpha(1) end
    end
end


function CoAHealAssistInternal.SetSpellProcAlert(button, shown)
    if not button or not button.procAlert then return end
    local alert = button.procAlert
    shown = shown and true or false
    button.procReady = shown
    alert.active = shown

    -- Proc-ready is intentionally a STEADY bright-gold state. Ascension's
    -- native activation art pulses/fades, which made a mirrored animation look
    -- unreliable in healer frames. We still debounce detection, but once ready
    -- the Heal Assist button remains solid gold until the proc truly ends.
    CoAHealAssistInternal.activeProcAlerts[alert] = nil
    if shown then
        alert:SetAlpha(1)
        if alert.fill and alert.fill.SetAlpha then alert.fill:SetAlpha(0.52) end
        if alert.text then alert.text:SetText("PROC") end
    else
        alert:SetAlpha(0)
        if alert.fill and alert.fill.SetAlpha then alert.fill:SetAlpha(0.52) end
        if alert.text then alert.text:SetText("") end
    end
end

local function ApplySpellIconState(button)
    if not button or not button.icon then return end
    local noMana = button.notEnoughMana and true or false
    local buffActive = button.buffGrey and true or false

    -- Not-enough-mana has visual priority over the normal active-buff grey state.
    -- The secure spell button is left intact; the game itself rejects an
    -- unaffordable cast while this makes the unavailable state obvious.
    if noMana then
        if button.icon.SetDesaturated then button.icon:SetDesaturated(true) end
        button.icon:SetVertexColor(0.32, 0.38, 0.52)
        button.icon:SetAlpha(0.34)
        if button.spellLabel then button.spellLabel:SetTextColor(0.35, 0.45, 0.65) end
        if button.buffShade then button.buffShade:Show() end
        if button.manaShade then button.manaShade:Show() end
    elseif buffActive then
        if button.icon.SetDesaturated then button.icon:SetDesaturated(true) end
        button.icon:SetVertexColor(0.58, 0.58, 0.58)
        button.icon:SetAlpha(0.48)
        if button.spellLabel then button.spellLabel:SetTextColor(0.48, 0.50, 0.54) end
        if button.buffShade then button.buffShade:Show() end
        if button.manaShade then button.manaShade:Hide() end
    else
        if button.icon.SetDesaturated then button.icon:SetDesaturated(false) end
        button.icon:SetVertexColor(1, 1, 1)
        button.icon:SetAlpha(1)
        if button.spellLabel then button.spellLabel:SetTextColor(0.92, 0.92, 0.94) end
        if button.buffShade then button.buffShade:Hide() end
        if button.manaShade then button.manaShade:Hide() end
    end
end

local function SetSpellBuffGrey(button, shown)
    if not button then return end
    button.buffGrey = shown and true or false
    ApplySpellIconState(button)
end

local function SetSpellManaUnavailable(button, shown)
    if not button then return end
    button.notEnoughMana = shown and true or false
    ApplySpellIconState(button)
end

local function SpellNeedsMana(spellName)
    if not spellName or spellName == "" or not IsUsableSpell then return false end
    local ok, usable, noMana = pcall(IsUsableSpell, spellName)
    if not ok then return false end
    return (noMana == true or noMana == 1) and true or false
end

local function SetSpellButtonSecure(button, unit, slot)
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        return
    end
    local spellName = NormalizeSpell(slot.spell)
    button:SetAttribute("unit", unit)
    if spellName and spellName ~= "" then
        button:SetAttribute("type1", "spell")
        button:SetAttribute("spell1", spellName)
        button:SetAttribute("type2", "target")
        button:Enable()
    else
        button:SetAttribute("type1", nil)
        button:SetAttribute("spell1", nil)
        button:SetAttribute("type2", "target")
        -- Keep empty visible slots mouse-enabled so they can receive a spell
        -- dropped directly from the spellbook.
        button:Enable()
    end
end

local function UpdateSpellButton(button, unit, slot, activeTypes, testMode, helpfulMap)
    local spellName, spellID, icon = NormalizeSpell(slot.spell)
    button.spellName = spellName
    button.spellID = spellID
    button.slotData = slot
    button.unitToken = unit

    if not spellName or spellName == "" then
        -- Empty slots are deliberately plain/dark. Do not use a Blizzard spell
        -- icon, cooldown sweep, or additive action-button texture here; those
        -- can animate/flash on the Ascension client even with no spell assigned.
        button.icon:SetTexture(0.045, 0.055, 0.075, 0.95)
        if button.slotNumber then spellSlotIconCache[button.slotNumber] = nil end
        button.icon:SetAlpha(1)
        if button.spellLabel then button.spellLabel:SetText(""); button.spellLabel:Hide() end
        if button.slotText then button.slotText:SetText(tostring(button.slotNumber or "")); button.slotText:Show() end
        button.cooldownText:SetText("")
        button.auraText:SetText("")
        if button.chargeText then button.chargeText:SetText("") end
        button.cooldownStart, button.cooldownDuration, button.cooldownEnabled = 0, 0, nil
        button.cooldownIsGCDOnly = false
        button.trackedAura = nil
        button.notEnoughMana = false
        SetSpellCleanseAlert(button, false)
        CoAHealAssistInternal.SetSpellProcAlert(button, false)
        SetSpellBuffGrey(button, false)
        SetSpellManaUnavailable(button, false)
        ClearCooldownVisual(button.cooldown)
        return
    end

    -- CoA custom spells can resolve a valid name/ID while returning nil for the
    -- icon by name. Prefer the exact saved spellbook slot (when it still points
    -- at the same spell), then a previously known-good slot icon, before using
    -- the generic question mark.
    if not IsValidTextureValue(icon) then
        local bookSlot = tonumber(slot.bookSlot) or 0
        local bookType = Trim(slot.bookType or "")
        if bookType == "" then bookType = BOOKTYPE_SPELL or "spell" end
        if (not CoAHealAssistInternal.ascensionSafeMode) and bookSlot > 0 and GetSpellTexture then
            local bookName = SpellBookNameAt(bookSlot, bookType)
            if bookName and NormalizeSpellNameForMatch(bookName) == NormalizeSpellNameForMatch(spellName) then
                local ok, texture = pcall(GetSpellTexture, bookSlot, bookType)
                if ok and IsValidTextureValue(texture) then icon = texture end
            end
        end
    end
    if not IsValidTextureValue(icon) and button.slotNumber and IsValidTextureValue(spellSlotIconCache[button.slotNumber]) then
        local cached = spellSlotIconCache[button.slotNumber]
        if not (type(cached) == "string" and string.find(string.lower(cached), "inv_misc_questionmark", 1, true)) then icon = cached end
    end
    if not IsValidTextureValue(icon) then icon = GetSpellIconSafe(spellID or spellName) end

    button.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    if button.slotNumber and button.icon.GetTexture then
        local ok, applied = pcall(button.icon.GetTexture, button.icon)
        local isQuestion = type(applied) == "string" and string.find(string.lower(applied), "inv_misc_questionmark", 1, true)
        if ok and IsValidTextureValue(applied) and not isQuestion then spellSlotIconCache[button.slotNumber] = applied end
    end
    if button.icon.SetDesaturated then button.icon:SetDesaturated(false) end
    button.icon:SetAlpha(1)
    if button.spellLabel then button.spellLabel:SetText(""); button.spellLabel:Hide() end
    if button.slotText then button.slotText:Hide() end
    CoAHealAssistInternal.SetSpellProcAlert(button, CoAHealAssistInternal.spellProcCache[button.slotNumber] == true)

    local charges, maxCharges = GetCachedCharges(button.slotNumber, spellName, spellID)
    if button.chargeText then
        if charges ~= nil and maxCharges and maxCharges > 1 then button.chargeText:SetText(tostring(charges)) else button.chargeText:SetText("") end
    end

    local start, duration, enabled = GetCachedCooldown(spellName)
    button.cooldownStart = tonumber(start) or 0
    button.cooldownDuration = tonumber(duration) or 0
    button.cooldownEnabled = enabled
    local remaining = 0
    if start and duration and start > 0 and duration > 0 then
        remaining = (start + duration) - GetTime()
    end
    local db = GetDB()
    local isGCDOnly = duration and duration > 0 and duration <= 1.6
    button.cooldownIsGCDOnly = isGCDOnly and true or false
    if remaining > 0 and (db.showGCD or not isGCDOnly) then
        SetCooldownVisual(button.cooldown, start, duration)
        button.cooldownText:SetText(FormatTime(remaining))
    else
        ClearCooldownVisual(button.cooldown)
        button.cooldownText:SetText("")
    end

    local auraToTrack = Trim(slot.aura)
    if auraToTrack == "" then auraToTrack = spellName end
    local aura
    local allowAuraTracking = true
    -- Multi-charge direct heals can trigger or refresh unrelated self/passive
    -- auras on CoA. Unless the user explicitly configured Track Aura, only let a
    -- charged spell auto-track an aura when its own tooltip describes a lasting
    -- effect. This prevents the post-cooldown fallback to bogus 18m/23m timers.
    if maxCharges and maxCharges > 1 and tostring(slot.auraSource or "") ~= "manual" then
        local advertised = TooltipAdvertisedAuraDuration(slot.spell or spellName, slot.bookSlot, slot.bookType, slot.spellID or spellID)
        if not advertised or advertised <= 0 then allowAuraTracking = false end
    end
    if allowAuraTracking and not testMode and unit and UnitExists(unit) then
        local wantedName = NormalizeSpell(auraToTrack) or auraToTrack
        if helpfulMap then
            aura = helpfulMap[wantedName] or helpfulMap[string.lower(wantedName)] or helpfulMap[string.lower(auraToTrack)]
        else
            aura = FindHelpfulAura(unit, auraToTrack)
        end
        if aura and not IsOwnedAuraClaim(unit, aura, button.slotNumber) then aura = nil end
        if aura and not LongTrackedAuraIsPlausible(slot, spellName, spellID, aura, unit, button.slotNumber) then aura = nil end
    end
    button.trackedAura = aura
    if aura then
        local sourceIcon
        if button.icon and button.icon.GetTexture then
            local ok, texture = pcall(button.icon.GetTexture, button.icon)
            if ok and IsValidTextureValue(texture) then sourceIcon = texture end
        end
        aura.sourceSlot = button.slotNumber
        if IsValidTextureValue(sourceIcon) then aura.sourceIcon = sourceIcon end
        CoAHealAssistInternal.RememberAuraSource(aura, button.slotNumber, sourceIcon)
    end
    if aura and aura.expiration and aura.expiration > 0 then
        local auraRemaining = aura.expiration - GetTime()
        button.auraText:SetText(auraRemaining > 0 and FormatTime(auraRemaining) or "")
    elseif aura then
        button.auraText:SetText("ON")
    else
        button.auraText:SetText("")
    end

    local removes = ParseRemoves(slot.removes)
    local actionable = false
    -- Strict rule: the red warning belongs to THIS spell button only. A debuff
    -- never flashes red merely because it exists; this assigned/visible slot
    -- must explicitly say it removes the matching type.
    if spellName and spellName ~= "" and Trim(slot.removes) ~= "" then
        for debuffType in pairs(activeTypes or {}) do
            if removes[debuffType] then actionable = true break end
        end
    end

    -- A matching cleanse is urgent and takes visual priority over the normal
    -- "buff already active" grey state. The spell remains clickable in both
    -- states; these are visual reminders only.
    SetSpellCleanseAlert(button, actionable)
    SetSpellBuffGrey(button, aura and not actionable)
    SetSpellManaUnavailable(button, spellManaCache[button.slotNumber] and true or false)
end

local function GetCursorSpellDetails()
    if not GetCursorInfo then return nil end
    local cursorType, data1, data2, data3 = GetCursorInfo()
    if cursorType ~= "spell" then return nil end

    local bookSlot, bookType, spellID
    if type(data2) == "string" then
        bookSlot = tonumber(data1)
        bookType = data2
        spellID = tonumber(data3)
    else
        spellID = tonumber(data3) or tonumber(data1)
    end

    local spellName
    if bookSlot then
        if GetSpellName then spellName = GetSpellName(bookSlot, bookType or (BOOKTYPE_SPELL or "spell")) end
        if not spellName and GetSpellBookItemName then spellName = GetSpellBookItemName(bookSlot, bookType or (BOOKTYPE_SPELL or "spell")) end
    end
    if not spellName and spellID then spellName = GetSpellInfo(spellID) end
    if not spellName then spellName = GetSpellInfo(data1) end
    return spellName, bookSlot, bookType, spellID
end

local function GetCursorSpellName()
    local name = GetCursorSpellDetails()
    return name
end

local function AssignCursorSpellToSlot(slotIndex)
    slotIndex = tonumber(slotIndex)
    if not slotIndex or slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then return false end
    if IsInCombatSafe() then
        Print("Spell buttons can only be changed out of combat.")
        if ClearCursor then ClearCursor() end
        return false
    end

    local spellName, bookSlot, bookType, cursorSpellID = GetCursorSpellDetails()
    if not spellName then return false end

    local db = GetDB()
    local slot = db.spellSlots[slotIndex]
    local oldName = NormalizeSpell(slot.spell)
    local changed = (not oldName) or string.lower(oldName) ~= string.lower(spellName)
    slot.spell = spellName
    slot.bookSlot = tonumber(bookSlot) or 0
    slot.bookType = bookType or ""
    slot.spellID = tonumber(cursorSpellID) or (slot.bookSlot > 0 and SpellBookIDAt(slot.bookSlot, slot.bookType ~= "" and slot.bookType or nil)) or 0
    if changed then
        slot.aura = ""
        slot.auraSource = ""
        slot.removes = DetectSpellRemoves(spellName, slot.bookSlot, slot.bookType, slot.spellID)
    elseif Trim(slot.removes) == "" then
        slot.removes = DetectSpellRemoves(spellName, slot.bookSlot, slot.bookType, slot.spellID)
    end
    if ClearCursor then ClearCursor() end
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
    if RebuildUnits then RebuildUnits() else pendingSecureRefresh = true end
    if Trim(slot.removes) ~= "" then
        Print("Spell slot " .. tostring(slotIndex) .. " set to " .. tostring(spellName) .. ". Auto Removes: " .. slot.removes)
    else
        Print("Spell slot " .. tostring(slotIndex) .. " set to " .. tostring(spellName) .. ".")
    end
    return true
end

local function ClearSpellSlot(slotIndex)
    slotIndex = tonumber(slotIndex)
    if not slotIndex or slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then return false end
    if IsInCombatSafe() then
        Print("Spell slots can only be cleared out of combat.")
        return false
    end

    local db = GetDB()
    local oldSpell = db.spellSlots[slotIndex] and Trim(db.spellSlots[slotIndex].spell) or ""
    db.spellSlots[slotIndex] = CopyDefaults(DEFAULTS.spellSlots[slotIndex])
    spellSlotIconCache[slotIndex] = nil
    spellManaCache[slotIndex] = false
    spellChargeCache[slotIndex] = nil
    cooldownCache[slotIndex] = nil

    -- Drop pending auto-learning work that belonged to the removed spell.
    for i = #pendingAuraLearns, 1, -1 do
        if pendingAuraLearns[i] and tonumber(pendingAuraLearns[i].slot) == slotIndex then
            table.remove(pendingAuraLearns, i)
        end
    end

    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB(true) end
    if RebuildUnits then RebuildUnits() else pendingSecureRefresh = true end
    if oldSpell ~= "" then
        Print("Cleared spell slot " .. tostring(slotIndex) .. " (" .. oldSpell .. ").")
    else
        Print("Spell slot " .. tostring(slotIndex) .. " is already empty.")
    end
    return true
end

local function CreateDebuffIcon(parent, index)
    local f = CreateFrame("Frame", nil, parent)
    f:SetWidth(19); f:SetHeight(19)
    f.border = f:CreateTexture(nil, "BACKGROUND")
    f.border:SetAllPoints(f)
    f.border:SetTexture(1, 1, 1, 1)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
    f.icon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
    f.typeText = CreateText(f, 7, "LEFT")
    f.typeText:SetPoint("TOPLEFT", f, "TOPLEFT", 1, 0)
    f.timer = CreateText(f, 7, "RIGHT")
    f.timer:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 0)
    f.stack = CreateText(f, 7, "LEFT")
    f.stack:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 1, 0)
    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self)
        if self.unitToken and self.auraIndex and UnitExists(self.unitToken) then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            if GameTooltip.SetUnitDebuff then
                GameTooltip:SetUnitDebuff(self.unitToken, self.auraIndex)
            elseif self.spellID then
                GameTooltip:SetHyperlink("spell:" .. tostring(self.spellID))
            else
                GameTooltip:SetText(self.auraName or "Debuff")
            end
            GameTooltip:Show()
        elseif self.auraName then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.auraName)
            GameTooltip:AddLine(self.auraType or "Debuff", 1, 1, 1)
            GameTooltip:Show()
        end
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f:Hide()
    return f
end

local function UpdateDebuffIcon(f, aura, unit, testMode)
    f.currentAura = aura
    if not aura then f:Hide(); return end
    f:Show()
    f.unitToken = testMode and nil or unit
    f.auraIndex = aura.index
    f.auraName = aura.name
    f.auraType = aura.type
    f.spellID = aura.spellID

    -- CoA custom debuffs can omit the icon or return a texture value that does
    -- not render. Resolve through spell ID/name before using a safe harmful icon.
    local displayIcon
    if type(aura.icon) == "string" and IsValidTextureValue(aura.icon) then displayIcon = aura.icon end
    if not displayIcon and aura.spellID then displayIcon = GetSpellIconSafe(aura.spellID) end
    if not displayIcon and aura.name then displayIcon = GetSpellIconSafe(aura.name) end
    if not displayIcon and IsValidTextureValue(aura.icon) then displayIcon = aura.icon end
    f.icon:SetTexture(displayIcon or "Interface\\Icons\\Spell_Shadow_ShadowWordPain")

    local c = TYPE_COLORS[aura.type] or TYPE_COLORS.Other
    f.border:SetVertexColor(c[1], c[2], c[3], 1)
    f.typeText:SetText(TYPE_SHORT[aura.type] or "")
    f.typeText:SetTextColor(c[1], c[2], c[3])
    if aura.count and aura.count > 1 then f.stack:SetText(aura.count) else f.stack:SetText("") end
    local remaining = 0
    if aura.expiration and aura.expiration > 0 then remaining = aura.expiration - GetTime() end
    f.timer:SetText(remaining > 0 and FormatTime(remaining) or "")
end


local function CreateBuffIcon(parent, index)
    local f = CreateFrame("Frame", nil, parent)
    f:SetWidth(19); f:SetHeight(19)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetAllPoints(f)

    -- Plain green border; do not use Blizzard's additive action-button border,
    -- which can produce blue flashing/bling on the Ascension client.
    f.border = {}
    local top = f:CreateTexture(nil, "OVERLAY"); top:SetTexture(0.20, 1.0, 0.35, 1); top:SetHeight(1); top:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0); top:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    local bottom = f:CreateTexture(nil, "OVERLAY"); bottom:SetTexture(0.20, 1.0, 0.35, 1); bottom:SetHeight(1); bottom:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0); bottom:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
    local left = f:CreateTexture(nil, "OVERLAY"); left:SetTexture(0.20, 1.0, 0.35, 1); left:SetWidth(1); left:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
    local right = f:CreateTexture(nil, "OVERLAY"); right:SetTexture(0.20, 1.0, 0.35, 1); right:SetWidth(1); right:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
    f.border[1], f.border[2], f.border[3], f.border[4] = top, bottom, left, right

    f.typeText = CreateText(f, 7, "LEFT")
    f.typeText:SetPoint("TOPLEFT", f, "TOPLEFT", 1, 0)
    f.typeText:SetText("+")
    f.typeText:SetTextColor(0.25, 1.0, 0.35)
    f.timer = CreateText(f, 7, "RIGHT")
    f.timer:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 0)
    f.timer:SetTextColor(0.65, 1.0, 0.70)
    f.stack = CreateText(f, 7, "LEFT")
    f.stack:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 1, 0)
    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self)
        if self.unitToken and self.auraIndex and UnitExists(self.unitToken) then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            if GameTooltip.SetUnitBuff then
                GameTooltip:SetUnitBuff(self.unitToken, self.auraIndex)
            elseif self.spellID then
                GameTooltip:SetHyperlink("spell:" .. tostring(self.spellID))
            else
                GameTooltip:SetText(self.auraName or "Buff / HoT / Shield")
            end
            GameTooltip:Show()
        elseif self.auraName then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.auraName)
            GameTooltip:AddLine("Your tracked helpful aura", 0.35, 1.0, 0.45)
            GameTooltip:Show()
        end
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f:Hide()
    return f
end

local function UpdateBuffIcon(f, aura, unit, testMode)
    f.currentAura = aura
    if not aura then
        f:Hide()
        f.unitToken, f.auraIndex, f.auraName, f.spellID, f.sourceSlot, f.sourceIcon = nil, nil, nil, nil, nil, nil
        return
    end

    local sourceSlot = tonumber(aura.sourceSlot)
    -- v0.9.1 deliberately makes the helpful-aura strip slot-driven.  A real
    -- row only sends a buff here when one of its configured Heal Assist spell
    -- buttons is actively tracking that aura, so the icon never has to be
    -- guessed from Ascension's unreliable UnitBuff texture data.
    if not testMode and not sourceSlot then
        f:Hide()
        return
    end

    f:Show()
    f.unitToken = testMode and nil or unit
    f.auraIndex = aura.index
    f.auraName = aura.name
    f.spellID = aura.spellID
    f.sourceSlot = sourceSlot

    local row = f.GetParent and f:GetParent() or nil
    local displayIcon
    if sourceSlot and row and row.spells and row.spells[sourceSlot] and row.spells[sourceSlot].icon then
        local sourceIcon = row.spells[sourceSlot].icon
        if sourceIcon.GetTexture then
            local ok, texture = pcall(sourceIcon.GetTexture, sourceIcon)
            if ok and IsValidTextureValue(texture) then displayIcon = texture end
        end
    end
    if not IsValidTextureValue(displayIcon) and sourceSlot then
        displayIcon = ResolveConfiguredSlotIcon(sourceSlot)
    end
    -- Test mode has no configured source slot, so retain its supplied demo icon.
    if not IsValidTextureValue(displayIcon) and testMode and IsValidTextureValue(aura.icon) then
        displayIcon = aura.icon
    end

    -- Use the exact same simple crop as the large Heal Assist spell buttons.
    -- Do not copy UnitBuff texture coordinates or action-button coordinates.
    f.icon:SetTexture(displayIcon or "Interface\\Icons\\INV_Misc_QuestionMark")
    if f.icon.SetTexCoord then f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    if f.icon.SetBlendMode then f.icon:SetBlendMode("BLEND") end
    if f.icon.SetVertexColor then f.icon:SetVertexColor(1, 1, 1, 1) end
    if f.icon.SetAlpha then f.icon:SetAlpha(1) end
    if f.icon.Show then f.icon:Show() end

    f.sourceIcon = displayIcon
    if sourceSlot then CoAHealAssistInternal.RememberAuraSource(aura, sourceSlot, displayIcon) end

    if aura.count and aura.count > 1 then f.stack:SetText(aura.count) else f.stack:SetText("") end
    local remaining = 0
    if aura.expiration and aura.expiration > 0 then remaining = aura.expiration - GetTime() end
    if remaining > 0 then
        f.timer:SetText(FormatTime(remaining))
    elseif aura.duration and aura.duration > 0 then
        f.timer:SetText("0")
    else
        f.timer:SetText("ON")
    end
end

local function CreateSpellButton(parent, index)
    local b = CreateFrame("Button", nil, parent, "SecureActionButtonTemplate")
    b.coaHealAssistSpellButton = true
    b:SetWidth(SpellButtonWidth(DEFAULT_BUTTON_SIZE)); b:SetHeight(DEFAULT_BUTTON_SIZE)
    b:RegisterForClicks("AnyUp")

    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints(b)
    b.bg:SetTexture(0.035, 0.040, 0.050, 0.98)
    b.border = {}
    local top = b:CreateTexture(nil, "BORDER"); top:SetTexture(0.22, 0.24, 0.28, 1); top:SetHeight(1); top:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0); top:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, 0)
    local bottom = b:CreateTexture(nil, "BORDER"); bottom:SetTexture(0.22, 0.24, 0.28, 1); bottom:SetHeight(1); bottom:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0); bottom:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    local left = b:CreateTexture(nil, "BORDER"); left:SetTexture(0.22, 0.24, 0.28, 1); left:SetWidth(1); left:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0)
    local right = b:CreateTexture(nil, "BORDER"); right:SetTexture(0.22, 0.24, 0.28, 1); right:SetWidth(1); right:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    b.border[1], b.border[2], b.border[3], b.border[4] = top, bottom, left, right

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", b, "TOPLEFT", 2, -2)
    b.icon:SetWidth(DEFAULT_BUTTON_SIZE - 4); b.icon:SetHeight(DEFAULT_BUTTON_SIZE - 4)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    -- Kept as a hidden compatibility field so older refresh paths/settings do not
    -- need special cases. Spell names are available in the mouseover tooltip.
    b.spellLabel = CreateText(b, 10, "LEFT")
    b.spellLabel:SetText("")
    b.spellLabel:Hide()

    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetPoint("TOPLEFT", b, "TOPLEFT", 2, -2)
    b.cooldown:SetWidth(DEFAULT_BUTTON_SIZE - 4); b.cooldown:SetHeight(DEFAULT_BUTTON_SIZE - 4)
    if b.cooldown.SetDrawBling then b.cooldown:SetDrawBling(false) end
    if b.cooldown.SetDrawEdge then b.cooldown:SetDrawEdge(false) end
    -- Keep protected child frames shown from creation onward. Combat refreshes
    -- only change alpha, never protected visibility.
    b.cooldown:Show()
    b.cooldown:SetAlpha(0)

    b.cleanseAlert = CreateFrame("Frame", nil, b)
    b.cleanseAlert:SetAllPoints(b)
    b.cleanseAlert:Show(); b.cleanseAlert:SetAlpha(0); b.cleanseAlert.elapsed = 0; b.cleanseAlert.active = false
    b.cleanseAlert.fill = b.cleanseAlert:CreateTexture(nil, "OVERLAY")
    b.cleanseAlert.fill:SetAllPoints(b.cleanseAlert); b.cleanseAlert.fill:SetTexture(1.0, 0.0, 0.0, 0.62)
    b.cleanseAlert.border = {}
    local ctop = b.cleanseAlert:CreateTexture(nil, "OVERLAY"); ctop:SetTexture(1.0, 0.10, 0.06, 1); ctop:SetHeight(3); ctop:SetPoint("TOPLEFT", b.cleanseAlert, "TOPLEFT", 0, 0); ctop:SetPoint("TOPRIGHT", b.cleanseAlert, "TOPRIGHT", 0, 0)
    local cbottom = b.cleanseAlert:CreateTexture(nil, "OVERLAY"); cbottom:SetTexture(1.0, 0.10, 0.06, 1); cbottom:SetHeight(3); cbottom:SetPoint("BOTTOMLEFT", b.cleanseAlert, "BOTTOMLEFT", 0, 0); cbottom:SetPoint("BOTTOMRIGHT", b.cleanseAlert, "BOTTOMRIGHT", 0, 0)
    local cleft = b.cleanseAlert:CreateTexture(nil, "OVERLAY"); cleft:SetTexture(1.0, 0.10, 0.06, 1); cleft:SetWidth(3); cleft:SetPoint("TOPLEFT", b.cleanseAlert, "TOPLEFT", 0, 0); cleft:SetPoint("BOTTOMLEFT", b.cleanseAlert, "BOTTOMLEFT", 0, 0)
    local cright = b.cleanseAlert:CreateTexture(nil, "OVERLAY"); cright:SetTexture(1.0, 0.10, 0.06, 1); cright:SetWidth(3); cright:SetPoint("TOPRIGHT", b.cleanseAlert, "TOPRIGHT", 0, 0); cright:SetPoint("BOTTOMRIGHT", b.cleanseAlert, "BOTTOMRIGHT", 0, 0)
    b.cleanseAlert.border[1], b.cleanseAlert.border[2], b.cleanseAlert.border[3], b.cleanseAlert.border[4] = ctop, cbottom, cleft, cright

    -- Gold proc/free-cast alert. Keep this child shown permanently and change
    -- only alpha so combat never toggles visibility on a secure button child.
    -- Unlike the native Ascension glow, this Heal Assist state is intentionally
    -- solid/steady so a ready heal is obvious and never visually pulses away.
    b.procAlert = CreateFrame("Frame", nil, b)
    b.procAlert:SetPoint("TOPLEFT", b, "TOPLEFT", -2, 2)
    b.procAlert:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 2, -2)
    b.procAlert:Show(); b.procAlert:SetAlpha(0); b.procAlert.active = false
    b.procAlert.fill = b.procAlert:CreateTexture(nil, "OVERLAY")
    b.procAlert.fill:SetAllPoints(b.procAlert); b.procAlert.fill:SetTexture(1.0, 0.72, 0.05, 0.52)
    if b.procAlert.fill.SetBlendMode then b.procAlert.fill:SetBlendMode("ADD") end
    b.procAlert.border = {}
    local ptop = b.procAlert:CreateTexture(nil, "OVERLAY"); ptop:SetTexture(1.0, 0.88, 0.16, 1); ptop:SetHeight(4); ptop:SetPoint("TOPLEFT", b.procAlert, "TOPLEFT", 0, 0); ptop:SetPoint("TOPRIGHT", b.procAlert, "TOPRIGHT", 0, 0)
    local pbottom = b.procAlert:CreateTexture(nil, "OVERLAY"); pbottom:SetTexture(1.0, 0.88, 0.16, 1); pbottom:SetHeight(4); pbottom:SetPoint("BOTTOMLEFT", b.procAlert, "BOTTOMLEFT", 0, 0); pbottom:SetPoint("BOTTOMRIGHT", b.procAlert, "BOTTOMRIGHT", 0, 0)
    local pleft = b.procAlert:CreateTexture(nil, "OVERLAY"); pleft:SetTexture(1.0, 0.88, 0.16, 1); pleft:SetWidth(4); pleft:SetPoint("TOPLEFT", b.procAlert, "TOPLEFT", 0, 0); pleft:SetPoint("BOTTOMLEFT", b.procAlert, "BOTTOMLEFT", 0, 0)
    local pright = b.procAlert:CreateTexture(nil, "OVERLAY"); pright:SetTexture(1.0, 0.88, 0.16, 1); pright:SetWidth(4); pright:SetPoint("TOPRIGHT", b.procAlert, "TOPRIGHT", 0, 0); pright:SetPoint("BOTTOMRIGHT", b.procAlert, "BOTTOMRIGHT", 0, 0)
    b.procAlert.border[1], b.procAlert.border[2], b.procAlert.border[3], b.procAlert.border[4] = ptop, pbottom, pleft, pright
    b.procAlert.text = CreateText(b.procAlert, 7, "LEFT")
    b.procAlert.text:SetPoint("TOPLEFT", b.procAlert, "TOPLEFT", 3, -2)
    b.procAlert.text:SetTextColor(1.0, 1.0, 0.45)
    b.procAlert.text:SetText("")

    b.buffShade = b:CreateTexture(nil, "OVERLAY")
    b.buffShade:SetAllPoints(b); b.buffShade:SetTexture(0, 0, 0, 0.38); b.buffShade:Hide()
    b.manaShade = b:CreateTexture(nil, "OVERLAY")
    b.manaShade:SetAllPoints(b); b.manaShade:SetTexture(0.02, 0.10, 0.35, 0.42); b.manaShade:Hide()
    b.buffGrey = false
    b.notEnoughMana = false
    SetSpellCleanseAlert(b, false)
    b.slotText = CreateText(b, 9, "CENTER")
    b.slotText:SetPoint("CENTER", b, "LEFT", math.floor(DEFAULT_BUTTON_SIZE / 2), 0)
    b.slotText:SetTextColor(0.38, 0.48, 0.62); b.slotText:SetText(tostring(index))
    b.cooldownText = CreateText(b, 10, "CENTER")
    b.cooldownText:SetPoint("CENTER", b, "LEFT", math.floor(DEFAULT_BUTTON_SIZE / 2), 0); b.cooldownText:SetTextColor(1, 1, 1)
    b.auraText = CreateText(b, 9, "RIGHT")
    b.auraText:SetPoint("TOPRIGHT", b, "TOPRIGHT", -2, -1); b.auraText:SetTextColor(0.35, 1.0, 0.45)
    b.chargeText = CreateText(b, 10, "RIGHT")
    b.chargeText:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -2, 1)
    b.chargeText:SetTextColor(1.0, 1.0, 1.0)
    b.chargeText:SetText("")
    b.slotNumber = index
    b:SetScript("OnReceiveDrag", function(self) AssignCursorSpellToSlot(self.slotNumber) end)
    b:SetScript("PreClick", function(self, mouseButton)
        self.coaClearRequested = false
        if mouseButton == "RightButton" and IsShiftKeyDown and IsShiftKeyDown() then
            self.coaClearRequested = true
            self.preCastAuraKeys = nil
            return
        end
        if mouseButton == "LeftButton" and self.spellName and not self.notEnoughMana and self.unitToken and UnitExists(self.unitToken) then self.preCastAuraKeys = SnapshotHelpfulAuraKeys(self.unitToken) else self.preCastAuraKeys = nil end
    end)
    b:SetScript("PostClick", function(self, mouseButton)
        if self.coaClearRequested and mouseButton == "RightButton" then
            self.coaClearRequested = false
            ClearSpellSlot(self.slotNumber)
            return
        end
        if mouseButton == "LeftButton" and self.spellName and not self.notEnoughMana and self.preCastAuraKeys then QueueAuraLearn(self) end
    end)
    b:SetScript("OnEnter", function(self)
        if not GetDB().showSpellTooltips then
            GameTooltip:Hide()
            return
        end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if self.spellID then GameTooltip:SetHyperlink("spell:" .. tostring(self.spellID)) elseif self.spellName then GameTooltip:SetText(self.spellName) else GameTooltip:SetText("Spell slot " .. tostring(self.slotNumber)); GameTooltip:AddLine("Drag a spell from your spellbook directly onto this button.", 0.8, 0.8, 0.8, true) end
        if self.slotData and Trim(self.slotData.removes) ~= "" then GameTooltip:AddLine("Removes: " .. self.slotData.removes, 1, 0.75, 0.25) end
        if self.notEnoughMana then GameTooltip:AddLine("NOT ENOUGH MANA", 0.30, 0.60, 1.0) end
        local chargeInfo = self.slotNumber and spellChargeCache[self.slotNumber]
        if chargeInfo and chargeInfo.current ~= nil and chargeInfo.maximum and chargeInfo.maximum > 1 then GameTooltip:AddLine("Charges: " .. tostring(chargeInfo.current) .. "/" .. tostring(chargeInfo.maximum), 0.95, 0.95, 1.0) end
        GameTooltip:AddLine("Green + icons = buffs/HoTs/shields cast by YOU", 0.35, 1.0, 0.45)
        GameTooltip:AddLine("Grey = tracked buff/HoT is already active", 0.7, 0.7, 0.7)
        GameTooltip:AddLine("Dark blue/grey = not enough mana to cast", 0.35, 0.55, 1.0)
        GameTooltip:AddLine("Flashing red = this spell can cleanse an active debuff", 1.0, 0.25, 0.25)
        GameTooltip:AddLine("Bright gold PROC = default action bar says this spell is proc-ready", 1.0, 0.88, 0.20)
        GameTooltip:AddLine("Left-click: cast  |  Right-click: target", 0.7, 0.9, 1)
        GameTooltip:AddLine("Shift + Right-click: clear this spell slot", 1.0, 0.65, 0.35)
        GameTooltip:AddLine("Drop from spellbook: assign/replace slot (out of combat)", 0.45, 1.0, 0.55, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local RAID_TARGET_TEXTURE = "Interface\\TargetingFrame\\UI-RaidTargetingIcons"

local function SetRaidMarkerTexture(texture, markerIndex)
    markerIndex = tonumber(markerIndex)
    if not texture or not markerIndex or markerIndex < 1 or markerIndex > 8 then
        if texture then texture:Hide() end
        return false
    end

    -- Wrath/Ascension's SetRaidTargetIconTexture normally only changes the
    -- texture coordinates. The texture itself must already be the shared raid
    -- target icon sheet or the marker can be completely blank.
    texture:SetTexture(RAID_TARGET_TEXTURE)

    -- Apply Blizzard's classic 4-column raid-target atlas coordinates first.
    -- The eight raid markers occupy the first two rows of a 4x4 coordinate
    -- grid on UI-RaidTargetingIcons. If the helper exists it may overwrite these
    -- with the client's exact values; if it silently does nothing this remains.
    local zero = markerIndex - 1
    local col = math.mod and math.mod(zero, 4) or (zero % 4)
    local row = math.floor(zero / 4)
    local left = col * 0.25
    local right = left + 0.25
    local top = row * 0.25
    local bottom = top + 0.25
    texture:SetTexCoord(left, right, top, bottom)

    -- Ascension can ship a modified raid-target atlas. Let its classic helper
    -- override our fallback coordinates when available, but keep the call safe.
    if SetRaidTargetIconTexture then pcall(SetRaidTargetIconTexture, texture, markerIndex) end

    if texture.SetVertexColor then texture:SetVertexColor(1, 1, 1, 1) end
    texture:Show()
    return true
end

local function GetRaidMarkerIndexSafe(unit)
    if not unit or not GetRaidTargetIndex then return nil end

    local ok, value = pcall(GetRaidTargetIndex, unit)
    if ok and tonumber(value) and tonumber(value) > 0 then return tonumber(value) end

    -- Final identity fallback: find the matching raidN token and query it.
    if UnitIsUnit then
        local count = math.min(SafeRaidCount(), 40)
        for i = 1, count do
            local raidUnit = "raid" .. i
            local sameOK, same = pcall(UnitIsUnit, unit, raidUnit)
            if sameOK and same then
                ok, value = pcall(GetRaidTargetIndex, raidUnit)
                if ok and tonumber(value) and tonumber(value) > 0 then return tonumber(value) end
            end
        end
    end
    return nil
end

local function UpdateRaidTargetMarker(row, unit, forcedIndex)
    if not row or not row.raidMarker then return end
    local markerIndex = tonumber(forcedIndex) or GetRaidMarkerIndexSafe(unit)

    local shown = SetRaidMarkerTexture(row.raidMarker, markerIndex)
    row.role:ClearAllPoints()
    row.name:ClearAllPoints()
    if shown then
        row.role:SetPoint("TOPLEFT", row.health, "TOPLEFT", 19, -1)
        row.name:SetPoint("TOPLEFT", row.health, "TOPLEFT", 31, -1)
        row.name:SetWidth(73)
    else
        row.role:SetPoint("TOPLEFT", row.health, "TOPLEFT", 2, -1)
        row.name:SetPoint("TOPLEFT", row.health, "TOPLEFT", 16, -1)
        row.name:SetWidth(91)
    end
end

local function RefreshRaidTargetMarkers()
    if assignedIsTest then return end
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local unit = assignedUnits[i]
        if unit and rows[i] then UpdateRaidTargetMarker(rows[i], unit) end
    end
end

local function CreateUnitRow(parent, index)
    local r = CreateFrame("Frame", nil, parent)
    r:SetWidth(535); r:SetHeight(DEFAULT_BUTTON_SIZE)
    SetBackdrop(r, 0.12, 0.13, 0.16, 0.95)
    r.health = CreateFrame("StatusBar", nil, r)
    r.health:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    r.health:SetPoint("TOPLEFT", r, "TOPLEFT", 2, -2)
    r.health:SetWidth(UNIT_PANEL_WIDTH - 4); r.health:SetHeight(DEFAULT_BUTTON_SIZE - 4)
    r.health:SetMinMaxValues(0, 100)
    r.healthBG = r.health:CreateTexture(nil, "BACKGROUND"); r.healthBG:SetAllPoints(r.health)
    r.healthBG:SetTexture("Interface\\TargetingFrame\\UI-StatusBar"); r.healthBG:SetVertexColor(0.055, 0.055, 0.065, 1)
    -- Lightweight absorb display. It never scans auras/spell IDs; it only uses
    -- the standard absorb amount API when this Ascension client exposes it.
    r.shieldOverlay = r.health:CreateTexture(nil, "ARTWORK")
    r.shieldOverlay:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
    r.shieldOverlay:SetVertexColor(0.18, 0.62, 1.00, 0.72)
    r.shieldOverlay:Hide()
    r.shieldEdge = r.health:CreateTexture(nil, "OVERLAY")
    r.shieldEdge:SetTexture(0.55, 0.86, 1.00, 0.95)
    r.shieldEdge:SetWidth(2)
    r.shieldEdge:Hide()
    r.raidMarker = r.health:CreateTexture(nil, "OVERLAY")
    r.raidMarker:SetWidth(16); r.raidMarker:SetHeight(16)
    r.raidMarker:SetPoint("LEFT", r.health, "LEFT", 1, 0)
    if r.raidMarker.SetDrawLayer then r.raidMarker:SetDrawLayer("OVERLAY", 7) end
    r.raidMarker:Hide()
    r.role = CreateText(r.health, 9, "LEFT"); r.role:SetPoint("TOPLEFT", r.health, "TOPLEFT", 2, -1); r.role:SetWidth(14)
    r.name = CreateText(r.health, 10, "LEFT"); r.name:SetPoint("TOPLEFT", r.health, "TOPLEFT", 16, -1); r.name:SetWidth(91)
    r.hp = CreateText(r.health, 9, "RIGHT"); r.hp:SetPoint("TOPRIGHT", r.health, "TOPRIGHT", -2, -1); r.hp:SetWidth(34)
    r.debuffs = {}
    for i = 1, 5 do local d = CreateDebuffIcon(r, i); d:SetWidth(AURA_ICON_SIZE); d:SetHeight(AURA_ICON_SIZE); r.debuffs[i] = d end
    r.buffs = {}
    for i = 1, MAX_DISPLAY_BUFFS do local b = CreateBuffIcon(r, i); b:SetWidth(AURA_ICON_SIZE); b:SetHeight(AURA_ICON_SIZE); r.buffs[i] = b end
    r.status = CreateText(r.health, 9, "CENTER"); r.status:SetPoint("CENTER", r.health, "CENTER", 0, 0); r.status:SetWidth(70); r.status:SetTextColor(1.0, 0.35, 0.25)
    r.spells = {}
    for i = 1, MAX_SPELL_SLOTS do r.spells[i] = CreateSpellButton(r, i) end
    r:Hide(); r.index = index
    return r
end

local TEST_DATA = {
    { name="Overlord", hp=82, role="TANK", marker=1, buffs={{name="Protective Shield",icon="Interface\\Icons\\Spell_Holy_PowerWordShield",duration=18},{name="Renewing Heal",icon="Interface\\Icons\\Spell_Holy_Renew",duration=11}}, debuffs={{name="Crushing Bleed",type="Bleed",icon="Interface\\Icons\\Ability_Gouge",duration=14},{name="Foul Disease",type="Disease",icon="Interface\\Icons\\Spell_Shadow_AbominationExplosion",duration=20}} },
    { name="Moonheals", hp=54, role="HEALER", buffs={{name="Regrowth",icon="Interface\\Icons\\Spell_Nature_ResistNature",duration=9}}, debuffs={{name="Hexing Curse",type="Curse",icon="Interface\\Icons\\Spell_Shadow_AntiShadow",duration=11}} },
    { name="Venoheal", hp=68, role="HEALER", buffs={{name="Healing Ward",icon="Interface\\Icons\\INV_Spear_04",duration=22}}, debuffs={{name="Toxic Venom",type="Poison",icon="Interface\\Icons\\Ability_PoisonSting",duration=8}} },
    { name="RaidDPS", hp=37, role="DAMAGER", buffs={}, debuffs={{name="Arcane Affliction",type="Magic",icon="Interface\\Icons\\Spell_Holy_DispelMagic",duration=6}} },
    { name="Guildmate", hp=100, role="DAMAGER", buffs={{name="Absorb Shield",icon="Interface\\Icons\\Spell_Holy_DevotionAura",duration=25}}, debuffs={} },
}

local function UpdateTestRow(r, data)
    r.unitToken = nil
    if not IsInCombatSafe() then
        r:Show()
    elseif not r:IsShown() then
        return
    end
    r:SetAlpha(1)
    r.health:SetMinMaxValues(0, 100)
    r.health:SetValue(data.hp)
    r.health:SetStatusBarColor(0.10, 0.34, 0.20)
    r.name:SetText(data.name)
    r.hp:SetText(data.hp .. "%")
    r.role:SetText(data.role == "TANK" and "T" or (data.role == "HEALER" and "H" or "D"))
    UpdateRaidTargetMarker(r, nil, data.marker)
    r.status:SetText("TEST")
    local active = {}
    for i = 1, 5 do
        local td = data.debuffs[i]
        local aura
        if td then
            aura = {name=td.name, type=td.type, icon=td.icon, count=0, expiration=GetTime()+td.duration, index=i}
            active[td.type] = true
        end
        UpdateDebuffIcon(r.debuffs[i], aura, nil, true)
    end
    for i = 1, MAX_DISPLAY_BUFFS do
        local tb = (GetDB().showBuffIcons ~= false) and data.buffs and data.buffs[i]
        local aura
        if tb then
            aura = {name=tb.name, icon=tb.icon, count=0, duration=tb.duration, expiration=GetTime()+tb.duration, index=i}
        end
        UpdateBuffIcon(r.buffs[i], aura, nil, true)
    end
    local visibleCount = ClampSpellButtonCount(GetDB().spellButtonCount)
    for i = 1, visibleCount do
        UpdateSpellButton(r.spells[i], nil, GetDB().spellSlots[i], active, true, nil)
        if not IsInCombatSafe() then
            r.spells[i]:SetAttribute("type1", nil)
            r.spells[i]:SetAttribute("unit", nil)
            r.spells[i]:Disable()
        end
    end
    -- Keep the player row neutral. Cleanse urgency belongs only on the exact
    -- spell button that can remove the active debuff; never flash/highlight the
    -- whole person's row.
    r:SetBackdropBorderColor(0.14, 0.18, 0.24, 0.85)
end

function CoAHealAssistInternal.GetUnitAbsorbAmount(unit)
    if not unit or not UnitExists(unit) then return 0 end
    if type(UnitGetTotalAbsorbs) == "function" then
        local ok, value = pcall(UnitGetTotalAbsorbs, unit)
        if ok then return math.max(0, tonumber(value) or 0) end
    end
    return 0
end

function CoAHealAssistInternal.UpdateShieldOverlay(row, unit, hp, maxhp)
    if not row or not row.shieldOverlay then return end
    local db = GetDB()
    if not db.showShieldOverlay or not unit or not UnitExists(unit) then
        if row.shieldVisible then
            row.shieldOverlay:Hide()
            if row.shieldEdge then row.shieldEdge:Hide() end
            row.shieldVisible = false
        end
        row.cachedAbsorb = 0
        return
    end

    hp = math.max(0, tonumber(hp) or 0)
    maxhp = math.max(1, tonumber(maxhp) or 1)

    -- Ascension can fire many UNIT_AURA/UNIT_HEALTH events for a single CoA
    -- skill. UnitGetTotalAbsorbs is therefore deliberately throttled per row.
    -- Reuse the cached amount between samples; health-bar geometry can still
    -- update immediately without hammering the client absorb API.
    local now = GetTime()
    local absorb = tonumber(row.cachedAbsorb) or 0
    if not row.lastAbsorbQuery or (now - row.lastAbsorbQuery) >= 0.20 then
        row.lastAbsorbQuery = now
        absorb = CoAHealAssistInternal.GetUnitAbsorbAmount(unit)
        row.cachedAbsorb = absorb
    end

    if absorb <= 0 then
        if row.shieldVisible then
            row.shieldOverlay:Hide()
            if row.shieldEdge then row.shieldEdge:Hide() end
            row.shieldVisible = false
        end
        return
    end

    local barWidth = tonumber(row.health:GetWidth()) or (UNIT_PANEL_WIDTH - 4)
    local hpFrac = math.min(1, hp / maxhp)
    local absorbFrac = math.min(1, absorb / maxhp)
    local rightFrac = math.min(1, hpFrac + absorbFrac)
    local leftFrac = math.max(0, rightFrac - absorbFrac)
    local width = math.max(1, (rightFrac - leftFrac) * barWidth)
    local x = leftFrac * barWidth

    -- Avoid repeating ClearAllPoints/SetPoint work when a burst of events
    -- reports the same shield geometry over and over.
    if not row.shieldVisible or math.abs((tonumber(row.shieldLastX) or -9999) - x) >= 0.5 or math.abs((tonumber(row.shieldLastWidth) or -9999) - width) >= 0.5 then
        row.shieldOverlay:ClearAllPoints()
        row.shieldOverlay:SetPoint("TOPLEFT", row.health, "TOPLEFT", x, 0)
        row.shieldOverlay:SetPoint("BOTTOMLEFT", row.health, "BOTTOMLEFT", x, 0)
        row.shieldOverlay:SetWidth(width)
        row.shieldLastX = x
        row.shieldLastWidth = width
    end
    if not row.shieldVisible then
        row.shieldOverlay:Show()
        if row.shieldEdge then
            row.shieldEdge:ClearAllPoints()
            row.shieldEdge:SetPoint("TOPLEFT", row.shieldOverlay, "TOPRIGHT", -1, 0)
            row.shieldEdge:SetPoint("BOTTOMLEFT", row.shieldOverlay, "BOTTOMRIGHT", -1, 0)
            row.shieldEdge:Show()
        end
        row.shieldVisible = true
    end
end

local function UpdateHealthStatusRow(r, unit)
    if not unit or not UnitExists(unit) then
        if not IsInCombatSafe() then r:Hide() end
        return
    end
    r.unitToken = unit
    if not IsInCombatSafe() then
        r:Show()
    elseif not r:IsShown() then
        return
    end

    local hp = UnitHealth(unit) or 0
    local maxhp = UnitHealthMax(unit) or 1
    if maxhp <= 0 then maxhp = 1 end
    local pct = math.floor((hp / maxhp) * 100 + 0.5)
    r.health:SetMinMaxValues(0, maxhp)
    r.health:SetValue(hp)
    local cr, cg, cb = GetClassColor(unit)
    r.health:SetStatusBarColor(cr * 0.48, cg * 0.48, cb * 0.48)
    CoAHealAssistInternal.UpdateShieldOverlay(r, unit, hp, maxhp)
    r.name:SetText(UnitName(unit) or unit)
    r.hp:SetText(pct .. "%")

    local role = GetRole(unit)
    if role == "TANK" then r.role:SetText("T")
    elseif role == "HEALER" then r.role:SetText("H")
    elseif role == "DAMAGER" then r.role:SetText("D")
    else r.role:SetText("") end
    UpdateRaidTargetMarker(r, unit)

    local status = ""
    local alpha = 1
    if UnitIsDeadOrGhost(unit) then
        status = "DEAD"
        alpha = 0.45
    elseif not UnitIsConnected(unit) then
        status = "OFFLINE"
        alpha = 0.35
    elseif UnitInRange and unit ~= "player" then
        local inRange = UnitInRange(unit)
        if not inRange then
            status = "RANGE"
            alpha = 0.55
        end
    end
    r.status:SetText(status)
    r:SetAlpha(alpha)
end

local function UpdateAuraRow(r, unit)
    if not unit or not UnitExists(unit) or not r then return end

    -- Shield application/removal often arrives as UNIT_AURA rather than a
    -- health event, so refresh the absorb layer here too.
    CoAHealAssistInternal.UpdateShieldOverlay(r, unit, UnitHealth(unit) or 0, UnitHealthMax(unit) or 1)

    local debuffs = CollectDebuffs(unit)
    local helpfulMap, helpfulList = CollectHelpfulAuras(unit)
    local activeTypes = {}
    for i = 1, #debuffs do activeTypes[debuffs[i].type] = true end

    r.cachedHelpfulMap = helpfulMap
    r.cachedHelpfulList = helpfulList
    r.cachedActiveTypes = activeTypes
    r.cachedDebuffs = debuffs

    for i = 1, 5 do UpdateDebuffIcon(r.debuffs[i], debuffs[i], unit, false) end

    -- Refresh spell buttons before the helpful-aura strip. The spell button is
    -- the one texture source we already know renders correctly on Ascension, so
    -- v0.8.8 lets the buff strip copy from it after trackedAura is established.
    r:SetBackdropBorderColor(0.14, 0.18, 0.24, 0.85)
    local visibleCount = ClampSpellButtonCount(GetDB().spellButtonCount)
    for i = 1, visibleCount do
        UpdateSpellButton(r.spells[i], unit, GetDB().spellSlots[i], activeTypes, false, helpfulMap)
    end
    -- v0.9.1: Build the green helpful-aura strip DIRECTLY from the configured
    -- spell buttons that are already tracking an active aura. This is simpler,
    -- faster, and deterministic: tracker slot N always uses Heal Assist spell
    -- slot N's icon, while the live aura supplies only the timer/stack data.
    -- Generic UnitBuff entries are intentionally not added here because custom
    -- CoA auras frequently have missing/transparent textures and no trustworthy
    -- source-spell identity.
    local buffs = {}
    if GetDB().showBuffIcons ~= false then
        for slotIndex = 1, visibleCount do
            local spellButton = r.spells[slotIndex]
            local aura = spellButton and spellButton.trackedAura
            if aura then
                aura.sourceSlot = slotIndex
                buffs[#buffs + 1] = aura
                if #buffs >= MAX_DISPLAY_BUFFS then break end
            end
        end
    end
    r.cachedBuffs = buffs
    for i = 1, MAX_DISPLAY_BUFFS do UpdateBuffIcon(r.buffs[i], buffs[i], unit, false) end
end

local function UpdateRealRow(r, unit)
    UpdateHealthStatusRow(r, unit)
    UpdateAuraRow(r, unit)
end

local function ForEachAssignedMatchingRow(unit, callback)
    if not unit or type(callback) ~= "function" then return end
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local assigned = assignedUnits[i]
        local matches = (assigned == unit)
        if not matches and assigned and UnitIsUnit and UnitExists and UnitExists(assigned) and UnitExists(unit) then
            local ok, same = pcall(UnitIsUnit, assigned, unit)
            matches = ok and same
        end
        if matches and rows[i] then callback(rows[i], i, assigned) end
    end
end

local function RefreshUnitHealth(unit)
    if assignedIsTest then return end
    ForEachAssignedMatchingRow(unit, function(r, _, assigned)
        UpdateHealthStatusRow(r, assigned or unit)
    end)
end

local function RefreshUnitAura(unit)
    if assignedIsTest then return end
    ForEachAssignedMatchingRow(unit, function(r, _, assigned)
        UpdateAuraRow(r, assigned or unit)
    end)
end

local function RefreshAllCooldowns()
    if not main or not main:IsShown() then return end
    cooldownCache = {}
    if assignedIsTest then return end

    -- Cooldown events can fire often (including the GCD). Do not run the full
    -- spell-button/aura logic here; only update cooldown-specific fields.
    local db = GetDB()
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    local now = GetTime()
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local r = rows[i]
        if r and r:IsShown() then
            for slotIndex = 1, visibleCount do
                local b = r.spells[slotIndex]
                local spellName = b and b.spellName
                if b and spellName and spellName ~= "" then
                    local start, duration, enabled = GetCachedCooldown(spellName)
                    start = tonumber(start) or 0
                    duration = tonumber(duration) or 0
                    b.cooldownStart = start
                    b.cooldownDuration = duration
                    b.cooldownEnabled = enabled
                    b.cooldownIsGCDOnly = duration > 0 and duration <= 1.6
                    local remaining = (start > 0 and duration > 0) and ((start + duration) - now) or 0
                    if remaining > 0 and (db.showGCD or not b.cooldownIsGCDOnly) then
                        SetCooldownVisual(b.cooldown, start, duration)
                        b.cooldownText:SetText(FormatTime(remaining))
                    else
                        ClearCooldownVisual(b.cooldown)
                        b.cooldownText:SetText("")
                    end
                end
            end
        end
    end
end

RefreshSpellUsability = function(force)
    if not main then return end
    local db = GetDB()
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    local changedSlots = {}

    -- IsUsableSpell is queried once per configured slot, not once per player.
    -- The result is then reused across every visible row, keeping this cheap in
    -- 25/40-player raids.
    for slotIndex = 1, visibleCount do
        local spellName = NormalizeSpell(db.spellSlots[slotIndex].spell)
        local noMana = false
        if spellName and spellName ~= "" then noMana = SpellNeedsMana(spellName) end
        if force or spellManaCache[slotIndex] ~= noMana then
            spellManaCache[slotIndex] = noMana
            changedSlots[slotIndex] = true
        end
    end
    for slotIndex = visibleCount + 1, MAX_SPELL_SLOTS do spellManaCache[slotIndex] = false end

    if not next(changedSlots) then return end
    local rowCount = math.min(assignedCount or 0, MAX_UNIT_ROWS)
    for i = 1, rowCount do
        local r = rows[i]
        if r and r.spells then
            for slotIndex in pairs(changedSlots) do
                local b = r.spells[slotIndex]
                if b then SetSpellManaUnavailable(b, spellManaCache[slotIndex]) end
            end
        end
    end
end

local function RefreshSpellCharges(force)
    if not main then return end
    local db = GetDB()
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    local changedSlots = {}
    local discoverySlot = CoAHealAssistInternal.chargeDiscoverySlot or 1
    if discoverySlot > visibleCount then discoverySlot = 1 end
    for slotIndex = 1, visibleCount do
        local slot = db.spellSlots[slotIndex]
        local spellName, spellID = NormalizeSpell(slot and slot.spell or "")
        local current, maximum, start, duration
        local allowDeep = force or slotIndex == discoverySlot
        if spellName and spellName ~= "" then current, maximum, start, duration = QuerySpellCharges(spellName, spellID, slotIndex, allowDeep) end
        local old = spellChargeCache[slotIndex]
        if force or not old or old.current ~= current or old.maximum ~= maximum or old.start ~= start or old.duration ~= duration then
            spellChargeCache[slotIndex] = { current=current, maximum=maximum, start=start or 0, duration=duration or 0 }
            changedSlots[slotIndex] = true
        end
    end
    if not force and visibleCount > 0 then
        CoAHealAssistInternal.chargeDiscoverySlot = (discoverySlot % visibleCount) + 1
    end
    for slotIndex = visibleCount + 1, MAX_SPELL_SLOTS do spellChargeCache[slotIndex] = nil end
    if not next(changedSlots) then return end
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local r = rows[i]
        if r and r.spells then
            for slotIndex in pairs(changedSlots) do
                local b = r.spells[slotIndex]
                local info = spellChargeCache[slotIndex]
                if b and b.chargeText then
                    if info and info.current ~= nil and info.maximum and info.maximum > 1 then b.chargeText:SetText(tostring(info.current)) else b.chargeText:SetText("") end
                end
            end
        end
    end
end

local function RefreshCachedTimers()
    if not main or not main:IsShown() then return end
    local now = GetTime()
    local db = GetDB()
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local r = rows[i]
        if r and r:IsShown() then
            for n = 1, 5 do
                local f = r.debuffs[n]
                local a = f and f.currentAura
                if f and a then
                    local remaining = (tonumber(a.expiration) or 0) - now
                    f.timer:SetText(remaining > 0 and FormatTime(remaining) or "")
                end
            end
            for n = 1, MAX_DISPLAY_BUFFS do
                local f = r.buffs[n]
                local a = f and f.currentAura
                if f and a then
                    local exp = tonumber(a.expiration) or 0
                    local duration = tonumber(a.duration) or 0
                    local remaining = exp > 0 and (exp - now) or 0
                    if remaining > 0 then f.timer:SetText(FormatTime(remaining))
                    elseif duration > 0 then f.timer:SetText("0")
                    else f.timer:SetText("ON") end
                end
            end
            for n = 1, visibleCount do
                local b = r.spells[n]
                if b and b.spellName then
                    local start = tonumber(b.cooldownStart) or 0
                    local duration = tonumber(b.cooldownDuration) or 0
                    local remaining = (start > 0 and duration > 0) and ((start + duration) - now) or 0
                    if remaining > 0 and (db.showGCD or not b.cooldownIsGCDOnly) then
                        b.cooldownText:SetText(FormatTime(remaining))
                    else
                        b.cooldownText:SetText("")
                        if remaining <= 0 then ClearCooldownVisual(b.cooldown) end
                    end
                    local a = b.trackedAura
                    if a and (tonumber(a.expiration) or 0) > 0 then
                        local auraRemaining = (tonumber(a.expiration) or 0) - now
                        b.auraText:SetText(auraRemaining > 0 and FormatTime(auraRemaining) or "")
                    elseif a then
                        b.auraText:SetText("ON")
                    else
                        b.auraText:SetText("")
                    end
                end
            end
        end
    end
end

local function RefreshAllStatus()
    if not main or not main:IsShown() or assignedIsTest then return end
    for i = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
        local unit = assignedUnits[i]
        if unit and UnitExists(unit) then UpdateHealthStatusRow(rows[i], unit) end
    end
end

local function RefreshOneAuraFallback()
    if not main or not main:IsShown() or assignedIsTest or (assignedCount or 0) <= 0 then return end
    if fallbackRowIndex > assignedCount then fallbackRowIndex = 1 end
    local i = fallbackRowIndex
    fallbackRowIndex = fallbackRowIndex + 1
    local unit = assignedUnits[i]
    if unit and UnitExists(unit) then UpdateAuraRow(rows[i], unit) end
end

local function PulseActiveCleanseAlerts()
    local now = GetTime()
    if next(activeCleanseAlerts) then
        local phase = (math.sin(now * 14) + 1) / 2
        local pulse = 0.72 + (0.28 * phase)
        for alert in pairs(activeCleanseAlerts) do
            if alert and alert.active then
                alert:SetAlpha(pulse)
                if alert.fill and alert.fill.SetAlpha then alert.fill:SetAlpha(0.72 + (0.28 * phase)) end
            else
                activeCleanseAlerts[alert] = nil
            end
        end
    end

    -- Proc-ready highlights are steady in v0.9.3. Detection still uses the
    -- cached action button/event state and debounce, but the Heal Assist visual
    -- itself does not animate. Keeping this table empty also removes needless
    -- per-frame proc alpha work in large groups.
end


function CoAHealAssistInternal.RefreshSpellProcGlows(force)
    if not main or not main:IsShown() then return end
    local db = GetDB()
    local enabled = db.showProcGlow ~= false
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    local discoverySlot = CoAHealAssistInternal.procDiscoverySlot or 1
    if discoverySlot > visibleCount then discoverySlot = 1 end
    local now = GetTime and GetTime() or 0
    local holdSeconds = tonumber(CoAHealAssistInternal.procHoldSeconds) or 0.65

    for slotIndex = 1, visibleCount do
        local slot = db.spellSlots and db.spellSlots[slotIndex]
        local spellName, spellID
        if slot then
            spellName, spellID = NormalizeSpell(slot.spell)
            if tonumber(slot.spellID) then spellID = tonumber(slot.spellID) end
        end
        -- Normal slots use cached/direct checks only. Exactly one slot per pass
        -- is allowed to perform the expensive Ascension overlay discovery.
        local allowDeep = (not force) and slotIndex == discoverySlot
        local rawReady = enabled and spellName and CoAHealAssistInternal.QuerySpellProcReady(spellName, spellID, slotIndex, allowDeep) or false
        local ready = rawReady and true or false

        -- Ascension's gold activation border pulses. During the dim phase the
        -- same proc can briefly look inactive even though it is still usable.
        -- Require a continuous idle period before clearing an already-lit proc.
        if ready then
            CoAHealAssistInternal.procOffSince[slotIndex] = nil
        elseif enabled and CoAHealAssistInternal.spellProcCache[slotIndex] == true then
            local offSince = CoAHealAssistInternal.procOffSince[slotIndex]
            if not offSince then
                CoAHealAssistInternal.procOffSince[slotIndex] = now
                ready = true
            elseif (now - offSince) < holdSeconds then
                ready = true
            end
        else
            CoAHealAssistInternal.procOffSince[slotIndex] = nil
        end

        local changed = CoAHealAssistInternal.spellProcCache[slotIndex] ~= ready
        CoAHealAssistInternal.spellProcCache[slotIndex] = ready and true or false
        if changed or force then
            for rowIndex = 1, math.min(assignedCount or 0, MAX_UNIT_ROWS) do
                local row = rows[rowIndex]
                local button = row and row.spells and row.spells[slotIndex]
                if button then CoAHealAssistInternal.SetSpellProcAlert(button, ready) end
            end
        end
    end
    if not force and visibleCount > 0 then
        CoAHealAssistInternal.procDiscoverySlot = (discoverySlot % visibleCount) + 1
    end
    for slotIndex = visibleCount + 1, MAX_SPELL_SLOTS do
        CoAHealAssistInternal.spellProcCache[slotIndex] = false
        CoAHealAssistInternal.procOffSince[slotIndex] = nil
    end
end

local function BuildUnitList()
    local db = GetDB()
    if db.testMode then
        return {"test1","test2","test3","test4","test5"}, true, {}, {"main","main","main","main","main"}
    end

    local frames = db.frames or DEFAULTS.frames
    local groups = frames.raidGroups or DEFAULTS.frames.raidGroups
    local units, unitGroups, unitPanels, seen = {}, {}, {}, {}

    local function AddUnit(unit, subgroup, panelKey)
        if not unit or not UnitExists or not UnitExists(unit) then return end
        if #units >= MAX_UNIT_ROWS then return end
        local identity
        if UnitGUID then identity = UnitGUID(unit) end
        if not identity or identity == "" then identity = UnitDisplayName(unit) or unit end
        panelKey = panelKey or "main"
        local key = tostring(identity) .. "::" .. tostring(panelKey)
        if seen[key] then return end
        seen[key] = true
        table.insert(units, unit)
        unitGroups[#units] = tonumber(subgroup) or 0
        unitPanels[#units] = panelKey
    end

    local function NonTankRoleSelected(unit)
        local role = GetRole(unit)
        if role == "HEALER" and frames.healers then return true end
        if role == "DAMAGER" and frames.damagers then return true end
        return false
    end

    local raidCount = SafeRaidCount()
    local partyCount = SafePartyCount()

    if raidCount and raidCount > 0 then
        local raidEntries = {}
        for i = 1, math.min(raidCount, 40) do
            local unit = "raid" .. i
            local subgroup = SafeRaidSubgroup(i)
            raidEntries[#raidEntries + 1] = {
                unit = unit,
                subgroup = subgroup,
                rosterIndex = i,
                raidRole = SafeRaidRosterRole(i),
            }
        end

        table.sort(raidEntries, function(a, b)
            if a.subgroup == b.subgroup then return a.rosterIndex < b.rosterIndex end
            return a.subgroup < b.subgroup
        end)

        -- When "Me" is enabled, automatically show the ENTIRE raid subgroup
        -- containing the player. This follows raid-leader moves between Group
        -- 1-8 on RAID_ROSTER_UPDATE, so the user never has to manually find and
        -- enable the group they were assigned to.
        local myRaidSubgroup = nil
        if frames.me then
            myRaidSubgroup = PlayerRaidSubgroup()
            if not myRaidSubgroup then
                for _, entry in ipairs(raidEntries) do
                    if UnitIsUnit and UnitExists(entry.unit) then
                        local ok, same = pcall(UnitIsUnit, entry.unit, "player")
                        if ok and same then myRaidSubgroup = entry.subgroup; break end
                    end
                end
            end
        end

        -- Normal raid-group rows. Tank selection is deliberately NOT treated as
        -- a group override; Tanks has its own independent Healium-style frame.
        -- "Me" is a current-group override and therefore includes all members
        -- of the player's actual subgroup, not just the player's own row.
        for _, entry in ipairs(raidEntries) do
            local unit, subgroup = entry.unit, entry.subgroup
            local byGroup = groups[subgroup] and true or false
            local byMyGroup = frames.me and myRaidSubgroup and subgroup == myRaidSubgroup
            local byFriend = frames.friends and IsConfiguredFriendUnit(unit)
            if byGroup or byMyGroup or byFriend or NonTankRoleSelected(unit) then
                AddUnit(unit, subgroup, "group" .. tostring(subgroup))
            end
        end

        -- Fallback for unusual/custom clients where the player cannot be found
        -- in raidN units. Normally the byMyGroup pass above already added them.
        if frames.me and not myRaidSubgroup then
            AddUnit("player", 1, "group1")
        end

        -- Pets use their own independent Healium-style frame. They are never
        -- mixed into the owner's normal raid subgroup panel.
        if frames.pets then
            for _, entry in ipairs(raidEntries) do
                AddUnit("raidpet" .. entry.rosterIndex, entry.subgroup, "pet")
            end
        end

        -- Dedicated Main Tank/Tank frame. These are intentional duplicates of
        -- the subgroup rows, just like Healium's role frames.
        if frames.tanks then
            for _, entry in ipairs(raidEntries) do
                if GetRole(entry.unit) == "TANK" then
                    AddUnit(entry.unit, entry.subgroup, "tank")
                end
            end
        end
    elseif partyCount and partyCount > 0 then
        -- "Me" means "my current group": in a dungeon/party it automatically
        -- includes the player plus every party member, even if Party is off.
        if frames.me then
            AddUnit("player", 0, "main")
            for i = 1, partyCount do AddUnit("party" .. i, 0, "main") end
        elseif frames.party then
            for i = 1, partyCount do AddUnit("party" .. i, 0, "main") end
        end
        for i = 0, partyCount do
            local unit = (i == 0) and "player" or ("party" .. i)
            local role = GetRole(unit)
            if (frames.friends and IsConfiguredFriendUnit(unit))
                or (frames.tanks and role == "TANK")
                or (frames.healers and role == "HEALER")
                or (frames.damagers and role == "DAMAGER") then
                AddUnit(unit, 0, "main")
            end
        end
        if frames.pets then
            AddUnit("pet", 0, "pet")
            for i = 1, partyCount do AddUnit("partypet" .. i, 0, "pet") end
        end
    else
        if frames.me then AddUnit("player", 0, "main") end
        if frames.pets then AddUnit("pet", 0, "pet") end
    end

    return units, false, unitGroups, unitPanels
end

local function SavedPanelPosition(kind, index)
    local frames = GetDB().frames or {}
    if kind == "group" then
        frames.raidGroupPositions = frames.raidGroupPositions or {}
        return frames.raidGroupPositions[index]
    elseif kind == "tank" then
        return frames.tankPosition
    elseif kind == "pet" then
        return frames.petPosition
    end
    return nil
end

local function StorePanelPosition(panel, kind, index)
    if not panel then return end

    -- Save the exact anchor generated by StartMoving instead of converting the
    -- panel center through the scaled main frame. The old center conversion is
    -- what caused frames to jump/snap when the mouse was released.
    local point, relativeTo, relativePoint, x, y = panel:GetPoint(1)
    if not point then return end
    local data = {
        point = point,
        relativePoint = relativePoint or point,
        x = tonumber(x) or 0,
        y = tonumber(y) or 0,
        manual = true,
    }

    -- Roster panels are direct UIParent children, so retaining the exact point
    -- and offsets is stable across rebuilds and toolbar movement.
    panel:ClearAllPoints()
    panel:SetPoint(data.point, UIParent, data.relativePoint, data.x, data.y)

    local frames = GetDB().frames
    if kind == "group" then
        frames.raidGroupPositions = frames.raidGroupPositions or {}
        frames.raidGroupPositions[index] = data
    elseif kind == "tank" then
        frames.tankPosition = data
    elseif kind == "pet" then
        frames.petPosition = data
    end
end

local function ApplyPanelPosition(panel, kind, index, defaultX, defaultY)
    if not panel then return end
    panel:ClearAllPoints()
    local saved = SavedPanelPosition(kind, index)
    if type(saved) == "table" and saved.point and saved.manual then
        panel:SetPoint(saved.point, UIParent, saved.relativePoint or saved.point, tonumber(saved.x) or 0, tonumber(saved.y) or 0)
    else
        -- Default positions are absolute screen positions, never anchored to the
        -- main toolbar. This avoids a circular anchor when the toolbar attaches
        -- to the player's own raid-group panel.
        local db = GetDB()
        local baseX = (tonumber(db.x) or 0) - 300
        local baseY = (tonumber(db.y) or 20) + 100
        panel:SetPoint("TOPLEFT", UIParent, "CENTER", baseX + (defaultX or 0), baseY + (defaultY or -5))
    end
end

local function AttachMainToolbarToOwnGroup(rowWidth)
    if not main then return end
    main.attachedPanel = nil
    main.attachedPanelKind = nil
    main.attachedPanelIndex = nil

    local subgroup = PlayerRaidSubgroup()
    local panel = subgroup and raidGroupPanels[subgroup] or nil
    if panel and panel:IsShown() then
        main:ClearAllPoints()
        main:SetPoint("BOTTOMLEFT", panel, "TOPLEFT", 0, 0)
        main:SetWidth(1)
        main:SetHeight(1)
        main:SetBackdropColor(0, 0, 0, 0)
        main:SetBackdropBorderColor(0, 0, 0, 0)
        main.attachedPanel = panel
        main.attachedPanelKind = "group"
        main.attachedPanelIndex = subgroup
        return true
    end

    -- If the player's own group is unavailable, keep the normal saved toolbar
    -- position instead of snapping it to an arbitrary raid group.
    ApplyMainPosition()
    main:SetWidth(1)
    main:SetHeight(1)
    main:SetBackdropColor(0, 0, 0, 0)
    main:SetBackdropBorderColor(0, 0, 0, 0)
    return false
end

local function HideRosterPanelsNow()
    for g = 1, 8 do
        if raidGroupPanels[g] then raidGroupPanels[g]:Hide() end
    end
    if tankPanel then tankPanel:Hide() end
    if petPanel then petPanel:Hide() end
end

local function LayoutRows(count, isRaid, unitGroups, unitPanels)
    if not main then return end
    local db = GetDB()
    local visibleCount = ClampSpellButtonCount(db.spellButtonCount)
    local buttonSize = ClampButtonSize(db.buttonSize)
    local buttonWidth = SpellButtonWidth(buttonSize)
    local buttonSpacing = ClampButtonSpacing(db.buttonSpacing)
    local spellStartX = UNIT_PANEL_WIDTH + 3
    local rowWidth = spellStartX + (visibleCount * buttonWidth) + (math.max(visibleCount - 1, 0) * buttonSpacing) + 3
    local rowHeight = math.max(26, buttonSize)
    local groupHeaderHeight = 20

    -- Roster panels are independent UIParent windows. Give them the same scale
    -- as the addon without inheriting main-frame scale/position math.
    for g = 1, 8 do
        if raidGroupPanels[g] then raidGroupPanels[g]:SetScale(db.scale or 0.90) end
    end
    if tankPanel then tankPanel:SetScale(db.scale or 0.90) end
    if petPanel then petPanel:SetScale(db.scale or 0.90) end

    for i = 1, MAX_UNIT_ROWS do
        local r = rows[i]
        if r then
            r:SetWidth(rowWidth); r:SetHeight(rowHeight)
            r.health:SetWidth(UNIT_PANEL_WIDTH - 4); r.health:SetHeight(rowHeight - 4)
            for d = 1, 5 do
                r.debuffs[d]:ClearAllPoints()
                r.debuffs[d]:SetPoint("BOTTOMLEFT", r.health, "BOTTOMLEFT", 2 + ((d - 1) * (AURA_ICON_SIZE + AURA_ICON_SPACING)), 1)
            end
            for a = 1, MAX_DISPLAY_BUFFS do
                r.buffs[a]:ClearAllPoints()
                r.buffs[a]:SetPoint("BOTTOMRIGHT", r.health, "BOTTOMRIGHT", -2 - ((a - 1) * (AURA_ICON_SIZE + AURA_ICON_SPACING)), 1)
            end
            for slotIndex = 1, MAX_SPELL_SLOTS do
                local b = r.spells[slotIndex]
                b:ClearAllPoints()
                b:SetPoint("LEFT", r, "LEFT", spellStartX + ((slotIndex - 1) * (buttonWidth + buttonSpacing)), 0)
                b:SetWidth(buttonWidth); b:SetHeight(buttonSize)
                local iconSize = math.max(12, buttonSize - 4)
                b.icon:SetWidth(iconSize); b.icon:SetHeight(iconSize)
                b.cooldown:SetWidth(iconSize); b.cooldown:SetHeight(iconSize)
                b.cooldownText:ClearAllPoints(); b.cooldownText:SetPoint("CENTER", b, "LEFT", 2 + math.floor(iconSize / 2), 0)
                b.slotText:ClearAllPoints(); b.slotText:SetPoint("CENTER", b, "LEFT", 2 + math.floor(iconSize / 2), 0)
                if slotIndex <= visibleCount then b:Show() else b:Hide() end
            end
            r:ClearAllPoints()
        end
    end

    for g = 1, 8 do
        if raidGroupPanels[g] then raidGroupPanels[g]:Hide() end
    end
    if tankPanel then tankPanel:Hide() end
    if petPanel then petPanel:Hide() end

    if isRaid then
        unitGroups = unitGroups or {}
        unitPanels = unitPanels or {}
        local frameSettings = db.frames or DEFAULTS.frames
        local selectedGroups = frameSettings.raidGroups or DEFAULTS.frames.raidGroups
        local groupCounts, groupRowPos = {}, {}
        for g = 1, 8 do groupCounts[g] = 0; groupRowPos[g] = 0 end
        local tankCount, tankRowPos = 0, 0
        local petCount, petRowPos = 0, 0

        for i = 1, count do
            local key = unitPanels[i]
            if key == "tank" then
                tankCount = tankCount + 1
            elseif key == "pet" then
                petCount = petCount + 1
            else
                local g = tonumber(unitGroups[i]) or tonumber(string.match(tostring(key or ""), "^group(%d+)$")) or 1
                if g < 1 or g > 8 then g = 1 end
                groupCounts[g] = groupCounts[g] + 1
            end
        end

        -- Each checked raid group is now its own movable/closable window.
        -- Unsaved frames start in a tidy two-column grid below the main toolbar;
        -- once moved, their individual positions are preserved.
        local defaultColumnWidth = rowWidth + 6
        local colY = { -5, -5 }
        local visibleOrdinal = 0
        for g = 1, 8 do
            if selectedGroups[g] or groupCounts[g] > 0 then
                visibleOrdinal = visibleOrdinal + 1
                local panel = raidGroupPanels[g]
                if panel then
                    local panelRows = math.max(groupCounts[g], 1)
                    local panelHeight = groupHeaderHeight + (panelRows * (rowHeight + 1)) + 4
                    panel:SetWidth(rowWidth); panel:SetHeight(panelHeight)
                    panel.title:SetText("Group " .. tostring(g))
                    if groupCounts[g] == 0 then panel.emptyText:SetText("Empty"); panel.emptyText:Show() else panel.emptyText:Hide() end

                    if not SavedPanelPosition("group", g) then
                        local col = ((visibleOrdinal - 1) % 2) + 1
                        local x = (col - 1) * defaultColumnWidth
                        ApplyPanelPosition(panel, "group", g, x, colY[col])
                        colY[col] = colY[col] - panelHeight - 6
                    else
                        ApplyPanelPosition(panel, "group", g, 0, -5)
                    end
                    panel:Show()
                end
            end
        end

        -- Dedicated Tank frame, independent from the subgroup frames. Main Tank
        -- assignments from the old raid roster API are included here.
        if tankPanel and (frameSettings.tanks or tankCount > 0) then
            local panelRows = math.max(tankCount, 1)
            local panelHeight = groupHeaderHeight + (panelRows * (rowHeight + 1)) + 4
            tankPanel:SetWidth(rowWidth); tankPanel:SetHeight(panelHeight)
            tankPanel.title:SetText("Tanks / Main Tank")
            if tankCount == 0 then tankPanel.emptyText:SetText("Empty"); tankPanel.emptyText:Show() else tankPanel.emptyText:Hide() end
            if not SavedPanelPosition("tank") then
                local tankDefaultY = math.min(colY[1] or -5, colY[2] or -5) - 6
                ApplyPanelPosition(tankPanel, "tank", nil, 0, tankDefaultY)
            else
                ApplyPanelPosition(tankPanel, "tank", nil, 0, -5)
            end
            tankPanel:Show()
        end

        -- Dedicated Pets frame, independent from raid subgroup panels and Tanks.
        -- This mirrors Healium: pet rows never consume space inside Group 1-8.
        if petPanel and (frameSettings.pets or petCount > 0) then
            local panelRows = math.max(petCount, 1)
            local panelHeight = groupHeaderHeight + (panelRows * (rowHeight + 1)) + 4
            petPanel:SetWidth(rowWidth); petPanel:SetHeight(panelHeight)
            petPanel.title:SetText("Pets")
            if petCount == 0 then petPanel.emptyText:SetText("Empty"); petPanel.emptyText:Show() else petPanel.emptyText:Hide() end
            if not SavedPanelPosition("pet") then
                local petDefaultY = math.min(colY[1] or -5, colY[2] or -5) - 6
                if tankPanel and tankPanel:IsShown() then
                    petDefaultY = petDefaultY - (tankPanel:GetHeight() or 0) - 6
                end
                ApplyPanelPosition(petPanel, "pet", nil, 0, petDefaultY)
            else
                ApplyPanelPosition(petPanel, "pet", nil, 0, -5)
            end
            petPanel:Show()
        end

        for i = 1, count do
            local r = rows[i]
            local key = unitPanels[i]
            if r then
                if key == "tank" and tankPanel then
                    tankRowPos = tankRowPos + 1
                    if r:GetParent() ~= tankPanel then r:SetParent(tankPanel) end
                    r:SetPoint("TOPLEFT", tankPanel, "TOPLEFT", 0, -groupHeaderHeight - ((tankRowPos - 1) * (rowHeight + 1)))
                elseif key == "pet" and petPanel then
                    petRowPos = petRowPos + 1
                    if r:GetParent() ~= petPanel then r:SetParent(petPanel) end
                    r:SetPoint("TOPLEFT", petPanel, "TOPLEFT", 0, -groupHeaderHeight - ((petRowPos - 1) * (rowHeight + 1)))
                else
                    local g = tonumber(unitGroups[i]) or tonumber(string.match(tostring(key or ""), "^group(%d+)$")) or 1
                    if g < 1 or g > 8 then g = 1 end
                    groupRowPos[g] = groupRowPos[g] + 1
                    local panel = raidGroupPanels[g]
                    if panel then
                        if r:GetParent() ~= panel then r:SetParent(panel) end
                        r:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, -groupHeaderHeight - ((groupRowPos[g] - 1) * (rowHeight + 1)))
                    end
                end
            end
        end

        -- In raids the toolbar belongs to your own five-player subgroup. It is
        -- anchored directly above that Group frame and follows whenever you move
        -- the group, so there is no separate floating bar to organize.
        AttachMainToolbarToOwnGroup(rowWidth)
    else
        main.attachedPanel = nil
        main.attachedPanelKind = nil
        main.attachedPanelIndex = nil
        ApplyMainPosition()
        SetBackdrop(main, 0.28, 0.30, 0.34, 1)

        unitPanels = unitPanels or {}
        local frameSettings = db.frames or DEFAULTS.frames
        local mainRowCount, mainRowPos = 0, 0
        local petCount, petRowPos = 0, 0
        for i = 1, count do
            if unitPanels[i] == "pet" then petCount = petCount + 1 else mainRowCount = mainRowCount + 1 end
        end

        main:SetWidth(math.max(335, 10 + rowWidth))
        main:SetHeight(6 + (math.max(mainRowCount, 1) * (rowHeight + 1)))

        if petPanel and (frameSettings.pets or petCount > 0) then
            local panelRows = math.max(petCount, 1)
            local panelHeight = groupHeaderHeight + (panelRows * (rowHeight + 1)) + 4
            petPanel:SetWidth(rowWidth); petPanel:SetHeight(panelHeight)
            petPanel.title:SetText("Pets")
            if petCount == 0 then petPanel.emptyText:SetText("Empty"); petPanel.emptyText:Show() else petPanel.emptyText:Hide() end
            if not SavedPanelPosition("pet") then
                -- Start the pet window just below the normal party/solo frame.
                petPanel:ClearAllPoints()
                petPanel:SetPoint("TOPLEFT", main, "BOTTOMLEFT", 5, -5)
            else
                ApplyPanelPosition(petPanel, "pet", nil, 0, -120)
            end
            petPanel:Show()
        end

        for i = 1, MAX_UNIT_ROWS do
            local r = rows[i]
            if r then
                r:ClearAllPoints()
                if i <= count and unitPanels[i] == "pet" and petPanel then
                    petRowPos = petRowPos + 1
                    if r:GetParent() ~= petPanel then r:SetParent(petPanel) end
                    r:SetPoint("TOPLEFT", petPanel, "TOPLEFT", 0, -groupHeaderHeight - ((petRowPos - 1) * (rowHeight + 1)))
                else
                    if i <= count then mainRowPos = mainRowPos + 1 end
                    if r:GetParent() ~= main then r:SetParent(main) end
                    r:SetPoint("TOPLEFT", main, "TOPLEFT", 5, -3 - ((math.max(mainRowPos, 1) - 1) * (rowHeight + 1)))
                end
            end
        end
    end
end

local function ApplySecureAssignments(units, isTest)
    if IsInCombatSafe() then pendingSecureRefresh = true; return end
    local visibleCount = ClampSpellButtonCount(GetDB().spellButtonCount)
    for i = 1, MAX_UNIT_ROWS do
        local unit = units[i]
        local r = rows[i]
        for slotIndex = 1, MAX_SPELL_SLOTS do
            local b = r.spells[slotIndex]
            if slotIndex > visibleCount or isTest or not unit then
                b:SetAttribute("type1", nil)
                b:SetAttribute("spell1", nil)
                b:SetAttribute("unit", nil)
                b:Enable()
            else
                SetSpellButtonSecure(b, unit, GetDB().spellSlots[slotIndex])
            end
        end
    end
    pendingSecureRefresh = false
end

RebuildUnits = function()
    if not main then return end
    cooldownCache = {}
    spellChargeCache = {}
    if IsInCombatSafe() then pendingSecureRefresh = true; return end
    local db = GetDB()
    local units, isTest, unitGroups, unitPanels = BuildUnitList()
    local raidCount = SafeRaidCount()
    local isRaid = (not isTest and raidCount > 0)
    LayoutRows(#units, isRaid, unitGroups, unitPanels)
    ApplySecureAssignments(units, isTest)
    assignedUnits = {}
    assignedPanelKeys = {}
    for i = 1, math.min(#units, MAX_UNIT_ROWS) do
        assignedUnits[i] = units[i]
        assignedPanelKeys[i] = unitPanels and unitPanels[i] or "main"
    end
    assignedCount = math.min(#units, MAX_UNIT_ROWS)
    assignedIsTest = isTest and true or false
    fallbackRowIndex = 1
    for i = 1, MAX_UNIT_ROWS do
        if i <= #units then
            if isTest then UpdateTestRow(rows[i], TEST_DATA[i]) else UpdateRealRow(rows[i], units[i]) end
        else
            rows[i]:Hide()
        end
    end
    if db.hideSolo and not isTest and #units == 1 then
        main:Hide()
        HideRosterPanelsNow()
    elseif db.shown then
        main:Show()
        -- LayoutRows already decided which roster panels should be visible.
    else
        main:Hide()
        HideRosterPanelsNow()
    end
    if RefreshSpellUsability then RefreshSpellUsability(true) end
    RefreshSpellCharges(true)
end

local function RefreshRows()
    if not main or not main:IsShown() then return end
    cooldownCache = {}
    -- Never rebuild/reorder visual units independently of the protected buttons.
    -- Use the last out-of-combat secure assignment snapshot until RebuildUnits
    -- can safely run again. This prevents a row from displaying raidA while its
    -- click-cast button is still securely bound to raidB.
    local units = assignedUnits
    local isTest = assignedIsTest
    local count = assignedCount or 0
    for i = 1, math.min(count, MAX_UNIT_ROWS) do
        if isTest then UpdateTestRow(rows[i], TEST_DATA[i]) else UpdateRealRow(rows[i], units[i]) end
    end
end

ApplyMainPosition = function()
    local db = GetDB()
    main:ClearAllPoints()
    main:SetPoint(db.point or "CENTER", UIParent, db.relativePoint or "CENTER", db.x or 0, db.y or 0)
    main:SetScale(db.scale or 0.90)
end

local function SaveMainPosition()
    local db = GetDB()
    local point, _, relativePoint, x, y = main:GetPoint(1)
    db.point = point or "CENTER"
    db.relativePoint = relativePoint or "CENTER"
    db.x = x or 0
    db.y = y or 0
end

local function ResetLayout()
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        Print("Layout can only be reset after combat.")
        return
    end
    local db = GetDB()
    db.point = DEFAULTS.point
    db.relativePoint = DEFAULTS.relativePoint
    db.x = DEFAULTS.x
    db.y = DEFAULTS.y
    db.scale = DEFAULTS.scale
    db.locked = false
    db.frames.raidGroupPositions = {}
    db.frames.tankPosition = {}
    db.frames.petPosition = {}
    ApplyMainPosition()
    RebuildUnits()
    Print("Layout reset, including Raid Group, Tank, and Pet frame positions.")
end

local function ResetButtonLayout()
    local db = GetDB()
    db.spellButtonCount = DEFAULT_SPELL_BUTTON_COUNT
    db.buttonSize = DEFAULT_BUTTON_SIZE
    db.buttonSpacing = DEFAULT_BUTTON_SPACING
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        Print("Button layout reset. It will apply when combat ends. Spell assignments were kept.")
    else
        RebuildUnits()
        Print("Button layout reset. Spell assignments were kept.")
    end
end

local function ResetSpells()
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        Print("Spell slots can only be reset after combat.")
        return
    end
    local db = GetDB()
    db.spellSlots = CopyDefaults(DEFAULTS.spellSlots)
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
    RebuildUnits()
    Print("Spell slots reset.")
end

local function ResetAll()
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        Print("Reset All can only be used after combat.")
        return
    end
    local root, key = EnsureProfileRoot()
    root.profiles[key] = CopyDefaults(DEFAULTS)
    ApplyMainPosition()
    UpdateMinimapButtonPosition(GetDB().minimap.angle)
    RefreshMinimapButtonVisibility()
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
    if RefreshFrameOptions then RefreshFrameOptions() end
    RebuildUnits()
    Print("All settings reset.")
end

function CoAHealAssistInternal.MinimapAtan2(y, x)
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
    if x < 0 and y < 0 then return math.atan(y / x) - math.pi end
    if x == 0 and y > 0 then return math.pi / 2 end
    if x == 0 and y < 0 then return -math.pi / 2 end
    return 0
end

UpdateMinimapButtonPosition = function(angle)
    if not minimapButton or not Minimap then return end
    local db = GetDB()
    angle = tonumber(angle) or tonumber(db.minimap.angle) or 225
    db.minimap.angle = angle
    local rad = math.rad(angle)
    local radius = 80
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(rad) * radius, math.sin(rad) * radius)
end

RefreshMinimapButtonVisibility = function()
    if not minimapButton then return end
    if GetDB().minimap.hide then minimapButton:Hide() else minimapButton:Show() end
end

function CoAHealAssistInternal.ToggleConfigFrame()
    if not config then return end
    if config:IsShown() then
        config:Hide()
    else
        config:Show()
        if config.LoadFromDB then config:LoadFromDB() end
    end
end

function CoAHealAssistInternal.ToggleMainFrame()
    if IsInCombatSafe() then
        Print("Cannot show/hide secure healer frames during combat.")
        return
    end
    local db = GetDB()
    db.shown = not main:IsShown()
    if db.shown then
        main:Show()
        RebuildUnits()
    else
        main:Hide()
        HideRosterPanelsNow()
    end
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
end

function CoAHealAssistInternal.CreateMinimapButton()
    if not Minimap then return end
    minimapButton = CreateFrame("Button", "CoAHealAssistMinimapButton", Minimap)
    minimapButton:SetWidth(32); minimapButton:SetHeight(32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 8)
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    minimapButton:RegisterForDrag("LeftButton")

    minimapButton.border = minimapButton:CreateTexture(nil, "OVERLAY")
    minimapButton.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    minimapButton.border:SetWidth(54); minimapButton.border:SetHeight(54)
    minimapButton.border:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 0, 0)

    minimapButton.icon = minimapButton:CreateTexture(nil, "BACKGROUND")
    minimapButton.icon:SetTexture("Interface\\Icons\\Spell_Holy_Heal")
    minimapButton.icon:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", 7, -6)
    minimapButton.icon:SetPoint("BOTTOMRIGHT", minimapButton, "BOTTOMRIGHT", -7, 6)
    if minimapButton.icon.SetTexCoord then minimapButton.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93) end

    minimapButton.highlight = minimapButton:CreateTexture(nil, "HIGHLIGHT")
    minimapButton.highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton.highlight:SetBlendMode("ADD")
    minimapButton.highlight:SetAllPoints(minimapButton)

    minimapButton:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            CoAHealAssistInternal.ToggleMainFrame()
        else
            CoAHealAssistInternal.ToggleConfigFrame()
        end
    end)
    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("CoA Heal Assist")
        GameTooltip:AddLine("Left-click: Open settings", 0.8, 0.9, 1)
        GameTooltip:AddLine("Right-click: Show / hide healer UI", 0.8, 0.9, 1)
        GameTooltip:AddLine("Drag: Move this minimap icon", 0.8, 0.9, 1)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    minimapButton:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            if not mx or not my then return end
            local scale = (UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or 1
            local cx, cy = GetCursorPosition()
            cx, cy = cx / scale, cy / scale
            local angle = math.deg(CoAHealAssistInternal.MinimapAtan2(cy - my, cx - mx))
            GetDB().minimap.angle = angle
            UpdateMinimapButtonPosition(angle)
        end)
    end)
    minimapButton:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    UpdateMinimapButtonPosition(GetDB().minimap.angle)
    RefreshMinimapButtonVisibility()
end

function CoAHealAssistInternal.CreateMainFrame()
    main = CreateFrame("Frame", "CoAHealAssistFrame", UIParent)
    main:SetFrameStrata("MEDIUM")
    main:SetClampedToScreen(true)
    main:SetMovable(true)
    main:EnableMouse(true)
    SetBackdrop(main, 0.28, 0.30, 0.34, 1)
    ApplyMainPosition()

    -- v0.9.4: gameplay UI is content-only. The addon name/version and all
    -- management controls live in Settings opened from the minimap icon.
    main:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" or GetDB().locked or IsInCombatSafe() then return end
        -- Raid subgroup/Tank/Pet windows are moved by their own headers.
        if not self.attachedPanel then self:StartMoving() end
    end)
    main:SetScript("OnMouseUp", function(self)
        if IsInCombatSafe() then return end
        if not self.attachedPanel then
            self:StopMovingOrSizing()
            SaveMainPosition()
        end
    end)

    -- Independent Healium-style roster panels. They are direct UIParent windows
    -- so their manual screen positions do not inherit/snap through main-frame
    -- scaling. Addon hide/show explicitly manages their visibility.
    local function CreateRosterPanel(titleText, kind, index)
        local panel = CreateFrame("Frame", nil, UIParent)
        panel:SetFrameStrata("MEDIUM")
        panel:SetMovable(true)
        panel.coaKind = kind
        panel.coaIndex = index
        panel:SetClampedToScreen(true)
        panel:EnableMouse(true)

        panel.bg = panel:CreateTexture(nil, "BACKGROUND")
        panel.bg:SetAllPoints(panel)
        panel.bg:SetTexture(0.025, 0.028, 0.035, 1)
        ApplyRosterPanelBackground(panel)
        panel.border = {}
        local ptop = panel:CreateTexture(nil, "BORDER"); ptop:SetTexture(0.48, 0.34, 0.08, 0.95); ptop:SetHeight(1); ptop:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, 0); ptop:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, 0)
        local pbottom = panel:CreateTexture(nil, "BORDER"); pbottom:SetTexture(0.48, 0.34, 0.08, 0.95); pbottom:SetHeight(1); pbottom:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 0, 0); pbottom:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", 0, 0)
        local pleft = panel:CreateTexture(nil, "BORDER"); pleft:SetTexture(0.48, 0.34, 0.08, 0.95); pleft:SetWidth(1); pleft:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, 0); pleft:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 0, 0)
        local pright = panel:CreateTexture(nil, "BORDER"); pright:SetTexture(0.48, 0.34, 0.08, 0.95); pright:SetWidth(1); pright:SetPoint("TOPRIGHT", panel, "TOPRIGHT", 0, 0); pright:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", 0, 0)
        panel.border[1], panel.border[2], panel.border[3], panel.border[4] = ptop, pbottom, pleft, pright

        panel.title = CreateText(panel, 10, "LEFT")
        panel.title:SetPoint("TOPLEFT", panel, "TOPLEFT", 5, -4)
        panel.title:SetText(titleText)
        panel.title:SetTextColor(1.0, 0.82, 0.18)

        panel.closeButton = MakeButton(panel, "X", 20, 17)
        panel.closeButton:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -2, -2)
        panel.closeButton:SetScript("OnClick", function()
            if IsInCombatSafe() then
                Print("Roster frames can only be hidden after combat.")
                pendingSecureRefresh = true
                return
            end
            local frames = GetDB().frames
            if kind == "group" then
                frames.raidGroups[index] = false
                Print("Group " .. tostring(index) .. " frame hidden. Re-enable it from Frames.")
            elseif kind == "tank" then
                frames.tanks = false
                Print("Tank frame hidden. Re-enable Tanks from Frames.")
            elseif kind == "pet" then
                frames.pets = false
                Print("Pets frame hidden. Re-enable Pets from Frames.")
            end
            panel:Hide()
            if RefreshFrameOptions then RefreshFrameOptions() end
            RebuildUnits()
        end)

        panel.emptyText = CreateText(panel, 9, "CENTER")
        panel.emptyText:SetPoint("CENTER", panel, "CENTER", 0, -7)
        panel.emptyText:SetText("Empty")
        panel.emptyText:SetTextColor(0.45, 0.48, 0.55)

        panel:SetScript("OnMouseDown", function(self, button)
            if button == "LeftButton" and not GetDB().locked and not IsInCombatSafe() then
                self:StartMoving()
            end
        end)
        panel:SetScript("OnMouseUp", function(self)
            if IsInCombatSafe() then return end
            self:StopMovingOrSizing()
            StorePanelPosition(self, kind, index)
        end)
        panel:Hide()
        return panel
    end

    for g = 1, 8 do
        raidGroupPanels[g] = CreateRosterPanel("Group " .. tostring(g), "group", g)
    end
    tankPanel = CreateRosterPanel("Tanks / Main Tank", "tank", nil)
    petPanel = CreateRosterPanel("Pets", "pet", nil)

    for i = 1, MAX_UNIT_ROWS do
        rows[i] = CreateUnitRow(main, i)
    end
end

function CoAHealAssistInternal.CreateCheckbox(parent, label)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetWidth(24); cb:SetHeight(24)
    cb.text = CreateText(parent, 11, "LEFT")
    cb.text:SetPoint("LEFT", cb, "RIGHT", 1, 0)
    cb.text:SetText(label)
    return cb
end

function CoAHealAssistInternal.AcceptSpellDrop(editBox, removesBox)
    local spellName, bookSlot, bookType, cursorSpellID = GetCursorSpellDetails()
    if spellName then
        editBox:SetText(spellName)
        editBox:SetCursorPosition(0)
        editBox.coaBookSlot = tonumber(bookSlot) or 0
        editBox.coaBookType = bookType or ""
        editBox.coaSpellID = tonumber(cursorSpellID) or (editBox.coaBookSlot > 0 and SpellBookIDAt(editBox.coaBookSlot, editBox.coaBookType ~= "" and editBox.coaBookType or nil)) or 0
        if removesBox then removesBox:SetText(DetectSpellRemoves(spellName, editBox.coaBookSlot, editBox.coaBookType, editBox.coaSpellID)) end
        if ClearCursor then ClearCursor() end
        return true
    end
    return false
end

function CoAHealAssistInternal.ApplyFrameVisibilityChange(message)
    if IsInCombatSafe() then
        pendingSecureRefresh = true
        Print((message or "Frame visibility changed.") .. " It will apply when combat ends.")
        return
    end
    RebuildUnits()
    if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB(true) end
end

RefreshFrameOptions = function()
    if not frameOptions then return end
    local f = GetDB().frames
    if frameOptions.party then frameOptions.party:SetChecked(f.party and 1 or nil) end
    if frameOptions.me then frameOptions.me:SetChecked(f.me and 1 or nil) end
    if frameOptions.pets then frameOptions.pets:SetChecked(f.pets and 1 or nil) end
    if frameOptions.friends then frameOptions.friends:SetChecked(f.friends and 1 or nil) end
    if frameOptions.tanks then frameOptions.tanks:SetChecked(f.tanks and 1 or nil) end
    if frameOptions.healers then frameOptions.healers:SetChecked(f.healers and 1 or nil) end
    if frameOptions.damagers then frameOptions.damagers:SetChecked(f.damagers and 1 or nil) end
    if frameOptions.groups then
        for groupIndex = 1, 8 do frameOptions.groups[groupIndex]:SetChecked(f.raidGroups[groupIndex] and 1 or nil) end
    end
    if frameOptions.friendCount then
        local n = 0
        for _ in pairs(f.friendNames or {}) do n = n + 1 end
        frameOptions.friendCount:SetText("Friends saved: " .. tostring(n))
    end
end

function CoAHealAssistInternal.SetFrameFlag(key, value)
    local f = GetDB().frames
    f[key] = value and true or false
    CoAHealAssistInternal.ApplyFrameVisibilityChange("Frame selection updated.")
    RefreshFrameOptions()
end

function CoAHealAssistInternal.SetRaidGroupsPreset(lastGroup)
    local f = GetDB().frames
    for groupIndex = 1, 8 do f.raidGroups[groupIndex] = (groupIndex <= (lastGroup or 0)) end
    CoAHealAssistInternal.ApplyFrameVisibilityChange(lastGroup and lastGroup > 0 and ("Raid Groups 1-" .. tostring(lastGroup) .. " selected.") or "All raid groups hidden.")
    RefreshFrameOptions()
end

ToggleFrameOptions = function(anchor)
    if not frameOptions then return end
    if frameOptions:IsShown() then frameOptions:Hide(); return end
    RefreshFrameOptions()
    frameOptions:ClearAllPoints()
    if anchor and anchor.GetCenter then
        frameOptions:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -4)
    else
        frameOptions:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
    frameOptions:Show()
end

CreateFrameOptionsFrame = function()
    frameOptions = CreateFrame("Frame", "CoAHealAssistFrameOptions", UIParent)
    frameOptions:SetWidth(330); frameOptions:SetHeight(448)
    frameOptions:SetFrameStrata("DIALOG")
    frameOptions:SetClampedToScreen(true)
    frameOptions:EnableMouse(true)
    SetBackdrop(frameOptions, 0.85, 0.45, 0.08, 1)

    frameOptions.title = CreateText(frameOptions, 14, "LEFT")
    frameOptions.title:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -10)
    frameOptions.title:SetText("Show / Hide Frames")

    frameOptions.close = MakeButton(frameOptions, "X", 24, 20)
    frameOptions.close:SetPoint("TOPRIGHT", frameOptions, "TOPRIGHT", -8, -8)
    frameOptions.close:SetScript("OnClick", function() frameOptions:Hide() end)

    local info = CreateText(frameOptions, 9, "LEFT")
    info:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -33)
    info:SetWidth(300)
    info:SetText("Choose which Healium-style frames CoA Heal Assist shows. Me / My Group automatically follows your current dungeon party or Raid Group 1-8, even if that raid-group checkbox is off. Raid Groups 1-8 are separate movable/closable windows. Tanks creates its own Main Tank/Tank window. Secure healing rows update out of combat.")
    info:SetTextColor(0.75, 0.82, 0.90)

    local function AddToggle(key, label, x, y)
        local cb = CoAHealAssistInternal.CreateCheckbox(frameOptions, label)
        cb:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", x, y)
        cb:SetScript("OnClick", function(self) CoAHealAssistInternal.SetFrameFlag(key, self:GetChecked() and true or false) end)
        frameOptions[key] = cb
        return cb
    end

    AddToggle("party", "Party", 10, -65)
    AddToggle("me", "Me / My Group", 165, -65)
    AddToggle("pets", "Pets", 10, -91)
    AddToggle("friends", "Friends", 165, -91)
    AddToggle("tanks", "Tanks", 10, -117)
    AddToggle("healers", "Healers", 165, -117)
    AddToggle("damagers", "DPS", 10, -143)

    frameOptions.addFriend = MakeButton(frameOptions, "Add Target Friend", 112, 22)
    frameOptions.addFriend:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -174)
    frameOptions.addFriend:SetScript("OnClick", function()
        if not UnitExists or not UnitExists("target") then Print("Target the player you want to add first."); return end
        local name = UnitDisplayName("target")
        if not name then return end
        AddHealFriend(name)
        Print("Added Healium Friend: " .. name)
        RefreshFrameOptions(); CoAHealAssistInternal.ApplyFrameVisibilityChange("Friends list updated.")
    end)

    frameOptions.removeFriend = MakeButton(frameOptions, "Remove Target", 100, 22)
    frameOptions.removeFriend:SetPoint("LEFT", frameOptions.addFriend, "RIGHT", 6, 0)
    frameOptions.removeFriend:SetScript("OnClick", function()
        if not UnitExists or not UnitExists("target") then Print("Target the player you want to remove first."); return end
        local name = UnitDisplayName("target")
        if not name then return end
        if RemoveHealFriend(name) then Print("Removed Healium Friend: " .. name) else Print(name .. " was not on the Healium Friends list.") end
        RefreshFrameOptions(); CoAHealAssistInternal.ApplyFrameVisibilityChange("Friends list updated.")
    end)

    frameOptions.listFriend = MakeButton(frameOptions, "List", 52, 22)
    frameOptions.listFriend:SetPoint("LEFT", frameOptions.removeFriend, "RIGHT", 6, 0)
    frameOptions.listFriend:SetScript("OnClick", ListHealFriends)

    frameOptions.friendCount = CreateText(frameOptions, 9, "LEFT")
    frameOptions.friendCount:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -202)
    frameOptions.friendCount:SetTextColor(0.65, 0.78, 0.90)

    local raidTitle = CreateText(frameOptions, 12, "LEFT")
    raidTitle:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -224)
    raidTitle:SetText("RAID GROUPS")

    frameOptions.groups = {}
    for i = 1, 8 do
        local groupIndex = i
        local col = (groupIndex <= 4) and 0 or 1
        local row = (groupIndex - 1) % 4
        local cb = CoAHealAssistInternal.CreateCheckbox(frameOptions, "Group " .. tostring(groupIndex))
        cb:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 10 + (col * 155), -246 - (row * 25))
        cb:SetScript("OnClick", function(self)
            local f = GetDB().frames
            f.raidGroups[groupIndex] = self:GetChecked() and true or false
            CoAHealAssistInternal.ApplyFrameVisibilityChange("Raid group selection updated.")
            RefreshFrameOptions()
        end)
        frameOptions.groups[groupIndex] = cb
    end

    frameOptions.hideRaid = MakeButton(frameOptions, "Hide Raid", 70, 22)
    frameOptions.hideRaid:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -354)
    frameOptions.hideRaid:SetScript("OnClick", function() CoAHealAssistInternal.SetRaidGroupsPreset(0) end)
    frameOptions.raid10 = MakeButton(frameOptions, "1-2 (10)", 70, 22)
    frameOptions.raid10:SetPoint("LEFT", frameOptions.hideRaid, "RIGHT", 6, 0)
    frameOptions.raid10:SetScript("OnClick", function() CoAHealAssistInternal.SetRaidGroupsPreset(2) end)
    frameOptions.raid25 = MakeButton(frameOptions, "1-5 (25)", 72, 22)
    frameOptions.raid25:SetPoint("LEFT", frameOptions.raid10, "RIGHT", 6, 0)
    frameOptions.raid25:SetScript("OnClick", function() CoAHealAssistInternal.SetRaidGroupsPreset(5) end)
    frameOptions.raid40 = MakeButton(frameOptions, "1-8 (40)", 72, 22)
    frameOptions.raid40:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -382)
    frameOptions.raid40:SetScript("OnClick", function() CoAHealAssistInternal.SetRaidGroupsPreset(8) end)

    frameOptions.toggleAll = MakeButton(frameOptions, "Toggle Entire Frame", 118, 22)
    frameOptions.toggleAll:SetPoint("LEFT", frameOptions.raid40, "RIGHT", 8, 0)
    frameOptions.toggleAll:SetScript("OnClick", function()
        if IsInCombatSafe() then Print("Cannot show/hide secure healer frames during combat."); return end
        local db = GetDB()
        db.shown = not main:IsShown()
        if db.shown then
            main:Show()
            RebuildUnits()
        else
            main:Hide()
            HideRosterPanelsNow()
        end
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB(true) end
    end)

    local note = CreateText(frameOptions, 8, "LEFT")
    note:SetPoint("TOPLEFT", frameOptions, "TOPLEFT", 12, -409)
    note:SetWidth(305)
    note:SetText("Each raid group can be moved or closed separately and keeps its exact position. The gameplay UI is content-only; all addon controls are in Settings from the minimap icon. Close X on a raid-group panel = uncheck that group. Tanks and Pets are separate. Reset restores all positions.")
    note:SetTextColor(0.65, 0.72, 0.80)

    frameOptions:Hide()
end

function CoAHealAssistInternal.CreateConfigFrame()
    config = CreateFrame("Frame", "CoAHealAssistConfigFrame", UIParent)
    config:SetWidth(1110); config:SetHeight(650)
    config:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    config:SetFrameStrata("DIALOG")
    config:SetMovable(true)
    config:EnableMouse(true)
    config:SetClampedToScreen(true)
    SetBackdrop(config, 0.25, 0.70, 1.0, 1)

    config.title = CreateText(config, 15, "LEFT")
    config.title:SetPoint("TOPLEFT", config, "TOPLEFT", 12, -12)
    config.title:SetText("CoA Heal Assist Settings")

    config.help = CreateText(config, 10, "LEFT")
    config.help:SetPoint("TOPLEFT", config.title, "BOTTOMLEFT", 0, -6)
    config.help:SetWidth(760)
    config.help:SetText("Healium-style compact rows use tight icon-only cast buttons. Drag spells from the spellbook onto the healer bar or the SPELL fields; Shift + Right-click a bar spell to clear that slot. Spell mouseover tooltips can be turned off below. REMOVES auto-reads the spell description, including existing blank slots; Scan All retries every configured spell. You can still edit it manually. Track Buff/HoT/Shield keeps short and long buffs visible with timers. Active tracked buffs grey their button; matching cleanses flash red. Use Frames for Party/Me/Pets/Friends/roles/Raid Groups 1-8. Pets use their own movable frame.")
    config.help:SetTextColor(0.75, 0.82, 0.90)

    config.topClose = MakeButton(config, "X", 24, 20)
    config.topClose:SetPoint("TOPRIGHT", config, "TOPRIGHT", -8, -8)
    config.topClose:SetScript("OnClick", function() config:Hide() end)

    local h0 = CreateText(config, 10, "LEFT"); h0:SetPoint("TOPLEFT", config, "TOPLEFT", 15, -63); h0:SetText("MOVE")
    local h1 = CreateText(config, 10, "LEFT"); h1:SetPoint("TOPLEFT", config, "TOPLEFT", 63, -63); h1:SetText("SPELL")
    local h2 = CreateText(config, 10, "LEFT"); h2:SetPoint("TOPLEFT", config, "TOPLEFT", 292, -63); h2:SetText("TRACK BUFF / HOT / SHIELD")
    local h3 = CreateText(config, 10, "LEFT"); h3:SetPoint("TOPLEFT", config, "TOPLEFT", 522, -63); h3:SetText("REMOVES (AUTO FROM TOOLTIP)")
    config.scanRemovesButton = MakeButton(config, "Scan All", 72, 20)
    config.scanRemovesButton:SetPoint("LEFT", h3, "RIGHT", 8, 0)
    config.scanRemovesButton:SetScript("OnClick", function()
        if CoAHealAssistInternal.ascensionSafeMode then
            Print("Scan All is disabled in Ascension Safe Mode to prevent the current CoA client crash. Enter Removes manually for now.")
            return
        end
        AutoFillBlankRemoves(false, true)
        if config.LoadFromDB then config:LoadFromDB(true) end
    end)

    config.slotRows = {}
    for i = 1, MAX_SPELL_SLOTS do
        local slotIndex = i
        local y = -80 - ((slotIndex - 1) * 29)

        local drag = MakeButton(config, "::", 24, 20)
        drag:SetPoint("TOPLEFT", config, "TOPLEFT", 12, y - 1)
        drag:RegisterForDrag("LeftButton")

        local num = CreateText(config, 11, "RIGHT")
        num:SetPoint("TOPLEFT", config, "TOPLEFT", 37, y - 5)
        num:SetWidth(20)
        num:SetText(tostring(slotIndex))

        local spell = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
        spell:SetWidth(215); spell:SetHeight(22); spell:SetAutoFocus(false)
        spell:SetPoint("TOPLEFT", config, "TOPLEFT", 60, y)

        local aura = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
        aura:SetWidth(215); aura:SetHeight(22); aura:SetAutoFocus(false)
        aura:SetPoint("TOPLEFT", config, "TOPLEFT", 289, y)
        aura:SetScript("OnTextChanged", function(self, userInput)
            if userInput then self.coaUserEdited = true end
        end)

        local removes = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
        removes:SetWidth(244); removes:SetHeight(22); removes:SetAutoFocus(false)
        removes:SetPoint("TOPLEFT", config, "TOPLEFT", 519, y)

        config.slotRows[slotIndex] = {drag=drag, number=num, spell=spell, aura=aura, removes=removes}
        spell:SetScript("OnReceiveDrag", function(self) CoAHealAssistInternal.AcceptSpellDrop(self, removes) end)
        spell:SetScript("OnMouseUp", function(self, button)
            if button == "LeftButton" then CoAHealAssistInternal.AcceptSpellDrop(self, removes) end
        end)
        spell:SetScript("OnEditFocusLost", function(self)
            if Trim(self:GetText()) ~= "" and Trim(removes:GetText()) == "" then
                local detected = DetectSpellRemoves(self:GetText(), self.coaBookSlot, self.coaBookType, self.coaSpellID)
                if detected ~= "" then removes:SetText(detected) end
            end
        end)

        drag:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Move spell slot " .. tostring(slotIndex))
            GameTooltip:AddLine("Drag this handle onto another row to reorder your spells.", 0.8, 0.9, 1, true)
            GameTooltip:AddLine("Click Save & Apply when finished.", 0.45, 1, 0.45)
            GameTooltip:Show()
        end)
        drag:SetScript("OnLeave", function() GameTooltip:Hide() end)
        drag:SetScript("OnDragStart", function(self)
            config.dragSource = slotIndex
            self:SetText(">>")
            GameTooltip:Hide()
        end)
        drag:SetScript("OnDragStop", function(self)
            self:SetText("::")
            local source = config.dragSource
            config.dragSource = nil
            if not source or not GetCursorPosition then return end
            local _, cursorY = GetCursorPosition()
            local scale = (UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or 1
            cursorY = cursorY / scale
            local target
            for rowIndex = 1, MAX_SPELL_SLOTS do
                local box = config.slotRows[rowIndex].spell
                local top = box:GetTop()
                local bottom = box:GetBottom()
                if top and bottom and cursorY <= (top + 4) and cursorY >= (bottom - 4) then
                    target = rowIndex
                    break
                end
            end
            if target and target ~= source and config.MoveSlot then
                config:MoveSlot(source, target)
            end
        end)
    end

    function config:MoveSlot(fromIndex, toIndex)
        if fromIndex == toIndex then return end
        if fromIndex < 1 or fromIndex > MAX_SPELL_SLOTS or toIndex < 1 or toIndex > MAX_SPELL_SLOTS then return end
        local snapshot = {}
        for rowIndex = 1, MAX_SPELL_SLOTS do
            local row = self.slotRows[rowIndex]
            snapshot[rowIndex] = {
                spell = Trim(row.spell:GetText()),
                aura = Trim(row.aura:GetText()),
                auraSource = row.aura.coaUserEdited and "manual" or (row.aura.coaSource or ""),
                removes = Trim(row.removes:GetText()),
            }
        end
        local moving = table.remove(snapshot, fromIndex)
        table.insert(snapshot, toIndex, moving)
        for rowIndex = 1, MAX_SPELL_SLOTS do
            local row = self.slotRows[rowIndex]
            row.spell:SetText(snapshot[rowIndex].spell or "")
            row.aura:SetText(snapshot[rowIndex].aura or "")
            row.aura.coaSource = snapshot[rowIndex].auraSource or ""
            row.aura.coaUserEdited = false
            row.removes:SetText(snapshot[rowIndex].removes or "")
        end
        Print("Moved spell slot " .. tostring(fromIndex) .. " to " .. tostring(toIndex) .. ". Click Save & Apply to use the new order.")
    end

    config.sidePanel = CreateFrame("Frame", nil, config)
    config.sidePanel:SetWidth(310); config.sidePanel:SetHeight(548)
    config.sidePanel:SetPoint("TOPLEFT", config, "TOPLEFT", 785, -55)
    SetBackdrop(config.sidePanel, 0.18, 0.50, 0.82, 0.85)

    local generalTitle = CreateText(config.sidePanel, 12, "LEFT")
    generalTitle:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -10)
    generalTitle:SetText("GENERAL")

    config.showFrame = CoAHealAssistInternal.CreateCheckbox(config.sidePanel, "Show healer frame")
    config.showFrame:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 8, -30)
    config.lockFrame = CoAHealAssistInternal.CreateCheckbox(config.sidePanel, "Lock healer frame position")
    config.lockFrame:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 8, -56)
    config.showMinimap = CoAHealAssistInternal.CreateCheckbox(config.sidePanel, "Show minimap icon")
    config.showMinimap:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 8, -82)
    config.testModeCheck = CoAHealAssistInternal.CreateCheckbox(config.sidePanel, "Test mode / sample raid")
    config.testModeCheck:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 8, -108)

    config.frameOptionsButton = MakeButton(config.sidePanel, "Show / Hide Frames", 128, 22)
    config.frameOptionsButton:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -140)
    config.frameOptionsButton:SetScript("OnClick", function() if ToggleFrameOptions then ToggleFrameOptions(config.frameOptionsButton) end end)

    config.resetMinimap = MakeButton(config.sidePanel, "Reset Mini", 92, 22)
    config.resetMinimap:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -168)
    config.resetMinimap:SetScript("OnClick", function()
        local db = GetDB()
        db.minimap.angle = 225
        db.minimap.hide = false
        if config.showMinimap then config.showMinimap:SetChecked(1) end
        UpdateMinimapButtonPosition(225)
        RefreshMinimapButtonVisibility()
        Print("Minimap icon position reset.")
    end)

    config.toggleMainNow = MakeButton(config.sidePanel, "Reset Layout", 100, 22)
    config.toggleMainNow:SetPoint("LEFT", config.resetMinimap, "RIGHT", 6, 0)
    config.toggleMainNow:SetScript("OnClick", ResetLayout)

    local bleedTitle = CreateText(config.sidePanel, 12, "LEFT")
    bleedTitle:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -206)
    bleedTitle:SetText("CUSTOM BLEED / DEBUFF TOOLS")

    local bleedHelp = CreateText(config.sidePanel, 10, "LEFT")
    bleedHelp:SetPoint("TOPLEFT", bleedTitle, "BOTTOMLEFT", 0, -5)
    bleedHelp:SetWidth(286)
    bleedHelp:SetText("If CoA does not identify a bleed correctly, enter its spell ID here. Use Debug Target/Mouseover to find custom aura IDs and API types.")
    bleedHelp:SetTextColor(0.75, 0.82, 0.90)

    config.bleedIDLabel = CreateText(config.sidePanel, 10, "LEFT")
    config.bleedIDLabel:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -271)
    config.bleedIDLabel:SetText("Spell ID:")
    config.bleedIDBox = CreateFrame("EditBox", nil, config.sidePanel, "InputBoxTemplate")
    config.bleedIDBox:SetWidth(78); config.bleedIDBox:SetHeight(22); config.bleedIDBox:SetAutoFocus(false)
    if config.bleedIDBox.SetNumeric then config.bleedIDBox:SetNumeric(true) end
    config.bleedIDBox:SetPoint("LEFT", config.bleedIDLabel, "RIGHT", 7, 0)

    config.addBleed = MakeButton(config.sidePanel, "Add Bleed", 78, 22)
    config.addBleed:SetPoint("LEFT", config.bleedIDBox, "RIGHT", 6, 0)
    config.addBleed:SetScript("OnClick", function()
        local id = tonumber(config.bleedIDBox:GetText())
        if not id then Print("Enter a numeric debuff spell ID first."); return end
        GetDB().customBleeds[id] = true
        Print("Added custom bleed: " .. tostring(id) .. " (" .. tostring(GetSpellInfo(id) or "unknown spell") .. ")")
        RefreshRows()
    end)

    config.removeBleed = MakeButton(config.sidePanel, "Remove", 66, 22)
    config.removeBleed:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -275)
    config.removeBleed:SetScript("OnClick", function()
        local id = tonumber(config.bleedIDBox:GetText())
        if not id then Print("Enter a numeric debuff spell ID first."); return end
        GetDB().customBleeds[id] = nil
        Print("Removed custom bleed ID " .. tostring(id) .. ".")
        RefreshRows()
    end)

    config.listBleeds = MakeButton(config.sidePanel, "List Bleeds", 82, 22)
    config.listBleeds:SetPoint("LEFT", config.removeBleed, "RIGHT", 6, 0)
    config.listBleeds:SetScript("OnClick", function() if ListBleeds then ListBleeds() end end)

    config.debugTarget = MakeButton(config.sidePanel, "Debug Target", 88, 22)
    config.debugTarget:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -305)
    config.debugTarget:SetScript("OnClick", function() if DumpDebuffs then DumpDebuffs("target") end end)
    config.debugMouse = MakeButton(config.sidePanel, "Debug Mouseover", 106, 22)
    config.debugMouse:SetPoint("LEFT", config.debugTarget, "RIGHT", 6, 0)
    config.debugMouse:SetScript("OnClick", function() if DumpDebuffs then DumpDebuffs("mouseover") end end)

    local guideTitle = CreateText(config.sidePanel, 12, "LEFT")
    guideTitle:SetPoint("TOPLEFT", config.sidePanel, "TOPLEFT", 10, -345)
    guideTitle:SetText("WHAT THE FIELDS MEAN")

    local guide = CreateText(config.sidePanel, 9, "LEFT")
    guide:SetPoint("TOPLEFT", guideTitle, "BOTTOMLEFT", 0, -5)
    guide:SetWidth(286)
    guide:SetText("SPELL: Name/ID, or drag from spellbook.\nREMOVES AUTO: Scans dragged spells by their exact spellbook slot and rescans existing blank slots. Use Scan All to retry. Detects remove/cure/cleanse/dispel/purify wording for Curse, Disease, Poison, Magic or Bleed; manual override remains available.\nTRACK BUFF / HOT / SHIELD: Tracks short or long buffs. Long self-buffs are intentionally strict: type the exact aura here for persistent tracking, or cast it from the healer bar so the addon can learn it directly. Blank = spell name for normal/short tracking.\nBUTTONS: Tight Healium-style icon-only buttons. Left-click casts; drag a spell directly onto a bar out of combat. Shift + Right-click clears a slot. Disable Show spell tooltips if you want mouseover to show nothing.\nDEBUFFS: C Curse | D Disease | P Poison | M Magic | B Bleed. Matching cleanse bars flash red.\nMINIMAP: Left-click settings, right-click healer frame, drag to move.")
    guide:SetTextColor(0.88, 0.90, 0.94)

    config.versionInfo = CreateText(config.sidePanel, 9, "LEFT")
    config.versionInfo:SetPoint("BOTTOMLEFT", config.sidePanel, "BOTTOMLEFT", 10, 9)
    config.versionInfo:SetText("v" .. VERSION .. "  |  " .. AUTHOR)
    config.versionInfo:SetTextColor(0.55, 0.75, 1.0)

    config.showSpellTooltips = CoAHealAssistInternal.CreateCheckbox(config, "Show spell tooltips")
    config.showSpellTooltips:SetPoint("BOTTOMLEFT", config, "BOTTOMLEFT", 15, 151)
    config.showSpellTooltips:SetScript("OnClick", function(self)
        GetDB().showSpellTooltips = self:GetChecked() and true or false
        if not GetDB().showSpellTooltips then GameTooltip:Hide() end
    end)

    config.showBuffIcons = CoAHealAssistInternal.CreateCheckbox(config, "Show my buff/HoT icons")
    config.showBuffIcons:SetPoint("LEFT", config.showSpellTooltips.text, "RIGHT", 90, 0)
    config.showShieldOverlay = CoAHealAssistInternal.CreateCheckbox(config, "Show shield/absorb overlay")
    config.showShieldOverlay:SetPoint("LEFT", config.showBuffIcons.text, "RIGHT", 90, 0)

    config.showGCD = CoAHealAssistInternal.CreateCheckbox(config, "Show global cooldown sweep")
    config.showGCD:SetPoint("BOTTOMLEFT", config, "BOTTOMLEFT", 15, 126)
    config.hideSolo = CoAHealAssistInternal.CreateCheckbox(config, "Hide frame while solo")
    config.hideSolo:SetPoint("LEFT", config.showGCD.text, "RIGHT", 130, 0)

    config.useBackground = CoAHealAssistInternal.CreateCheckbox(config, "Use frame background")
    config.useBackground:SetPoint("LEFT", config.hideSolo.text, "RIGHT", 128, 0)
    config.useBackground:SetScript("OnClick", function(self)
        if config.bgAlphaSlider then
            if self:GetChecked() then config.bgAlphaSlider:Enable() else config.bgAlphaSlider:Disable() end
        end
    end)

    config.bgAlphaLabel = CreateText(config, 11, "LEFT")
    config.bgAlphaLabel:SetPoint("BOTTOMLEFT", config, "BOTTOMLEFT", 15, 98)
    config.bgAlphaLabel:SetText("Background transparency:")
    config.bgAlphaSlider = CreateFrame("Slider", "CoAHealAssistBgAlphaSlider", config, "OptionsSliderTemplate")
    config.bgAlphaSlider:SetWidth(145)
    config.bgAlphaSlider:SetHeight(16)
    config.bgAlphaSlider:SetPoint("LEFT", config.bgAlphaLabel, "RIGHT", 10, 0)
    config.bgAlphaSlider:SetMinMaxValues(0, 100)
    config.bgAlphaSlider:SetValueStep(1)
    if config.bgAlphaSlider.SetObeyStepOnDrag then config.bgAlphaSlider:SetObeyStepOnDrag(true) end
    _G["CoAHealAssistBgAlphaSliderLow"]:SetText("0%")
    _G["CoAHealAssistBgAlphaSliderHigh"]:SetText("100%")
    _G["CoAHealAssistBgAlphaSliderText"]:SetText("")
    config.bgAlphaValue = CreateText(config, 11, "LEFT")
    config.bgAlphaValue:SetPoint("LEFT", config.bgAlphaSlider, "RIGHT", 8, 0)
    config.bgAlphaSlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor((tonumber(value) or 0) + 0.5)
        if config.bgAlphaValue then config.bgAlphaValue:SetText(tostring(value) .. "%") end
    end)

    config.scaleLabel = CreateText(config, 11, "LEFT")
    config.scaleLabel:SetPoint("BOTTOMLEFT", config, "BOTTOMLEFT", 15, 74)
    config.scaleLabel:SetText("Scale:")
    config.scaleBox = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
    config.scaleBox:SetWidth(48); config.scaleBox:SetHeight(22); config.scaleBox:SetAutoFocus(false)
    config.scaleBox:SetPoint("LEFT", config.scaleLabel, "RIGHT", 7, 0)

    config.buttonCountLabel = CreateText(config, 11, "LEFT")
    config.buttonCountLabel:SetPoint("LEFT", config.scaleBox, "RIGHT", 24, 0)
    config.buttonCountLabel:SetText("Visible buttons (1-14):")
    config.buttonCountBox = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
    config.buttonCountBox:SetWidth(38); config.buttonCountBox:SetHeight(22); config.buttonCountBox:SetAutoFocus(false)
    if config.buttonCountBox.SetNumeric then config.buttonCountBox:SetNumeric(true) end
    config.buttonMinus = MakeButton(config, "-", 24, 22)
    config.buttonMinus:SetPoint("LEFT", config.buttonCountLabel, "RIGHT", 7, 0)
    config.buttonCountBox:SetPoint("LEFT", config.buttonMinus, "RIGHT", 4, 0)
    config.buttonPlus = MakeButton(config, "+", 24, 22)
    config.buttonPlus:SetPoint("LEFT", config.buttonCountBox, "RIGHT", 4, 0)
    config.buttonMinus:SetScript("OnClick", function()
        config.buttonCountBox:SetText(tostring(ClampSpellButtonCount((tonumber(config.buttonCountBox:GetText()) or DEFAULT_SPELL_BUTTON_COUNT) - 1)))
    end)
    config.buttonPlus:SetScript("OnClick", function()
        config.buttonCountBox:SetText(tostring(ClampSpellButtonCount((tonumber(config.buttonCountBox:GetText()) or DEFAULT_SPELL_BUTTON_COUNT) + 1)))
    end)

    config.buttonSizeLabel = CreateText(config, 11, "LEFT")
    config.buttonSizeLabel:SetPoint("BOTTOMLEFT", config, "BOTTOMLEFT", 15, 44)
    config.buttonSizeLabel:SetText("Bar height (22-48):")
    config.buttonSizeBox = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
    config.buttonSizeBox:SetWidth(38); config.buttonSizeBox:SetHeight(22); config.buttonSizeBox:SetAutoFocus(false)
    if config.buttonSizeBox.SetNumeric then config.buttonSizeBox:SetNumeric(true) end
    config.sizeMinus = MakeButton(config, "-", 24, 22)
    config.sizeMinus:SetPoint("LEFT", config.buttonSizeLabel, "RIGHT", 7, 0)
    config.buttonSizeBox:SetPoint("LEFT", config.sizeMinus, "RIGHT", 4, 0)
    config.sizePlus = MakeButton(config, "+", 24, 22)
    config.sizePlus:SetPoint("LEFT", config.buttonSizeBox, "RIGHT", 4, 0)
    config.sizeMinus:SetScript("OnClick", function()
        config.buttonSizeBox:SetText(tostring(ClampButtonSize((tonumber(config.buttonSizeBox:GetText()) or DEFAULT_BUTTON_SIZE) - 1)))
    end)
    config.sizePlus:SetScript("OnClick", function()
        config.buttonSizeBox:SetText(tostring(ClampButtonSize((tonumber(config.buttonSizeBox:GetText()) or DEFAULT_BUTTON_SIZE) + 1)))
    end)

    config.buttonSpacingLabel = CreateText(config, 11, "LEFT")
    config.buttonSpacingLabel:SetPoint("LEFT", config.sizePlus, "RIGHT", 28, 0)
    config.buttonSpacingLabel:SetText("Spacing (0-12):")
    config.buttonSpacingBox = CreateFrame("EditBox", nil, config, "InputBoxTemplate")
    config.buttonSpacingBox:SetWidth(38); config.buttonSpacingBox:SetHeight(22); config.buttonSpacingBox:SetAutoFocus(false)
    if config.buttonSpacingBox.SetNumeric then config.buttonSpacingBox:SetNumeric(true) end
    config.spacingMinus = MakeButton(config, "-", 24, 22)
    config.spacingMinus:SetPoint("LEFT", config.buttonSpacingLabel, "RIGHT", 7, 0)
    config.buttonSpacingBox:SetPoint("LEFT", config.spacingMinus, "RIGHT", 4, 0)
    config.spacingPlus = MakeButton(config, "+", 24, 22)
    config.spacingPlus:SetPoint("LEFT", config.buttonSpacingBox, "RIGHT", 4, 0)
    config.spacingMinus:SetScript("OnClick", function()
        config.buttonSpacingBox:SetText(tostring(ClampButtonSpacing((tonumber(config.buttonSpacingBox:GetText()) or DEFAULT_BUTTON_SPACING) - 1)))
    end)
    config.spacingPlus:SetScript("OnClick", function()
        config.buttonSpacingBox:SetText(tostring(ClampButtonSpacing((tonumber(config.buttonSpacingBox:GetText()) or DEFAULT_BUTTON_SPACING) + 1)))
    end)

    config.resetButtonLayout = MakeButton(config, "Reset Button Layout", 130, 22)
    config.resetButtonLayout:SetPoint("LEFT", config.spacingPlus, "RIGHT", 22, 0)
    config.resetButtonLayout:SetScript("OnClick", ResetButtonLayout)
    config.resetButtonLayout:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Reset Button Layout")
        GameTooltip:AddLine("Restores 8 visible buttons, 32px bar height and 5px spacing.", 0.8, 0.9, 1, true)
        GameTooltip:AddLine("Your spell assignments are kept.", 0.45, 1, 0.45)
        GameTooltip:Show()
    end)
    config.resetButtonLayout:SetScript("OnLeave", function() GameTooltip:Hide() end)

    config.save = MakeButton(config, "Save & Apply", 100, 24)
    config.save:SetPoint("BOTTOMRIGHT", config, "BOTTOMRIGHT", -12, 16)
    config.close = MakeButton(config, "Close", 65, 24)
    config.close:SetPoint("RIGHT", config.save, "LEFT", -7, 0)
    config.resetSpells = MakeButton(config, "Reset Spells", 90, 24)
    config.resetSpells:SetPoint("RIGHT", config.close, "LEFT", -18, 0)
    config.resetAll = MakeButton(config, "Reset ALL", 82, 24)
    config.resetAll:SetPoint("RIGHT", config.resetSpells, "LEFT", -7, 0)

    function config:LoadFromDB(skipAutoScan)
        if (not CoAHealAssistInternal.ascensionSafeMode) and not skipAutoScan then AutoFillBlankRemoves(true) end
        local db = GetDB()
        if self.showFrame then self.showFrame:SetChecked(db.shown and 1 or nil) end
        if self.lockFrame then self.lockFrame:SetChecked(db.locked and 1 or nil) end
        if self.showMinimap then self.showMinimap:SetChecked((not db.minimap.hide) and 1 or nil) end
        if self.testModeCheck then self.testModeCheck:SetChecked(db.testMode and 1 or nil) end
        for i = 1, MAX_SPELL_SLOTS do
            self.slotRows[i].spell:SetText(db.spellSlots[i].spell or "")
            self.slotRows[i].spell.coaBookSlot = tonumber(db.spellSlots[i].bookSlot) or 0
            self.slotRows[i].spell.coaBookType = db.spellSlots[i].bookType or ""
            self.slotRows[i].spell.coaSpellID = tonumber(db.spellSlots[i].spellID) or 0
            self.slotRows[i].aura:SetText(db.spellSlots[i].aura or "")
            self.slotRows[i].aura.coaSource = db.spellSlots[i].auraSource or ""
            self.slotRows[i].aura.coaUserEdited = false
            self.slotRows[i].removes:SetText(db.spellSlots[i].removes or "")
        end
        if self.showSpellTooltips then self.showSpellTooltips:SetChecked(db.showSpellTooltips and 1 or nil) end
        if self.showBuffIcons then self.showBuffIcons:SetChecked((db.showBuffIcons ~= false) and 1 or nil) end
        if self.showShieldOverlay then self.showShieldOverlay:SetChecked((db.showShieldOverlay ~= false) and 1 or nil) end
        self.showGCD:SetChecked(db.showGCD and 1 or nil)
        self.hideSolo:SetChecked(db.hideSolo and 1 or nil)
        if self.useBackground then self.useBackground:SetChecked((db.useBackground ~= false) and 1 or nil) end
        if self.bgAlphaSlider then
            local pct = math.floor(((tonumber(db.backgroundAlpha) or 0.22) * 100) + 0.5)
            self.bgAlphaSlider:SetValue(pct)
            if self.bgAlphaValue then self.bgAlphaValue:SetText(tostring(pct) .. "%") end
            if self.useBackground and self.useBackground:GetChecked() then self.bgAlphaSlider:Enable() else self.bgAlphaSlider:Disable() end
        end
        self.scaleBox:SetText(string.format("%.2f", db.scale or 0.90))
        self.buttonCountBox:SetText(tostring(ClampSpellButtonCount(db.spellButtonCount)))
        self.buttonSizeBox:SetText(tostring(ClampButtonSize(db.buttonSize)))
        self.buttonSpacingBox:SetText(tostring(ClampButtonSpacing(db.buttonSpacing)))
    end

    function config:SaveToDB()
        local db = GetDB()
        local wantedShown = self.showFrame and self.showFrame:GetChecked() and true or false
        db.locked = self.lockFrame and self.lockFrame:GetChecked() and true or false
        if self.showMinimap then db.minimap.hide = not (self.showMinimap:GetChecked() and true or false) end
        db.testMode = self.testModeCheck and self.testModeCheck:GetChecked() and true or false
        db.shown = wantedShown
        RefreshMinimapButtonVisibility()
        for i = 1, MAX_SPELL_SLOTS do
            local oldSpell = Trim(db.spellSlots[i].spell)
            local oldRemoves = Trim(db.spellSlots[i].removes)
            local oldAura = Trim(db.spellSlots[i].aura)
            local newSpell = Trim(self.slotRows[i].spell:GetText())
            local newAura = Trim(self.slotRows[i].aura:GetText())
            local auraEdited = self.slotRows[i].aura.coaUserEdited and true or false
            local typedRemoves = Trim(self.slotRows[i].removes:GetText())
            local spellChanged = string.lower(oldSpell) ~= string.lower(newSpell)
            local removesManuallyChanged = typedRemoves ~= oldRemoves
            db.spellSlots[i].spell = newSpell
            db.spellSlots[i].aura = newAura
            if auraEdited then
                db.spellSlots[i].auraSource = newAura ~= "" and "manual" or ""
            else
                db.spellSlots[i].auraSource = self.slotRows[i].aura.coaSource or db.spellSlots[i].auraSource or ""
            end
            if spellChanged then
                db.spellSlots[i].bookSlot = tonumber(self.slotRows[i].spell.coaBookSlot) or 0
                db.spellSlots[i].bookType = self.slotRows[i].spell.coaBookType or ""
                db.spellSlots[i].spellID = tonumber(self.slotRows[i].spell.coaSpellID) or 0
                if db.spellSlots[i].bookSlot == 0 and not CoAHealAssistInternal.ascensionSafeMode then
                    local foundSlot, foundType, foundID = FindSpellBookSlot(newSpell)
                    db.spellSlots[i].bookSlot = tonumber(foundSlot) or 0
                    db.spellSlots[i].bookType = foundType or ""
                    db.spellSlots[i].spellID = tonumber(foundID) or 0
                end
            end
            if spellChanged and newAura == oldAura then
                db.spellSlots[i].aura = ""
                db.spellSlots[i].auraSource = ""
            end
            if CoAHealAssistInternal.ascensionSafeMode then
                db.spellSlots[i].removes = typedRemoves
            elseif spellChanged and not removesManuallyChanged then
                db.spellSlots[i].removes = DetectSpellRemoves(newSpell, db.spellSlots[i].bookSlot, db.spellSlots[i].bookType, db.spellSlots[i].spellID)
            elseif typedRemoves == "" and newSpell ~= "" then
                db.spellSlots[i].removes = DetectSpellRemoves(newSpell, db.spellSlots[i].bookSlot, db.spellSlots[i].bookType, db.spellSlots[i].spellID)
            else
                db.spellSlots[i].removes = typedRemoves
            end
            self.slotRows[i].aura.coaSource = db.spellSlots[i].auraSource or ""
            self.slotRows[i].aura.coaUserEdited = false
        end
        db.spellButtonCount = ClampSpellButtonCount(self.buttonCountBox:GetText())
        self.buttonCountBox:SetText(tostring(db.spellButtonCount))
        db.buttonSize = ClampButtonSize(self.buttonSizeBox:GetText())
        self.buttonSizeBox:SetText(tostring(db.buttonSize))
        db.buttonSpacing = ClampButtonSpacing(self.buttonSpacingBox:GetText())
        self.buttonSpacingBox:SetText(tostring(db.buttonSpacing))
        if self.showSpellTooltips then db.showSpellTooltips = self.showSpellTooltips:GetChecked() and true or false end
        if self.showBuffIcons then db.showBuffIcons = self.showBuffIcons:GetChecked() and true or false end
        if self.showShieldOverlay then db.showShieldOverlay = self.showShieldOverlay:GetChecked() and true or false end
        db.showGCD = self.showGCD:GetChecked() and true or false
        db.hideSolo = self.hideSolo:GetChecked() and true or false
        if self.useBackground then db.useBackground = self.useBackground:GetChecked() and true or false end
        if self.bgAlphaSlider then
            local pct = tonumber(self.bgAlphaSlider:GetValue()) or 22
            if pct < 0 then pct = 0 elseif pct > 100 then pct = 100 end
            db.backgroundAlpha = pct / 100
        end
        RefreshRosterPanelBackgrounds()
        local scale = tonumber(self.scaleBox:GetText()) or db.scale or 0.90
        if scale < 0.55 then scale = 0.55 end
        if scale > 1.40 then scale = 1.40 end
        db.scale = scale
        if not IsInCombatSafe() then
            main:SetScale(scale)
            if db.shown then main:Show() else main:Hide() end
        end
        if IsInCombatSafe() then
            pendingSecureRefresh = true
            Print("Settings saved. Secure spell changes will apply when combat ends.")
        else
            RebuildUnits()
            Print("Settings saved and applied.")
        end
    end

    config.save:SetScript("OnClick", function() config:SaveToDB() end)
    config.close:SetScript("OnClick", function() config:Hide() end)
    config.resetSpells:SetScript("OnClick", ResetSpells)
    config.resetAll:SetScript("OnClick", ResetAll)

    config:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then self:StartMoving() end
    end)
    config:SetScript("OnMouseUp", function(self) self:StopMovingOrSizing() end)
    config:Hide()
end

DumpDebuffs = function(unit)
    if not unit or not UnitExists(unit) then Print("That unit does not exist. Try /cha debug target or /cha debug mouseover"); return end
    Print("Debuffs on " .. (UnitName(unit) or unit) .. ":")
    local found = false
    for i = 1, 40 do
        local a = UnitAuraData(unit, i, false)
        if not a then break end
        found = true
        local t = NormalizeDebuffType(a.name, a.spellID, a.rawType)
        Print(string.format("#%d  %s  spellID=%s  apiType=%s  shownAs=%s", i, a.name or "?", tostring(a.spellID or "?"), tostring(a.rawType or "none"), t))
    end
    if not found then Print("No harmful auras found.") end
end

ListBleeds = function()
    local db = GetDB()
    local found = false
    Print("Custom bleed spell IDs:")
    for id in pairs(db.customBleeds) do
        found = true
        local name = GetSpellInfo(id) or "Unknown"
        Print(tostring(id) .. " - " .. name)
    end
    if not found then Print("No custom bleed IDs added yet.") end
end

function CoAHealAssistInternal.DebugActionMirror(slotIndex)
    slotIndex = tonumber(slotIndex) or 1
    if slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then Print("Usage: /cha bardebug <1-14>"); return end
    local db = GetDB()
    local slot = db.spellSlots and db.spellSlots[slotIndex]
    local spellName, spellID = NormalizeSpell(slot and slot.spell or "")
    if slot and tonumber(slot.spellID) then spellID = tonumber(slot.spellID) end
    if not spellName or spellName == "" then Print("Bar debug: slot " .. tostring(slotIndex) .. " is empty."); return end
    -- A manual debug request should bypass the normal miss throttle.
    CoAHealAssistInternal.actionButtonMissUntil = {}
    local button, globalName = FindVisibleActionButtonForSpell(spellName, spellID, slotIndex, true)
    Print("Bar debug slot " .. tostring(slotIndex) .. ": " .. tostring(spellName) .. " id=" .. tostring(spellID or "?") )
    if not button then Print("No visible default/custom action button matched this spell icon or A" .. tostring(slotIndex) .. " hotkey hint."); return end
    local name = globalName or (button.GetName and button:GetName()) or "<anonymous>"
    local count = ActionButtonCountText(button, globalName, true)
    local wantedTexture = NormalizeTextureForMatch(SpellIconForChargeMatch(spellName, spellID, slotIndex))
    local proc = CoAHealAssistInternal.ActionButtonHasProcGlow(button, globalName, wantedTexture, true)
    local w, h = "?", "?"
    if button.GetWidth then local ok, v = pcall(button.GetWidth, button); if ok then w = tostring(math.floor((tonumber(v) or 0)+0.5)) end end
    if button.GetHeight then local ok, v = pcall(button.GetHeight, button); if ok then h = tostring(math.floor((tonumber(v) or 0)+0.5)) end end
    Print("Matched frame=" .. tostring(name) .. " size=" .. w .. "x" .. h .. " chargeText=" .. tostring(count) .. " procGlow=" .. tostring(proc))
end

function CoAHealAssistInternal.ShowHelp()
    Print("Commands:")
    Print("/cha - show/hide healer frame")
    Print("/cha config - open full settings window")
    Print("/cha frames - open Healium-style Show / Hide Frames menu")
    Print("/cha minimap - show/hide minimap icon; /cha minimap reset resets its position")
    Print("/cha friendadd [name] | friendremove [name] | friendlist | friendclear")
    Print("/cha buttons <1-14> - set how many spell buttons are visible")
    Print("/cha buttonsize <22-48> - set Healium-style spell bar height")
    Print("/cha spacing <0-12> - set space between spell buttons")
    Print("/cha resetbuttons - reset button count/size/spacing without erasing spells")
    Print("/cha test - toggle sample raid-frame test mode")
    Print("/cha reset - reset frame position/scale")
    Print("/cha clearslot <1-14> - clear one spell slot out of combat")
    Print("/cha tooltips on|off - toggle spell-button mouseover tooltips")
    Print("/cha resetspells - clear all configured spell slots")
    Print("/cha resetall - reset every addon setting")
    Print("/cha bleedadd <spellID> - mark a CoA debuff as a bleed")
    Print("/cha bleedremove <spellID> - remove custom bleed classification")
    Print("/cha bleedlist - list custom bleed IDs")
    Print("/cha debug target|mouseover - print harmful aura names, IDs and API types")
    Print("/cha bardebug <1-14> - diagnose charge/proc mirroring for one healer spell slot")
    Print("/cha barbind <1-14> [both|proc|charge] - bind the hovered normal action button with separate proc/charge behavior")
    Print("/cha barmode <1-14> both|proc|charge - change an existing binding without rebinding")
    Print("/cha barunbind <1-14> - clear a saved action-bar binding")
    Print("/cha version - show version")
end

function CoAHealAssistInternal.SlashHandler(msg)
    msg = Trim(msg or "")
    local cmd, rest = string.match(msg, "^(%S*)%s*(.-)$")
    cmd = string.lower(cmd or "")
    rest = Trim(rest)

    if cmd == "" then
        if IsInCombatSafe() then
            Print("Cannot show/hide secure healer frames during combat.")
            return
        end
        local db = GetDB()
        db.shown = not main:IsShown()
        if db.shown then
            main:Show()
            RebuildUnits()
        else
            main:Hide()
            HideRosterPanelsNow()
        end
    elseif cmd == "config" or cmd == "options" then
        config:Show(); config:LoadFromDB()
    elseif cmd == "minimap" then
        local action = string.lower(rest or "")
        if action == "reset" then
            GetDB().minimap.angle = 225
            GetDB().minimap.hide = false
            UpdateMinimapButtonPosition(225)
            RefreshMinimapButtonVisibility()
            Print("Minimap icon reset.")
        elseif action == "show" then
            GetDB().minimap.hide = false
            RefreshMinimapButtonVisibility()
        elseif action == "hide" then
            GetDB().minimap.hide = true
            RefreshMinimapButtonVisibility()
        else
            GetDB().minimap.hide = not GetDB().minimap.hide
            RefreshMinimapButtonVisibility()
        end
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
    elseif cmd == "frames" or cmd == "frame" then
        if ToggleFrameOptions then ToggleFrameOptions(config and config.frameOptionsButton or minimapButton) end
    elseif cmd == "friendadd" then
        local name = rest
        if name == "" and UnitExists and UnitExists("target") then name = UnitDisplayName("target") or "" end
        if name == "" then Print("Target a group member or use /cha friendadd Name"); return end
        AddHealFriend(name)
        Print("Added Healium Friend: " .. name)
        if RefreshFrameOptions then RefreshFrameOptions() end
        if not IsInCombatSafe() then RebuildUnits() else pendingSecureRefresh = true end
    elseif cmd == "friendremove" or cmd == "frienddel" then
        local name = rest
        if name == "" and UnitExists and UnitExists("target") then name = UnitDisplayName("target") or "" end
        if name == "" then Print("Target a member or use /cha friendremove Name"); return end
        if RemoveHealFriend(name) then Print("Removed Healium Friend: " .. name) else Print(name .. " was not on the Healium Friends list.") end
        if RefreshFrameOptions then RefreshFrameOptions() end
        if not IsInCombatSafe() then RebuildUnits() else pendingSecureRefresh = true end
    elseif cmd == "friendlist" then
        ListHealFriends()
    elseif cmd == "friendclear" then
        GetDB().frames.friendNames = {}
        Print("Healium Friends list cleared.")
        if RefreshFrameOptions then RefreshFrameOptions() end
        if not IsInCombatSafe() then RebuildUnits() else pendingSecureRefresh = true end
    elseif cmd == "test" then
        if IsInCombatSafe() then Print("Test mode can only be changed out of combat."); return end
        local db = GetDB(); db.testMode = not db.testMode
        Print("Test mode " .. (db.testMode and "ON" or "OFF") .. ".")
        RebuildUnits()
    elseif cmd == "buttons" or cmd == "buttoncount" then
        local requested = tonumber(rest)
        if not requested or requested < 1 or requested > MAX_SPELL_SLOTS then
            Print("Usage: /cha buttons <1-14>")
            return
        end
        local db = GetDB()
        db.spellButtonCount = ClampSpellButtonCount(requested)
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
        if IsInCombatSafe() then
            pendingSecureRefresh = true
            Print("Spell button count set to " .. db.spellButtonCount .. ". It will apply when combat ends.")
        else
            RebuildUnits()
            Print("Visible spell buttons set to " .. db.spellButtonCount .. ".")
        end
    elseif cmd == "buttonsize" or cmd == "size" then
        local requested = tonumber(rest)
        if not requested or requested < MIN_BUTTON_SIZE or requested > MAX_BUTTON_SIZE then
            Print("Usage: /cha buttonsize <22-48>")
            return
        end
        local db = GetDB()
        db.buttonSize = ClampButtonSize(requested)
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
        if IsInCombatSafe() then
            pendingSecureRefresh = true
            Print("Spell bar height set to " .. db.buttonSize .. ". It will apply when combat ends.")
        else
            RebuildUnits()
            Print("Spell bar height set to " .. db.buttonSize .. ".")
        end
    elseif cmd == "spacing" or cmd == "buttonspacing" then
        local requested = tonumber(rest)
        if requested == nil or requested < MIN_BUTTON_SPACING or requested > MAX_BUTTON_SPACING then
            Print("Usage: /cha spacing <0-12>")
            return
        end
        local db = GetDB()
        db.buttonSpacing = ClampButtonSpacing(requested)
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB() end
        if IsInCombatSafe() then
            pendingSecureRefresh = true
            Print("Button spacing set to " .. db.buttonSpacing .. ". It will apply when combat ends.")
        else
            RebuildUnits()
            Print("Button spacing set to " .. db.buttonSpacing .. ".")
        end
    elseif cmd == "resetbuttons" or cmd == "resetbuttonlayout" then
        ResetButtonLayout()
    elseif cmd == "reset" then
        ResetLayout()
    elseif cmd == "clearslot" or cmd == "clearspell" then
        local slotIndex = tonumber(rest)
        if not slotIndex or slotIndex < 1 or slotIndex > MAX_SPELL_SLOTS then
            Print("Usage: /cha clearslot <1-14>")
            return
        end
        ClearSpellSlot(slotIndex)
    elseif cmd == "tooltips" or cmd == "tooltip" then
        local action = string.lower(rest or "")
        local db = GetDB()
        if action == "on" or action == "show" or action == "1" then
            db.showSpellTooltips = true
        elseif action == "off" or action == "hide" or action == "0" then
            db.showSpellTooltips = false
            GameTooltip:Hide()
        else
            db.showSpellTooltips = not db.showSpellTooltips
            if not db.showSpellTooltips then GameTooltip:Hide() end
        end
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB(true) end
        Print("Spell tooltips " .. (db.showSpellTooltips and "ON" or "OFF") .. ".")
    elseif cmd == "resetspells" then
        if IsInCombatSafe() then Print("Reset spells after combat."); return end
        ResetSpells()
    elseif cmd == "resetall" then
        if IsInCombatSafe() then Print("Reset all after combat."); return end
        ResetAll()
    elseif cmd == "bleedadd" then
        local id = tonumber(rest)
        if not id then Print("Usage: /cha bleedadd <spellID>"); return end
        GetDB().customBleeds[id] = true
        Print("Added custom bleed: " .. tostring(id) .. " (" .. tostring(GetSpellInfo(id) or "unknown spell") .. ")")
        RefreshRows()
    elseif cmd == "bleedremove" or cmd == "bleeddel" then
        local id = tonumber(rest)
        if not id then Print("Usage: /cha bleedremove <spellID>"); return end
        GetDB().customBleeds[id] = nil
        Print("Removed custom bleed ID " .. tostring(id) .. ".")
        RefreshRows()
    elseif cmd == "bleedlist" then
        ListBleeds()
    elseif cmd == "barbind" or cmd == "bindbar" or cmd == "mousebar" then
        local slotText, mirrorMode = string.match(rest or "", "^(%d+)%s*(%S*)")
        CoAHealAssistInternal.BindMouseActionButton(tonumber(slotText) or 1, mirrorMode)
    elseif cmd == "barmode" or cmd == "mirrormode" then
        local slotText, mirrorMode = string.match(rest or "", "^(%d+)%s+(%S+)")
        CoAHealAssistInternal.SetActionMirrorMode(tonumber(slotText), mirrorMode)
    elseif cmd == "barunbind" or cmd == "unbindbar" then
        CoAHealAssistInternal.UnbindActionButton(tonumber(rest) or 1)
    elseif cmd == "bardebug" or cmd == "actiondebug" then
        CoAHealAssistInternal.DebugActionMirror(tonumber(rest) or 1)
    elseif cmd == "debug" then
        local unit = string.lower(rest)
        if unit ~= "target" and unit ~= "mouseover" and unit ~= "player" then unit = "target" end
        DumpDebuffs(unit)
    elseif cmd == "scanremoves" or cmd == "scan" then
        if CoAHealAssistInternal.ascensionSafeMode then
            Print("Spellbook tooltip scanning is disabled in Ascension Safe Mode to prevent the current CoA client crash.")
            return
        end
        AutoFillBlankRemoves(false, true)
        if config and config:IsShown() and config.LoadFromDB then config:LoadFromDB(true) end
    elseif cmd == "version" then
        Print("v" .. VERSION .. " - Made by " .. AUTHOR)
    elseif cmd == "show" then
        if IsInCombatSafe() then Print("Cannot show secure healer frames during combat."); return end
        GetDB().shown = true; main:Show(); RebuildUnits()
    elseif cmd == "hide" then
        if IsInCombatSafe() then Print("Cannot hide secure healer frames during combat."); return end
        GetDB().shown = false; main:Hide(); HideRosterPanelsNow()
    else
        CoAHealAssistInternal.ShowHelp()
    end
end

function CoAHealAssistInternal.Initialize()
    GetDB()
    CoAHealAssistInternal.CreateMainFrame()
    CoAHealAssistInternal.CreateConfigFrame()
    CreateFrameOptionsFrame()
    CoAHealAssistInternal.CreateMinimapButton()
    SLASH_COAHEALASSIST1 = "/cha"
    SLASH_COAHEALASSIST2 = "/coaheal"
    SlashCmdList["COAHEALASSIST"] = CoAHealAssistInternal.SlashHandler
    -- Safe mode deliberately does not walk custom spellbook/tooltips at login.
    RebuildUnits()
    if not GetDB().shown then main:Hide() end
    Print("v" .. VERSION .. " loaded for " .. tostring(activeCharacterKey or GetCharacterProfileKey()) .. ". Safe compatibility mode is ON. Click the minimap icon for Settings, or type /cha config.")
end

CHA:RegisterEvent("ADDON_LOADED")
CHA:RegisterEvent("PLAYER_LOGIN")
CHA:RegisterEvent("PLAYER_REGEN_ENABLED")
CHA:RegisterEvent("PARTY_MEMBERS_CHANGED")
CHA:RegisterEvent("RAID_ROSTER_UPDATE")
SafeCall(CHA.RegisterEvent, CHA, "RAID_TARGET_UPDATE")
CHA:RegisterEvent("UNIT_HEALTH")
CHA:RegisterEvent("UNIT_MAXHEALTH")
CHA:RegisterEvent("UNIT_AURA")
CHA:RegisterEvent("SPELL_UPDATE_COOLDOWN")
CHA:RegisterEvent("SPELL_UPDATE_USABLE")
-- Not every Ascension client exposes this event; unknown events are ignored.
SafeCall(CHA.RegisterEvent, CHA, "SPELL_UPDATE_CHARGES")
CHA:RegisterEvent("SPELLS_CHANGED")
SafeCall(CHA.RegisterEvent, CHA, "ACTIONBAR_SLOT_CHANGED")
-- Some Ascension builds backport Blizzard spell-activation overlay events.
-- Use them when present; SafeCall keeps older clients compatible.
SafeCall(CHA.RegisterEvent, CHA, "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW")
SafeCall(CHA.RegisterEvent, CHA, "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE")
CHA:RegisterEvent("PLAYER_TARGET_CHANGED")

CHA:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        -- Wait for PLAYER_LOGIN before selecting/migrating a character profile.
        -- At ADDON_LOADED some Ascension builds have not populated the
        -- character spellbook yet, which could make a real healer look like a
        -- brand-new alt during the one-time legacy profile migration.
        return
    elseif event == "PLAYER_LOGIN" then
        if not main then CoAHealAssistInternal.Initialize() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pendingSecureRefresh then RebuildUnits() else RefreshRows() end
    elseif event == "PARTY_MEMBERS_CHANGED" or event == "RAID_ROSTER_UPDATE" then
        if IsInCombatSafe() then pendingSecureRefresh = true else RebuildUnits() end
    elseif event == "RAID_TARGET_UPDATE" then
        RefreshRaidTargetMarkers()
    elseif event == "UNIT_HEALTH" or event == "UNIT_MAXHEALTH" then
        -- Health events only touch the one affected row. No aura/spellbook scan.
        RefreshUnitHealth(arg1)
    elseif event == "UNIT_AURA" then
        -- Aura events only rescan the player whose auras actually changed.
        RefreshUnitAura(arg1)
    elseif event == "SPELL_UPDATE_COOLDOWN" then
        -- Cooldowns are shared by spell slot, but this path never calls UnitBuff/
        -- UnitDebuff; it reuses each row's cached aura/debuff state.
        RefreshAllCooldowns()
        if RefreshSpellUsability then RefreshSpellUsability(false) end
        RefreshSpellCharges(false)
    elseif event == "SPELL_UPDATE_USABLE" then
        if RefreshSpellUsability then RefreshSpellUsability(false) end
    elseif event == "SPELL_UPDATE_CHARGES" then
        RefreshSpellCharges(false)
    elseif event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" or event == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
        local key = arg1 and tostring(arg1) or nil
        if key then
            CoAHealAssistInternal.procEventActive[key] = (event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW") and true or nil
            -- Update immediately so short passive/free-cast procs do not wait for
            -- the polling scheduler. The normal visual check remains a fallback.
            CoAHealAssistInternal.RefreshSpellProcGlows(false)
        end
    elseif event == "ACTIONBAR_SLOT_CHANGED" then
        -- Do not query the action slot here. Only invalidate our UI-object
        -- mirrors so discovery happens gradually in the lightweight scheduler.
        actionButtonChargeCache = {}
        actionChargeKnown = {}
        CoAHealAssistInternal.actionButtonFrameCache = {}
        CoAHealAssistInternal.actionButtonMissUntil = {}
        CoAHealAssistInternal.buttonChargeRegionCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcVisualCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcBaselineCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcBaselineReady = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.procDiscoverySlot = 1
        CoAHealAssistInternal.procOffSince = {}
        CoAHealAssistInternal.chargeDiscoverySlot = 1
    elseif event == "SPELLS_CHANGED" then
        actionButtonChargeCache = {}
        actionChargeKnown = {}
        CoAHealAssistInternal.actionButtonFrameCache = {}
        CoAHealAssistInternal.actionButtonMissUntil = {}
        CoAHealAssistInternal.buttonChargeRegionCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcVisualCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcBaselineCache = setmetatable({}, { __mode = "k" })
        CoAHealAssistInternal.buttonProcBaselineReady = setmetatable({}, { __mode = "k" })
        longAuraHintCache = {}
        CoAHealAssistInternal.spellProcCache = {}
        CoAHealAssistInternal.procOffSince = {}
        CoAHealAssistInternal.procEventActive = {}
        -- Do not auto-scan the CoA spellbook/tooltips here. The Aug 2026 client
        -- can assert in native CharacterAdvancement code on stale custom entries.
        -- Existing configured spell names remain usable; manual Scan All is
        -- intentionally the only opt-in path for tooltip discovery.
        if not IsInCombatSafe() then RebuildUnits() else pendingSecureRefresh = true end
    end
end)

CHA:SetScript("OnUpdate", function(self, elapsed)
    -- One lightweight scheduler replaces the old full-everything refresh that
    -- ran five times per second. Expensive aura scans are event-driven.
    auraLearnAccumulator = auraLearnAccumulator + elapsed
    timerAccumulator = timerAccumulator + elapsed
    statusAccumulator = statusAccumulator + elapsed
    fallbackAuraAccumulator = fallbackAuraAccumulator + elapsed
    cleansePulseAccumulator = cleansePulseAccumulator + elapsed
    manaCheckAccumulator = manaCheckAccumulator + elapsed
    chargeCheckAccumulator = chargeCheckAccumulator + elapsed
    CoAHealAssistInternal.procCheckAccumulator = (CoAHealAssistInternal.procCheckAccumulator or 0) + elapsed

    if #pendingAuraLearns > 0 and auraLearnAccumulator >= 0.10 then
        auraLearnAccumulator = 0
        ProcessPendingAuraLearns()
    elseif #pendingAuraLearns == 0 then
        auraLearnAccumulator = 0
    end

    -- Timer text does not query auras/cooldowns; it only uses cached timestamps.
    if timerAccumulator >= 0.25 then
        timerAccumulator = 0
        RefreshCachedTimers()
    end

    -- Range/dead/offline/health fallback is cheap and intentionally slower.
    if statusAccumulator >= 0.50 then
        statusAccumulator = 0
        RefreshAllStatus()
    end

    -- Ascension compatibility fallback: rescan only ONE row at a time. Even if
    -- UNIT_AURA is missed, a 40-man raid is gradually checked without CPU spikes.
    if fallbackAuraAccumulator >= 0.25 then
        fallbackAuraAccumulator = 0
        RefreshOneAuraFallback()
    end

    -- Cheap Ascension compatibility fallback: sample only the player's mana.
    -- We rescan spell usability only when the mana value actually changes, so
    -- this does not restore the old expensive per-row polling behavior.
    if manaCheckAccumulator >= 0.20 then
        manaCheckAccumulator = 0
        local mana = 0
        if UnitMana then
            local ok, value = SafeCall(UnitMana, "player")
            if ok then mana = tonumber(value) or 0 end
        elseif UnitPower then
            local ok, value = SafeCall(UnitPower, "player")
            if ok then mana = tonumber(value) or 0 end
        end
        if mana ~= lastPlayerMana then
            lastPlayerMana = mana
            if RefreshSpellUsability then RefreshSpellUsability(false) end
        end
    end

    -- Charge APIs/events vary between Ascension builds. At most 14 inexpensive
    -- checks twice per second keep custom charge spells accurate without a
    -- per-player scan.
    if chargeCheckAccumulator >= 0.50 then
        chargeCheckAccumulator = 0
        RefreshSpellCharges(false)
    end

    -- Proc checks use cached/direct objects. Only one spell per pass may run the
    -- deeper Ascension overlay discovery, preventing raid-scale frame scans.
    if (CoAHealAssistInternal.procCheckAccumulator or 0) >= 0.12 then
        CoAHealAssistInternal.procCheckAccumulator = 0
        CoAHealAssistInternal.RefreshSpellProcGlows(false)
    end

    -- A single animator services only the cleanse/proc buttons currently flashing.
    if cleansePulseAccumulator >= 0.05 then
        cleansePulseAccumulator = 0
        PulseActiveCleanseAlerts()
    end
end)
