# CoA Heal Assist

**Healium-style healing frames built specifically for Conquest of Azeroth / Project Ascension.**  
**Made by Overlord - Homeless Guild**

## Per-Character Profiles (v0.6.7)
Each character now has its own CoA Heal Assist profile. Spell slots, tracked buffs, cleanse settings, visible button count, frame visibility, positions, and layout are saved separately by Realm + Character Name. A brand-new character starts with a blank spell bar. Your old pre-v0.6.7 setup is preserved and automatically claimed by the character whose spellbook matches it.


> Version: **v0.9.4**  
> Addon type: Healing / Raid Frames / Click Casting  
> Game: Conquest of Azeroth / Project Ascension

## Why this addon exists

Healium is useful, but for CoA it can feel like important healer information is missing. CoA Heal Assist is built around seeing the things a healer needs immediately: health, your clickable spells, real cooldowns, tracked buffs/HoTs, and harmful effects that may need a cleanse.

### Separate Pets Frame
When **Pets** is enabled in Frames, player pets are shown in their own movable **Pets** window. Pets are never mixed into the owner's Party or Raid Group frame. The Pets window can be moved or closed independently and its position is saved per character.


## Features

- Minimap icon: left-click opens the full settings UI, right-click opens **Show / Hide Frames**, and drag moves the icon.
- Full in-game settings panel with general controls, all 14 spell slots, button layout, custom bleed tools, debuff debugging, and built-in field explanations.
- Drag a learned spell directly from your spellbook onto any visible healer-bar spell button while out of combat; that slot updates across every player row.
- Empty spell slots stay dark and static with no cooldown-finish bling/blue flashing.

- **Healium-inspired compact party/raid rows:** dark unit panel on the left with compact icon-only bars on the right.
- **Independent raid-group windows:** Group 1 through Group 8 are separate movable frames. Each group has its own close button; closing it only disables that group and it can be re-enabled from **Frames**. Manual positions are saved exactly and no longer snap through the toolbar scale.
- **Toolbar follows your group:** while raiding, the CoA Heal Assist title/control bar attaches directly above the raid subgroup that contains your character and moves with that group frame.
- **Dedicated Tanks / Main Tank frame:** checking **Tanks** creates a separate tank window and recognizes both modern Tank roles and the older Wrath/Ascension `MAINTANK` raid assignment.
- **Improved raid-marker tracking:** Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull use the Wrath shared raid-target texture sheet, refresh on the raid-target update event, and include older-client name/unit fallbacks.
- Existing blank `Removes` fields are automatically rescanned on load, spellbook changes, and when Settings opens.
- **Scan All** in Settings (or `/cha scanremoves`) retries tooltip detection for every configured spell with a blank `Removes` field.
- Drag/drop detection scans the exact spellbook slot for better compatibility with custom CoA spells.
- Adjustable **1-14 configurable click-to-cast spell buttons per player**.
- Adjustable icon-only spell-button size from **22-48 px**.
- Adjustable spacing from **0-12 px**.
- Drag-and-drop spell-slot reordering using the `::` handle; spell, aura and cleanse settings move together.
- Actual spell cooldown sweep plus numeric countdown.
- **Spell charge counts:** charge-based spells show the current charge number in the bottom-right of the spell icon. The addon tries spell-charge APIs first and falls back to the normal action-bar count for custom CoA abilities.
- **Ascension aura-timer normalization:** impossible custom-client expiration timestamps are clamped back to the aura's reported duration so short/30-minute buffs do not display bogus 1h+ timers.
- **Raid API hardening:** raid subgroup/role/aura calls are protected with conservative fallbacks to prevent custom-client nil bit-flag errors.
- Separate tracked buff / HoT remaining-time indicator.
- **Visible green HoT / shield / buff icons on each player row**, including remaining duration and stack count.
- Helpful buff icons use multiple fallbacks so custom CoA auras do not appear as blank timer boxes.
- Blizzard raid target markers (Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull) automatically appear beside marked players.
- Configured Track Buff/HoT auras are shown first; other timed buffs cast by you are also detected. Healer-bar auto-learning supports short HoTs/shields **and long buffs such as 30-minute or hour-long effects**, including CoA custom auras that omit caster data.
- When Track Buff/HoT is blank, a click from the healer bar can auto-learn one clear newly applied timed aura if the spell uses a different aura name.
- Harmful-aura display with special classification for:
  - Curse
  - Disease
  - Poison
  - Magic
  - Bleed
- **Automatic cleanse detection:** when a spell is assigned, the addon scans its spellbook tooltip for remove/cure/cleanse/dispel/purify wording and auto-fills Curse, Disease, Poison, Magic, and Bleed when found.
- Configurable/manual cleanse capability per spell slot remains available as an override.
- Only the exact cleanse-capable spell button flashes red when that player has a matching removable debuff; the player row itself stays normal.
- Custom CoA bleed database that can be extended in-game by spell ID.
- Debuff debug command for finding custom Ascension aura spell IDs/types.
- Tank / Healer / DPS role indicator where the client provides a role.
- Dead, Offline and Out-of-Range states.
- Movable and lockable main window.
- Reset Layout button.
- Reset Button Layout without erasing spell assignments.
- Reset Spells and Reset ALL controls.
- Test mode for previewing the UI without a raid.
- Saved settings across `/reload` and logins.
- Lowering the visible button count hides extra slots without erasing their saved spells.
- Spell fields support dragging a spell from the spellbook when the Ascension client exposes normal WoW cursor spell data.

> **Note:** an instant direct heal has no lasting aura to display. HoTs, shields, absorbs, and buffs do.


## My Buffs Only

The green helpful-aura strip is filtered to **your casts only**. Other healers' HoTs/shields, general raid buffs, food/world buffs, and unrelated target buffs are hidden. The grey "buff active" state also only reacts to an aura known to be yours. For custom CoA auras that omit caster information, the addon can establish temporary ownership when it directly observes the aura appear or refresh immediately after a cast from the healer bar.

## Installation

1. Download the release ZIP.
2. Extract it.
3. Put the `CoAHealAssist` folder into your game's `Interface\AddOns` folder.
4. Restart the client or type `/reload`.
5. Type `/cha test` to preview it.
6. Type `/cha config` to configure your spells.

Expected folder layout:

```text
Interface
└── AddOns
    └── CoAHealAssist
        ├── CoAHealAssist.lua
        ├── CoAHealAssist.toc
        └── README.txt
```


## Show / Hide Frames

Open the Healium-style frame menu from the **Frames** button, right-click the minimap icon, or type `/cha frames`.

You can enable/disable **Party, Me, Pets, Friends, Tanks, Healers, DPS**, and **Raid Groups 1-8**. Raid presets are included for 10-man (Groups 1-2), 25-man (Groups 1-5), 40-man (Groups 1-8), or Hide Raid.

**Friends** is a custom Healium-style list. A saved friend appears only while that character is also in your current party or raid. Target someone and use **Add Target Friend** in the Frames menu, or use `/cha friendadd Name`.

In raids, each checked raid subgroup is its own movable frame. The toolbar attaches to your own subgroup. Tanks/Main Tank can appear in a separate duplicate role frame while the same player remains in their normal subgroup.

## Minimap icon and full settings

A CoA Heal Assist icon appears around the minimap by default.

- **Left-click** the minimap icon to open/close the full settings window.
- **Right-click** it to open **Show / Hide Frames**.
- **Drag** it around the minimap to move it.
- The settings window can hide the minimap icon or reset its position.

The settings UI includes healer-frame visibility/lock controls, test mode, minimap visibility, scale, visible button count, bar height, spacing, global-cooldown display, solo hiding, all 14 spell slots, custom bleed ID add/remove tools, debuff debug buttons, reset controls, and an explanation of every spell-slot field and debuff letter.

Optional commands:

```text
/cha minimap
/cha minimap show
/cha minimap hide
/cha minimap reset
```

## Spell configuration

There are **14 saved spell slots**, and you choose how many are visible at once (1-14). Each slot has three fields:

| Field | What it does |
|---|---|
| Spell | Exact learned spell name or spell ID used for click casting and cooldowns |
| Track Buff / HoT | Aura name to track on the recipient; leave blank to track the spell name |
| Removes | Auto-filled from the spell tooltip when possible. You can manually override with `Curse,Disease,Poison,Magic,Bleed` |

Example:

```text
Spell: Your Cleanse Spell
Track Buff / HoT:
Removes: Curse,Disease
```

When a player has a Curse or Disease, that spell bar will flash red on that player's row. If the spell description says it removes those effects, the addon attempts to fill this field automatically.


## Automatic `Removes` detection

When you drag or assign a spell, CoA Heal Assist tries to read the spell's **actual spellbook tooltip**. If the description says the spell removes, cures, cleanses, dispels, or purifies one of these effects, `Removes` is filled automatically:

- Curse
- Disease
- Poison
- Magic
- Bleed

Example description: `Removes a Curse and a Poison effect.` → `Removes: Curse,Poison`.

This is designed for CoA custom spells so the addon does not need a fixed retail-WoW cleanse list. Tooltip wording can vary, so **manual editing always remains available**. If a custom spell is not detected correctly, enter its supported types yourself in the Removes field.

## Adjustable spell button count

Open `/cha config` and set **Visible spell buttons (1-14)**. The main healer frame automatically grows or shrinks to match.

You can also use:

```text
/cha buttons 5
/cha buttons 10
/cha buttons 14
```

Changing from 14 buttons down to 5 does **not** delete slots 6-14. Their spell, tracked aura and cleanse settings remain saved and return when you raise the visible count again.

For faster setup, drag a spell directly from your spellbook onto a **Spell** field or onto a visible healer bar. The addon immediately tries to read the spell description and fill **Removes** automatically. If Ascension does not expose normal cursor/tooltip data for a custom spell, type the spell name or spell ID and manually set Removes if needed.

## Spell-bar height, spacing, and reordering

Open `/cha config` to customize how the healing buttons are laid out:

- **Bar height:** 22-48 pixels. The icon-only button width and height scale together for a tight bar.
- **Spacing:** 0-12 pixels between buttons.
- **Reorder:** drag the `::` handle beside a spell slot and release it over another row.

Reordering moves the entire slot together, including the spell, tracked buff/HoT, and `Removes` settings. Click **Save & Apply** after arranging the slots.

The **Reset Button Layout** control restores the defaults of 8 visible bars, 32px height, and 5px spacing while keeping all 14 spell assignments.

You can also use:

```text
/cha buttonsize 36
/cha spacing 4
/cha resetbuttons
```

## Commands

```text
/cha
/cha config
/cha buttons <1-14>
/cha buttonsize <22-48>
/cha spacing <0-12>
/cha resetbuttons
/cha test
/cha reset
/cha resetspells
/cha resetall
/cha bleedadd <spellID>
/cha bleedremove <spellID>
/cha bleedlist
/cha debug target
/cha debug mouseover
/cha version
```

## Finding custom CoA debuffs

If a custom debuff is not classified correctly:

1. Target or mouse over the affected player.
2. Run `/cha debug target` or `/cha debug mouseover`.
3. Find the aura's `spellID` and API type in chat.
4. If it is a bleed, run `/cha bleedadd <spellID>`.

This makes the custom classification persist through reloads.

## Cooldown and buff display

The **center number** on a spell button is the spell's actual cooldown. The **small green number in the top-right** is the tracked buff/HoT duration on that specific player.

The normal global cooldown is hidden by default so every visible button does not appear to go on meaningful cooldown every time you cast. It can be enabled in Config.

## Combat behavior

Health, debuffs, buffs and cooldowns continue updating in combat. WoW protects secure click-cast button attributes, so roster changes and spell-button reassignment that occur during combat are queued and applied after combat ends.

## Credits

**Created by Overlord - Homeless Guild**

Built as an unofficial community addon for Conquest of Azeroth players. Project Ascension / Conquest of Azeroth and their game content belong to their respective owners.

## Bug reports

Please include:

- CoA Heal Assist version (`/cha version`)
- What you were doing
- Full Lua error text
- Screenshot if useful
- For aura problems, output from `/cha debug target` or `/cha debug mouseover`


## v0.4.2 Visual Healing Alerts
- Buff/HoT spell buttons grey out while their tracked aura is still active on that player.
- Buttons remain clickable so you can refresh a buff early if desired.
- If a player has a Curse, Disease, Poison, Magic effect, or configured Bleed that a spell slot can remove, that specific cleanse button flashes RED.
- The red cleanse warning overrides the grey buff state so urgent dispels remain obvious.
- Cleanse matching uses each spell slot's `Removes` setting.


### Mana-aware spell buttons
- Spell icons darken/desaturate when the game reports that you do not have enough mana to cast them.
- The addon checks `IsUsableSpell` once per configured spell slot and reuses that state across all player rows.
- Icons return to full color as soon as enough mana is available again.
- Cleanse alerts can still identify the correct cure with the red border, while the dim icon communicates that the spell is currently unaffordable.

## Performance

v0.6.0 replaces the old full-frame polling loop with event-driven updates:

- Health events update only the affected unit.
- Aura events rescan only the affected unit.
- Helpful auras are scanned once and reused for buff display/tracking.
- Cooldown events do not rescan buffs/debuffs.
- Countdown text uses cached timestamps.
- Red cleanse flashing uses one shared animator instead of one animation handler per spell button.
- A staggered fallback scans one row at a time for custom-client compatibility instead of rescanning the entire raid at once.

This is especially important in 25/40-player groups with many visible spell slots.


PROC / FREE-CAST MIRRORING
When the default Ascension/WoW action bar lights up a spell as proc-ready/free/instant, the matching CoA Heal Assist spell icon becomes a steady bright gold and displays PROC. The spell must exist on the normal action bar so the addon can safely mirror the client's own activation alert without querying risky custom action-slot APIs.



### v0.8.6 separate proc/charge mirror modes

Manual action-bar bindings can now mirror proc state and charge counts independently. This prevents a proc-only spell from inheriting a neighboring Ascension charge counter. Use `/cha barmode <slot> both|proc|charge`, or specify the mode while binding: `/cha barbind <slot> both|proc|charge`.

### v0.8.5 mouse action-bar binding
If Ascension custom action buttons cannot be auto-detected, hover the matching normal action-bar spell and run `/cha barbind <Heal Assist slot>`. The addon caches that exact frame and saves a resolvable binding when possible. Use `/cha barunbind <slot>` to clear it. This adds no continuous full-screen scan.


### v0.8.9 persistent helpful-aura source mapping
- Remembers aura -> Heal Assist spell-slot ownership for the whole login session.
- Reuses the exact source spell button icon when CoA drops caster/icon metadata on later aura refreshes.
- Builds the small helpful-aura strip after spell buttons establish tracked-aura ownership, improving mixed custom-aura icon reliability.

### v0.8.8 direct helpful-aura icon copy
- Helpful buff/HoT/shield icons now copy the texture directly from the matching Heal Assist spell button already rendering in the same row.
- Spell buttons refresh before the helpful-aura strip so custom CoA aura APIs cannot leave an empty timer box before the casting spell icon is available.
- Missing source-slot data is recovered from the row's tracked aura, and the spell icon's texture coordinates are copied too for custom textures/atlases.
