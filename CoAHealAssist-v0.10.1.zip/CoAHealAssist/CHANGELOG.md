## v0.10.0
- Added Settings toggle to hide/show the small My Buff/HoT/Shield icons beside unit names.
- Added optional blue shield/absorb overlay on health bars using UnitGetTotalAbsorbs when the Ascension client exposes it.
- Preserves v0.9.9 Ascension Safe Mode startup protections.

# v0.9.4
- Removed the gameplay title/toolbar: addon name, version, Lock, Reset, Frames, Config, and close buttons are no longer shown above the healer rows.
- Party/solo healer UI is now compact/content-only; raid mode no longer leaves a blank toolbar above the player subgroup.
- Consolidated management in Settings opened from the minimap icon: Show healer frame, Lock position, Show / Hide Frames, Reset Layout, minimap controls, and version/author.
- Both left- and right-click on the minimap icon open Settings; dragging the minimap icon still moves it.

## 0.9.1
- Replaced the fragile live-aura icon resolver with a deterministic slot-driven helpful-aura strip.
- A displayed buff/HoT/shield tracker now exists only when a configured Heal Assist spell button is actively tracking that aura.
- Tracker slot N always copies Heal Assist spell slot N's already-working icon; the aura supplies only timer/stack data.
- Generic personal buffs that cannot be tied to a configured Heal Assist spell are no longer added to the small green strip, eliminating blank custom-aura boxes.
- Uses the same fixed icon crop as the main spell buttons and no longer copies UnitBuff/action-button texture coordinates for helpful-aura icons.

## 0.9.0
- Fixed the remaining blank helpful buff/HoT/shield icons on Wrath/CoA clients.
- Correctly handles the 8-coordinate return format from `Texture:GetTexCoord()` when copying a visible Heal Assist spell icon into the small green aura strip.
- Prevents the copied aura icon crop from collapsing to zero width while preserving custom texture coordinates when available.
- Keeps the existing persistent aura-to-spell source mapping, per-character profiles, charge/proc bindings, and performance-safe cached action-bar mirroring.

## 0.8.9
- Fixed remaining intermittent blank helpful buff/HoT/shield icons on Ascension custom auras.
- Added session-persistent aura-to-spell-slot ownership mapping so later UnitBuff refreshes can reuse the exact source spell icon even when CoA omits caster/icon metadata.
- Helpful-aura strip is now built after spell buttons establish their tracked aura, making source-slot recovery deterministic.

## 0.8.6

- Split manual action-bar mirroring into independent `both`, `proc`, and `charge` modes.
- Added `/cha barmode <1-14> both|proc|charge` so an existing binding can be changed without rebinding.
- Added optional mode to `/cha barbind <1-14> [both|proc|charge]`.
- Proc-only bindings now suppress all charge display paths, including misleading custom-client `GetSpellCharges` results and neighboring action-bar counters.
- Charge-only bindings suppress proc highlighting.
- Keeps the cached low-FPS-cost action-bar mirror architecture from v0.8.1+.

## 0.8.5
- Fixed manually-bound charge/proc spells showing `PROC` permanently.
- Added one-time per-action-button idle visual calibration so Ascension's always-visible border/ADD textures are treated as normal button chrome, not a proc.
- A baseline texture that later disappears is automatically armed; its next appearance can trigger the proc alert. Low-alpha idle overlays can also trigger only when they brighten meaningfully above baseline.
- Baseline discovery remains staggered/cached, preserving the v0.8.1+ FPS optimizations. Charge mirroring/manual bindings are unchanged.

# CoA Heal Assist Changelog

## v0.9.4
- Replaced the pulsing proc/free-cast alert with a steady bright-gold ready state.
- Proc-ready buttons remain solid gold until the proc is consumed/expires; visual pulse dips no longer affect the Heal Assist highlight.
- Increased gold fill/border visibility while preserving the separate bright-red cleanse warning.
- Removed proc alpha animation work while keeping cached detection, action-bar bindings, overlay events, and the proc-off debounce.

## v0.8.4
- Added performance-safe `/cha barbind <1-14>` mouse binding for Ascension custom action buttons that cannot be matched by texture or hotkey text.
- Manual action-button mappings are cached immediately and saved per character when the frame can be resolved after reload.
- Added `/cha barunbind <1-14>`.
- Binding performs a one-time deep read for charge/proc regions; normal gameplay uses cached objects only.
- Keeps the v0.8.1+ FPS protections and does not restore continuous full-screen scanning.

## v0.8.3
- Added an Ascension-specific low-cost action-button fallback for charge/proc mirroring.
- If identical spell icons expose incompatible texture identifiers, Heal Assist can discover the visible `A1`, `A2`, `A3`, etc. action button that corresponds to the configured healer-bar slot.
- The matched action button is cached, so the fallback discovery scan is not repeated during normal updates and does not reintroduce the v0.8.0 FPS regression.
- `/cha bardebug <slot>` now reports failure only after both icon matching and the `A<slot>` hotkey hint fail.

## v0.8.2
- Fixed `/cha bardebug <slot>` crashing because it referenced a nonexistent `ResolveConfiguredSpell()` helper.
- Debug now uses the existing safe spell normalizer and preserves the saved custom CoA spell ID for accurate charge/proc diagnostics.
- No changes to the normal cached charge/proc polling path, so v0.8.1 FPS improvements are preserved.

## v0.8.1
- Performance hotfix for the Ascension charge/proc action-bar mirror.
- Cached action-button matches are now trusted instead of recursively texture-scanned every poll.
- Cached charge FontStrings are read directly after discovery.
- Deep custom-frame discovery is staggered to one spell slot at a time instead of every spell on every update.
- Failed custom action-button lookups are throttled for 30 seconds to prevent repeated thousands-of-frame scans.
- ACTIONBAR_SLOT_CHANGED only invalidates caches; it does not query protected action-slot APIs.
- Keeps charge/proc mirroring without restoring the old raid-scale FPS cost.

# CoA Heal Assist v0.8.0

- Improved instant-cast/free-cast proc mirroring for Ascension custom action bars.
- Uses `IsSpellOverlayed()` when the client exposes it.
- Detects anonymous additive/gold proc overlays several child levels deep on the matching visible action button.
- Includes the v0.7.8 visible custom-action-bar charge detection improvements.

## v0.8.0
- Charge mirroring now finds custom Ascension action buttons by visible spell texture, including anonymous/custom frames.
- Charge text detection recursively scans child FontStrings and prioritizes bottom-right standalone numbers while rejecting top-right hotkeys.
- Hidden Blizzard action buttons are ignored so they cannot mask the visible CoA action bar.
- Does not use GetActionInfo/GetActionCount, preserving the SharedXML bit.lua safety workaround.

## v0.8.0 - CoA unit icons & charge mirroring

- Unknown/custom debuffs no longer draw a `?` over unit rows; missing icons resolve through spell ID/name before a safe harmful-icon fallback.
- Raid markers let Ascension's protected classic marker helper override atlas coordinates when available, fixing custom raid-marker sheets without risking addon load failure.
- Charge mirroring recognizes `Charges`/`ChargeCount` fields and anonymous pure-number FontStrings on normal action buttons while ignoring hotkey labels such as `A1`/`A2`.
- Charge/proc action-button matching now prefers the exact icon already rendered in the corresponding healer spell slot, improving custom CoA spell matching.

# CoA Heal Assist Changelog

## v0.7.6
- Fixed charge-based direct heals being misidentified as buff/HoT spells after casting.
- Multi-charge spells no longer auto-learn an aura unless their tooltip actually describes a lasting effect.
- Preserves manual Track Buff/HoT/Shield entries for legitimate charged HoTs and shields.
- Hardened detection of the player row in raids/parties using UnitGUID/name fallbacks when UnitIsUnit is unreliable on Ascension.
- Clears stale auto-learned aura data for non-aura charge heals on the next cast, preventing bogus 18m/23m/53m green timers and grey buttons.

## v0.7.5
- Fixes persistent bogus 18m/23m grey spell buttons that appeared only on the player row.
- Long self auras are no longer inferred from spell name, spell ID, or tooltip duration.
- A long self aura now requires either a direct healer-bar cast claim or an explicitly edited Track Buff/HoT/Shield field.
- Track-aura fields now remember whether they were auto-learned or manually edited, preventing old auto-learned self auras from being treated as manual configuration.
- Existing short-duration HoT/buff tracking and direct-cast learning remain unchanged.

## v0.7.4
- Fixed long self/passive auras incorrectly greying a spell button and showing 20m-50m timers on only the player's own row. Long self auras now require a direct observed cast or a matching advertised long duration.
- Improved CoA custom-spell icon resolution by using the saved spellbook slot texture when name/ID texture lookup fails.
- The generic question-mark icon is no longer cached as a valid spell-slot icon.

## v0.7.3
- Added default-action-bar proc/free-cast mirroring. When the normal action bar lights up a spell as proc-ready, the matching CoA Heal Assist spell button now gets a pulsing gold `PROC` alert.
- Proc detection reads already-rendered action-button UI state rather than querying protected/custom action-slot APIs.
- Proc state is checked once per spell slot and reused across every party/raid row to keep raid performance light.
- Gold proc alerts and bright-red cleanse alerts can coexist; red still identifies the exact cure spell for that player.
- Kept the Lua 5.1 main-chunk local count below the 200-local hard limit.

## v0.7.2 - Lua 5.1 local-variable compatibility fix

- Fixed `main function has more than 200 local variables`, which prevented the addon from compiling/loading on the CoA Lua 5.1 client.
- Moved late UI/control helpers into the `CoAHealAssistInternal` namespace so the main chunk stays below the 200-local hard limit.
- No healer features or per-character settings were removed.
- Existing SavedVariables remain compatible.

# Changelog

## v0.7.1
- Removed `GetActionInfo`, `GetActionCount`, `C_Spell.GetSpellCharges`, and `ACTIONBAR_SLOT_CHANGED` from the charge fallback to avoid Ascension SharedXML nil bitmask errors.
- Charge counts now mirror the number already rendered on matching Blizzard/Ascension action buttons by comparing spell icons and reading the button Count font string.
- Removed the `SetRaidTargetIconTexture` helper call and name-based raid-marker query fallback; raid markers use direct unit tokens plus manual atlas coordinates only.
- Keeps v0.7.0 long-buff validation and all per-character/frame features.

## v0.7.1 - CoA action-bar charges & tracked-aura timer validation

- Added an Ascension/Wrath fallback that reads custom spell charge counts from the same action-slot count data used by the normal action bar when `GetSpellCharges` is unavailable.
- Charge counts are cached per spell/action slot and refresh on action-bar changes plus the existing lightweight charge timer.
- Long tracked auras with a different name from their casting spell are now validated against direct cast ownership or an advertised tooltip duration before they can grey a spell button/show a long timer.
- This prevents unrelated long buffs/procs from being auto-learned as bogus `53m` timers on healing buttons while preserving legitimate long-duration buffs.

# Changelog

## v0.6.9

- Pets now use a dedicated Healium-style **Pets** frame instead of appearing inside Party or Raid Group 1-8 frames.
- The Pets frame is independently movable, closable, and saved per character, just like the Tanks / Main Tank frame.
- Closing the Pets frame only disables the Pets option; re-enable it from **Frames > Pets**.
- Pet-frame position is included in Reset Layout.

## v0.6.8

- Fixed a Lua 5.1 function-order bug where raid/party layout code could call `ApplyMainPosition()` before the local function was declared, causing `attempt to call global 'ApplyMainPosition' (a nil value)`.
- Added an explicit forward declaration so party/solo layout and the raid-toolbar fallback resolve the correct local function.
- Kept the v0.6.7 per-character profile migration and blank-new-character behavior unchanged.

# CoA Heal Assist Changelog

## v0.6.7
- Added true per-character profiles keyed by Realm + Character Name.
- Spell slots, tracked buffs/HoTs/shields, Removes data, button count/layout, frame visibility, group/tank positions, minimap settings, and other healer UI settings are now saved separately for each character.
- Brand-new characters start with a blank spell bar instead of inheriting another character's spells.
- Added a safe one-time migration for the pre-v0.6.7 account-wide profile: it is only claimed by a character whose spellbook actually matches the saved spells, preventing unrelated alts with question-mark icons from stealing the old healer setup.
- Reset All now resets only the currently logged-in character's CoA Heal Assist profile.

## v0.6.6
- Fixed Blizzard raid target markers (Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull) by using the shared Wrath raid-target texture sheet correctly.
- Raid marker icon is drawn above the unit name/health area with a stronger overlay layer.
- Raid Group 1-8 and Main Tank frames are now direct UIParent windows so dragging them no longer snaps due to inherited main-frame scale.
- Manual frame positions save the exact drag anchor/offset and are preserved across roster rebuilds. Legacy v0.6.5 panel coordinates are ignored once so the old snap/scale offsets do not carry forward.
- In raids, the CoA Heal Assist title/control toolbar automatically attaches directly above your own raid subgroup frame and moves with that frame.
- Dragging the attached toolbar moves your own group frame and saves that position.
- Leaving a raid restores the normal saved toolbar position.
- Keeps all v0.6.4/v0.6.5 spell, tooltip, charge, cleanse, aura, performance, and frame controls.


## v0.6.5 - Independent raid groups, Main Tank frame & raid-marker fixes

- Raid Group 1 through Raid Group 8 are now **separate movable windows** instead of panels locked inside one large container.
- Every raid-group window has its own **X** button. Closing a group only disables that group; it can be re-enabled from the Frames menu.
- Group positions are saved independently. The main **Reset** button now also resets all group and tank-frame positions.
- Added a dedicated **Tanks / Main Tank** window when the Tanks option is enabled.
- Main Tank detection now reads the older Wrath/Ascension `GetRaidRosterInfo()` role value (`MAINTANK`) in addition to modern role APIs and `GetPartyAssignment`.
- Main Tank/Tank rows can appear in the dedicated tank frame while still remaining in their normal raid subgroup.
- Increased the secure row pool to allow normal 40-player raid rows plus tank-frame duplicates without changing per-row update frequency.
- Added `RAID_TARGET_UPDATE` handling so Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull refresh immediately when raid markers change.
- Added extra raid-marker lookup fallbacks for custom Ascension unit/name behavior and an older-client icon texture fallback.
- Event-driven performance work from v0.6.0 remains intact; duplicate tank rows reuse the same cached spell usability/cooldown/charge data.

## v0.6.4 - Ascension compatibility, timer fixes & spell charges

- Hardened raid subgroup, role, aura, cooldown, mana and charge API calls against custom-client nil/flag errors.
- Replaced subgroup panel Backdrop usage with simple textures to avoid an Ascension SharedXML bit-flag failure path.
- Normalizes helpful/harmful aura duration and expiration values; impossible expiration timestamps fall back to the aura's reported duration instead of showing bogus 1h+ timers.
- Added charge counters to spell buttons. Charge-based spells show the current count in the bottom-right corner when the client exposes a supported charge API.
- Added `SPELL_UPDATE_CHARGES` support when available plus a lightweight 0.5-second charge fallback shared across spell slots, not per raid member.
- Charge state is queried once per spell slot and reused across all player rows to preserve v0.6.0 performance improvements.

## v0.6.2 - Real raid group frames

- Fixed Raid Group 1-8 checkboxes behaving only as roster filters instead of actual visible frames.
- Raid mode now creates labeled Group 1 through Group 8 panels, like Healium.
- Checked raid-group panels remain visible even when that subgroup is currently empty.
- Raid members are assigned from the subgroup returned by `GetRaidRosterInfo`, not inferred from the `raidN` number.
- Raid members are sorted into subgroup order before secure click-cast assignments are built.
- Me/Friends/role overrides still work and can surface a normally hidden subgroup when needed.
- Group panels use two columns when the spell bar is compact enough to reduce vertical screen usage.
- Secure roster/layout changes remain out-of-combat only.

## v0.6.1 - Mana-aware spell usability

- Spell icons now darken/desaturate when `IsUsableSpell` reports not enough mana.
- Mana usability is calculated once per visible spell slot and shared across all party/raid rows.
- Added `SPELL_UPDATE_USABLE` handling plus a lightweight player-mana-change fallback for Ascension compatibility.
- Buff-aura learning is no longer queued after clicking a spell while the addon already knows you lack enough mana.
- Added tooltip feedback for the not-enough-mana state.


## v0.6.0 - Performance update
- Replaced the old full party/raid refresh every 0.20 seconds with event-driven updates.
- `UNIT_HEALTH` / `UNIT_MAXHEALTH` now update only the affected player's health/status row.
- `UNIT_AURA` now rescans buffs/debuffs only for the affected player instead of every visible player.
- Spell cooldown events reuse cached aura/debuff state and no longer trigger a full aura rescan.
- Helpful buffs are collected once per aura refresh and reused, removing duplicate `UnitBuff` scans.
- Cooldown, buff, HoT and debuff countdown text now ticks from cached expiration times without querying the game API again.
- Replaced one red-cleanse `OnUpdate` handler per spell button with one shared animator that only touches currently flashing buttons.
- Added a staggered Ascension compatibility fallback that rescans one unit at a time instead of all raid rows at once.
- Health/range/dead/offline fallback refresh is throttled separately from aura scanning.
- Existing settings and SavedVariables migrate without changes.

## v0.5.9 - Exact Cleanse Button Alert

- Removed the old red player-row border for Curse/Disease/Poison/Magic/Bleed.
- The player/health row now stays visually neutral when debuffed.
- Only the exact visible spell button whose `Removes` setting matches the active debuff pulses bright red.
- If none of the visible 1-14 spell slots can cure the debuff, no cleanse button flashes.
- Test mode follows the same exact-button-only behavior.

## v0.5.8 - Ascension Tooltip Scanner Fix
- Reworked `Removes` auto-detection for custom CoA spells using multiple hidden-tooltip paths.
- Forces the hidden tooltip to render before reading text, fixing clients that do not populate tooltip FontStrings while hidden.
- Reads both named tooltip lines and every FontString region for Ascension template compatibility.
- Tries exact spellbook slot, spell ID, spell hyperlink, and `GetSpellLink` routes.
- Stores the dragged spellbook slot/type/ID so future rescans can use the exact custom spell entry.
- `Scan All` now reports per-slot results in chat instead of silently leaving fields empty.
- Added conservative CoA fallback data for Antivenom and Blight Antidote when the client exposes no tooltip text at all.

## v0.5.7
- Fixed blank helpful-buff icons by caching the exact spell-button texture at cast time and attaching it to the learned/owned aura.
- Added stronger icon fallbacks and forces normal vertex color/alpha on helpful aura textures.
- Cleanse warnings are now much brighter with a thicker, high-contrast red pulse.
- Red cleanse warning is strict: only the specific assigned bar spell whose `Removes` types match the player debuff can flash.
- Debuffs that none of the visible configured bar spells can remove do not create a false red spell warning.

## v0.5.7
- Fixed Ascension secure-frame taint error: `CoAHealAssist prevented the call of the secure function <unnamed>:Show()`.
- Combat refreshes no longer call Show/Hide on protected healer rows, secure-button cooldown frames, or cleanse alert frames.
- Cooldown/cleanse visibility now uses alpha so timers and red cleanse warnings can still update in combat.
- Visual rows stay locked to the exact unit tokens assigned to secure click-cast buttons until combat ends.
- Roster/layout changes made during combat are queued and rebuilt after `PLAYER_REGEN_ENABLED`.
- Added combat guards to reset actions that would move/rebuild protected frames.

## v0.5.5 - Buff Icon Fallback + Raid Target Markers
- Fixed blank green buff/HoT/shield icons on CoA auras that return an empty, zero, or missing texture.
- Helpful aura icons now fall back through: aura texture -> tracked spell-slot icon -> aura spell ID/name -> safe shield icon.
- Added automatic Blizzard raid target markers on healer rows: Star, Circle, Diamond, Triangle, Moon, Square, Cross, and Skull.
- Raid markers follow the game marker assigned to that unit and update during normal row refreshes.
- The name/role area shifts only when a raid marker is present, keeping unmarked rows compact.

## v0.5.4 - My Buffs Only + Frame Selection
- Helpful aura icons now show **only buffs/HoTs/shields cast by you**.
- Other healers' HoTs/shields, raid buffs, food/world buffs and unrelated target buffs are no longer copied into the green aura strip.
- The grey "buff already active" spell-button state now also requires the tracked aura to be yours.
- For CoA custom auras that omit caster information, the addon can temporarily prove ownership by observing the aura appear or refresh immediately after you cast that spell from CoA Heal Assist.
- Removed the old generic unknown-caster buff fallback that could display unrelated buffs.
- Includes the v0.5.3 Healium-style **Show / Hide Frames** controls for Party, Me, Pets, Friends, Tanks, Healers, DPS and Raid Groups 1-8, with 10/25/40-man presets.


## v0.5.3 - Healium-style Show / Hide Frames
- Added a dedicated **Show / Hide Frames** popup inspired by Healium.
- Added visibility toggles for **Party, Me, Pets, Friends, Tanks, Healers, and DPS**.
- Added individual **Raid Group 1-8** toggles.
- Added raid presets: **Hide Raid**, **Groups 1-2 (10 man)**, **Groups 1-5 (25 man)**, and **Groups 1-8 (40 man)**.
- Added a **Frames** button to the main healer window and Settings.
- Right-clicking the minimap icon now opens the frame visibility popup; left-click still opens Settings.
- Added a Healium-style custom Friends list. Friends only appear when they are also in your current party/raid.
- Added **Add Target Friend**, **Remove Target**, and **List** controls in the Frames popup.
- Added `/cha frames`, `/cha friendadd`, `/cha friendremove`, `/cha friendlist`, and `/cha friendclear`.
- Frame selection settings migrate automatically from older versions; existing users keep the prior default behavior (Party + Me + all raid groups visible).
- Role/Friend selections can include matching group members even when their normal raid group/party view is hidden.

## v0.5.2
- Keeps the new tight icon-only Healium-style healer buttons.
- Fixes automatic `Removes` detection for pre-existing spell assignments by rescanning blank fields automatically.
- Drag/drop now scans the exact dragged spellbook slot, improving compatibility with custom Ascension/CoA spells.
- Added broader cleanse wording detection (remove, cure, cleanse, dispel, purify, abolish, neutralize, decurse).
- Added **Scan All** in Settings and `/cha scanremoves` as a manual retry.
- Automatically retries blank cleanse detection when the spellbook changes.

## v0.5.1
- Removed spell-name text from healer-bar buttons for a tighter Healium-style layout.
- Spell buttons are now icon-only and use the configured button size as their width.
- Spell names remain available in mouseover tooltips.
- Preserves cooldown timers, buff timers, grey active-buff state, flashing-red cleanse alerts, and spellbook drag/drop.

## v0.5.0 - Healium-style bars + automatic cleanse detection
- Restyled the main healer UI to more closely match Healium: compact dark rows with the player panel on the left and rectangular spell bars on the right.
- Spell bars now show the spell **icon and abbreviated spell name** instead of icon-only square buttons.
- Buff/debuff icons remain visible in a compact strip inside the player panel.
- Button Size now acts as the Healium-style spell-bar height; bar width scales automatically so names remain visible.
- Direct spellbook drag/drop onto the healer bars is retained.
- Added automatic `Removes` detection by reading the assigned spell's actual spellbook tooltip/description.
- Recognizes tooltip wording that removes/cures/cleanses/dispels/purifies **Curse, Disease, Poison, Magic, and Bleed**.
- Dragging a new spell into a slot immediately tries to fill its `Removes` field.
- Typing a spell in Settings can auto-fill `Removes` when the field is blank; changing a spell also re-detects cleanse types unless you manually edited `Removes`.
- Manual `Removes` entries still override automatic detection for custom CoA wording the scanner does not understand.
- Replacing a spell no longer carries the old spell's learned aura into the new slot when that aura field was not manually changed.
- Debuff borders use a flat non-additive style to reduce the chance of Blizzard glow/bling artifacts on the Ascension client.

## v0.4.4
- Long-duration buffs are now fully supported by healer-bar aura auto-learning.
- Removed the old 120-second limit for newly detected CoA custom auras that do not report a caster token.
- 30-minute and hour-long buffs can now be learned into `Track Buff / HoT`, shown as green aura icons, and grey their spell button while active.
- When the tracked buff expires or is removed, its green icon disappears and the spell button returns to full color so it is clear the buff needs to be reapplied.
- Long timers now use cleaner hour/minute formatting (for example `1h30m`).

## v0.4.3
- Added a separate green helpful-aura strip on every player row.
- HoTs, shields, and timed buffs you apply are now shown as icons with remaining time and stack count, similar to debuffs.
- Configured `Track Buff / HoT` auras are prioritized so the most important healer effects stay visible.
- Also detects other timed helpful auras cast by the player.
- Added a Conquest of Azeroth fallback for short timed helpful auras when the custom client does not report a caster token.
- Helpful-aura icons use a plain green border and do not use Blizzard additive glow textures.
- Test mode now includes sample HoT/shield icons.
- Added healer-bar aura auto-learning: when Track Buff / HoT is blank and one clear new timed aura appears after your click, the addon stores that aura name for the slot.

## v0.4.2
- Buff/HoT buttons now grey out while the configured tracked aura is active on that specific player.
- Greyed buttons remain clickable for manual early refreshes.
- Matching cleanse buttons now pulse/flash RED when the player has a configured removable Curse, Disease, Poison, Magic effect, or Bleed.
- Red cleanse warning takes priority over buff greying.
- Uses a custom red pulse instead of Blizzard action-button glow textures to avoid the Ascension blue-flash issue.

## v0.4.1

- Fixed the blue flashing/bling that could appear on empty spell buttons.
- Empty slots now use a plain dark static background with the slot number.
- Cooldown widgets stay hidden unless a real cooldown is active, preventing repeated cooldown-finish animations on custom/older clients.
- Replaced the additive Blizzard action-button glow on healer spell buttons with a static cleanse-alert border.
- Added direct drag-and-drop from the spellbook onto the actual healer-bar spell buttons.
- Dropping a spell onto a slot updates that slot for every party/raid row and syncs it back to Settings.
- Direct healer-bar spell assignment is blocked during combat to avoid protected-action errors.

## v0.4.0

- Added a movable minimap icon using a healing spell icon.
- Left-click minimap icon opens/closes the full settings UI.
- Right-click minimap icon shows/hides the healer frame.
- Added settings for healer-frame visibility, frame lock, minimap icon visibility, and test mode.
- Added Reset Minimap Icon and Show/Hide Frame controls.
- Added custom bleed Spell ID add/remove/list controls directly in settings.
- Added Debug Target and Debug Mouseover buttons for custom CoA aura troubleshooting.
- Added a built-in guide explaining Spell, Track Buff/HoT, Removes, cooldown text, debuff letters, and minimap controls.
- Added `/cha minimap [show|hide|reset]`.
- Existing v0.3.0 spell slots and layout settings migrate automatically.

## v0.3.0 - Adjustable button layout and drag reordering

- Added adjustable spell-button size from 22 to 48 pixels.
- Added adjustable spacing between spell buttons from 0 to 12 pixels.
- Added drag-to-reorder spell slots using a dedicated `::` handle in the config window.
- Reordering moves the spell, tracked aura, and cleanse/removal settings together.
- Added automatic healer-row width and height resizing for larger/smaller buttons.
- Added **Reset Button Layout** to restore 8 visible buttons, 32px size, and 5px spacing without erasing spell assignments.
- Added `/cha buttonsize <22-48>`, `/cha spacing <0-12>`, and `/cha resetbuttons`.
- Preserves all existing v0.2.0 saved spell slots and settings during upgrade.

## v0.2.0 - Adjustable spell buttons

- Expanded the addon from 8 saved spell slots to 14.
- Added a configurable visible spell-button count from 1 to 14.
- Main party/raid rows automatically grow or shrink with the selected button count.
- Hidden higher-numbered slots keep their saved spell/aura/cleanse configuration.
- Added `/cha buttons <1-14>` for quick button-count changes.
- Added spellbook drag/drop support for Spell fields when supported by the Ascension client.
- Preserves existing v0.1.0 slot configuration when updating.

## v0.1.0 - Initial test release

- Added Healium-style party/raid healer rows.
- Added 8 configurable secure click-to-cast spell slots.
- Added spell cooldown sweeps and countdown text.
- Added recipient buff/HoT timer tracking.
- Added Curse, Disease, Poison, Magic and Bleed debuff display.
- Added configurable cleanse highlighting.
- Added persistent custom bleed spell-ID classification.
- Added aura debug command for CoA custom debuffs.
- Added role, dead, offline and range states.
- Added movable/lockable UI.
- Added Reset Layout, Reset Spells and Reset ALL.
- Added test mode.

## v0.6.4
- Added Shift + Right-click on a healer-bar spell icon to clear that slot out of combat.
- Clearing a slot also clears its tracked buff/HoT, cleanse types, spellbook metadata, cooldown/mana/charge caches, and pending aura-learning work.
- Added a **Show spell tooltips** setting. Turn it off to make spell-button mouseover show nothing.
- Added `/cha tooltips on|off` and `/cha clearslot <1-14>`.


## 0.8.8
- Fixed remaining blank helpful-aura icons by copying the already-rendered matching Heal Assist spell-button texture directly into the green buff/HoT/shield strip.
- Reordered row aura refresh so spell buttons establish tracked aura/source textures before buff-strip icons render.
- Added source-slot recovery from tracked aura identity and copied source texture coordinates for custom CoA textures.
