CoA HEAL ASSIST v0.6.6
Made by Overlord - Homeless Guild

## Per-Character Profiles (v0.6.7)
Each character now has its own CoA Heal Assist profile. Spell slots, tracked buffs, cleanse settings, visible button count, frame visibility, positions, and layout are saved separately by Realm + Character Name. A brand-new character starts with a blank spell bar. Your old pre-v0.6.7 setup is preserved and automatically claimed by the character whose spellbook matches it.


WHAT IT IS
A standalone Healium-style healer addon for Conquest of Azeroth / Project Ascension.

MAIN FEATURES
- Visible green HoT/shield/buff icons with timers on each player row — YOUR CASTS ONLY.
- Buff icons fall back to the casting spell icon when a custom CoA aura reports no usable texture.
- Game raid markers (Star/Circle/Diamond/Triangle/Moon/Square/Cross/Skull) show automatically beside marked players using the Wrath raid-target icon sheet.
- Raid Group 1-8 windows save exact manual positions without snapping; while raiding, the CoA Heal Assist toolbar attaches above your own subgroup and moves with it.

- Minimap icon: left-click opens the full settings UI, right-click opens Show / Hide Frames, and drag moves the icon.
- Full in-game settings panel with general controls, all 14 spell slots, button layout, custom bleed tools, debuff debugging, and built-in field explanations.
- Click-to-cast healing/utility spell buttons for party and raid members.
- Adjustable 1-14 visible spell buttons, with 14 saved spell slots.
- Tight Healium-style icon-only spell buttons; spell names are shown on mouseover.
- Adjustable spell-bar height from 22 to 48 pixels; bar width scales automatically.
- Automatically scans assigned spell descriptions to fill Removes for Curse, Disease, Poison, Magic and Bleed when the tooltip says the spell removes/cures/cleanses/dispels/purifies them.
- Adjustable spacing between spell buttons from 0 to 12 pixels.
- Drag the :: handle beside a spell slot to reorder it; spell, aura and cleanse settings move together.
- Real spell cooldown sweeps and numeric cooldown countdowns.
- Charge-based spells show their current charges as a small number in the bottom-right of the spell icon. Custom CoA spells can fall back to the normal action-bar count when spell-charge APIs are unavailable.
- Custom CoA aura timers are normalized so invalid expiration timestamps do not create fake 1h+ countdowns.
- Raid/aura compatibility calls use safe fallbacks to avoid nil bit-flag errors on Ascension builds.
- Buff / HoT timer tracking on each spell button.
- Shows harmful auras and highlights Curse, Disease, Poison, Magic and Bleed.
- Only the exact cleanse spell button flashes red when its configured dispel type matches a debuff on that player; the player row itself stays normal.
- Custom bleed spell-ID list for CoA auras that the normal WoW API does not classify.
- Health %, role, dead, offline and out-of-range indicators.
- Movable/lockable frame.
- Reset Layout, Reset Button Layout, Reset Spells and Reset ALL controls.
- Test mode with sample debuffs plus sample HoT/shield buffs.
- Custom debuff debug command to print aura spell IDs and API types.

INSTALL
1. Extract the CoAHealAssist folder.
2. Put the folder in your Ascension / Conquest of Azeroth Interface\AddOns folder.
3. Restart the game or /reload.
4. Type /cha test to preview the UI.
5. Type /cha config to enter your healing and cleanse spells.
6. Choose how many spell buttons you want visible, from 1 to 14.
7. Adjust bar height/spacing if desired and drag the :: handles to reorder slots.

CONFIGURING SPELL BUTTONS
Visible spell buttons:
  Choose any number from 1 to 14.
  Lowering the number only hides extra slots; their saved spells are kept.

Bar height:
  Set from 22 to 48 pixels. The icon-only button width and height scale together to keep the bar compact.

Button spacing:
  Set from 0 to 12 pixels.

Reordering:
  Drag the :: handle beside a slot and release it over another spell row.
  The spell, tracked aura and Removes settings move together.
  Click Save & Apply when finished.

Spell:
  Enter the exact learned spell name OR a spell ID.
  You can also try dragging a spell from your spellbook onto the Spell field.

Track Buff / HoT:
  Enter the aura name that should be tracked on the recipient.
  Leave blank if the buff/HoT has the same name as the spell.
  When left blank, the addon can also auto-learn one clear new timed aura created by a spell cast from the healer bar.

Removes:
  If the spell is a cleanse, enter one or more of:
  Curse,Disease,Poison,Magic,Bleed

Example:
  Spell: Cleanse Spirit
  Track Buff / HoT: [blank]
  Removes: Curse,Disease

The cleanse button will glow on a player row when that player has a Curse or Disease.

COMMANDS
/cha
  Show/hide the main frame.

/cha config
  Open configuration.

/cha buttons <1-14>
  Change how many spell buttons are visible.

/cha buttonsize <22-48>
  Change the Healium-style spell-bar height.

/cha spacing <0-12>
  Change spacing between spell buttons.

/cha resetbuttons
  Reset visible count, size and spacing without erasing configured spells.

/cha test
  Toggle sample UI test mode.

/cha reset
  Reset frame position and scale only.

/cha resetspells
  Clear all 14 configured spell slots.

/cha resetall
  Reset every addon setting.

/cha bleedadd <spellID>
  Mark a custom CoA harmful aura as a Bleed.

/cha bleedremove <spellID>
  Remove a custom Bleed classification.

/cha bleedlist
  List your saved custom Bleed spell IDs.

/cha debug target
/cha debug mouseover
  Print every harmful aura on that unit, including spell ID, API dispel type,
  and how CoA Heal Assist classified it.

/cha version
  Print installed version and creator credit.

COOLDOWNS VS BUFF TIMERS
The center number on a spell button is the spell's actual cooldown.
The small green number in the upper-right is the remaining tracked buff/HoT time on that player.
Global-cooldown sweeps are hidden by default so every spell does not look unavailable after each cast.
You can enable GCD sweeps in Config.

BLEEDS
WoW/Ascension does not necessarily expose "Bleed" as a normal dispel category. CoA Heal Assist:
1. Recognizes several common bleed-name patterns.
2. Recognizes a debuff if Ascension explicitly calls its type Bleed.
3. Lets you add exact custom spell IDs with /cha bleedadd.

If a CoA debuff is being shown as ? instead of B:
1. Mouse over or target the affected player.
2. Use /cha debug mouseover or /cha debug target.
3. Find the debuff's spellID.
4. Use /cha bleedadd SPELLID.

COMBAT RESTRICTION
WoW protects click-casting buttons during combat. CoA Heal Assist updates health, auras,
cooldowns and timers during combat, but roster changes and secure spell-button assignments
are deferred until combat ends. This is intentional and prevents protected-action errors.

VERSION NOTE
v0.2.0 adds adjustable 1-14 spell buttons and optional spellbook drag/drop. Conquest of Azeroth contains custom spells,
classes and encounters, so please report the exact Lua error and the spell/debuff ID if you
find an Ascension-specific behavior that needs to be added.

## Minimap icon and full settings

A CoA Heal Assist icon appears around the minimap by default.

- **Left-click** the minimap icon to open/close the full settings window.
- **Right-click** it to open Show / Hide Frames.
- **Drag** it around the minimap to move it.
- The settings window can hide the minimap icon or reset its position.

The settings UI includes healer-frame visibility/lock controls, test mode, minimap visibility, scale, visible button count, bar height, spacing, global-cooldown display, solo hiding, all 14 spell slots, custom bleed ID add/remove tools, debuff debug buttons, reset controls, and an explanation of every spell-slot field and debuff letter.

Optional commands:

```text
/cha minimap
/cha minimap show
/cha minimap hide
/cha minimap reset
```



DRAG SPELLS DIRECTLY ONTO THE HEALER BAR
------------------------------------------
Out of combat, open your spellbook and drag a learned spell directly onto any visible spell slot in CoA Heal Assist. Dropping it on Slot 4, for example, changes Slot 4 for every party/raid row and updates the Settings window too.

Empty spell slots use a plain dark background and do not run the cooldown widget, preventing the blue cooldown-finish bling seen on some Ascension client builds.


## v0.4.3 Visible HoT / Shield / Buff Icons
- Player rows now show up to 5 green helpful-aura icons with timers and stack counts.
- Configured Track Buff / HoT auras are prioritized first.
- Other timed helpful auras cast by you are also displayed.
- CoA healer-bar auto-learning now supports long timed custom buffs too, including 30-minute/hour-long buffs when the client does not report their caster.
- When Track Buff / HoT is blank, casting from the healer bar can auto-learn one clear new timed aura with a different name.
- Instant direct heals do not create a lasting buff icon unless the spell also applies a timed aura.


## v0.4.2 Visual Healing Alerts
- Buff/HoT spell buttons grey out while their tracked aura is still active on that player.
- Buttons remain clickable so you can refresh a buff early if desired.
- If a player has a Curse, Disease, Poison, Magic effect, or configured Bleed that a spell slot can remove, that specific cleanse button flashes RED.
- The red cleanse warning overrides the grey buff state so urgent dispels remain obvious.
- Cleanse matching uses each spell slot's `Removes` setting.


## v0.5.2 Healium-style UI + Auto Removes
- Compact Healium-inspired player rows.
- Rectangular spell bars show icon-only.
- Automatic Removes detection from spell descriptions/tooltips.
- Dragging a spell onto the healer bar or Settings tries to fill cleanse types immediately.
- Manual Removes override remains supported.

## v0.4.4 Long Buff Tracking
- 30-minute and hour-long buffs are supported by healer-bar auto-learning.
- Cast the buff from the addon bar; if it applies a differently named timed aura, the addon can learn that aura into Track Buff / HoT.
- Active long buffs show a green + icon and remaining time.
- The associated spell button stays grey while the buff is active.
- When the buff is removed or expires, the green icon disappears and the spell button returns to full color so you know to rebuff.



MY BUFFS ONLY (v0.5.4)
- The green helpful-aura strip is intentionally filtered to effects cast by YOU.
- Other healers' HoTs/shields, raid buffs, food buffs and unrelated character buffs stay hidden.
- The grey active-buff state also only reacts to your own tracked aura.
- If a custom CoA aura does not report its caster, CoA Heal Assist can still recognize it as yours when it appears/refreshes immediately after you cast that slot from the healer bar.
- There is no generic unknown-caster fallback anymore, preventing the target's whole buff bar from leaking into the healer row.

SHOW / HIDE FRAMES (v0.5.3)
- Open with the Frames button, right-click the minimap icon, or /cha frames.
- Toggle Party, Me, Pets, Friends, Tanks, Healers, DPS, and Raid Groups 1-8.
- Presets: Hide Raid, Groups 1-2 (10), Groups 1-5 (25), Groups 1-8 (40).
- Friends is a custom Healium-style list and only shows saved names while they are in your current party/raid.
- Friend commands: /cha friendadd [name], /cha friendremove [name], /cha friendlist, /cha friendclear.

## Performance

v0.6.0 replaces the old full-frame polling loop with event-driven updates:

- Health events update only the affected unit.
- Aura events rescan only the affected unit.
- Helpful auras are scanned once and reused for buff display/tracking.
- Cooldown events do not rescan buffs/debuffs.
- Countdown text uses cached timestamps.
- Red cleanse flashing uses one shared animator instead of one animation handler per spell button.
- A staggered fallback scans one row at a time for custom-client compatibility instead of rescanning the entire raid at once.

This is especially important in 25/40-player groups with many visible spell slots.

MANA / SPELL USABILITY
-----------------------
- Spell icons automatically darken/desaturate when you do not have enough mana to cast them.
- The state uses the game's IsUsableSpell result instead of estimating mana cost from tooltip text.
- Mana is checked once per spell slot and reused across all player rows for low CPU usage.
- As soon as you regain enough mana, the icon returns to its normal color.
- A bright red cleanse border can still identify the correct cure, while the dim icon shows that you cannot currently afford the cast.



INDEPENDENT RAID GROUP FRAMES
-----------------------------
In a raid, Group 1 through Group 8 are separate movable windows.
Drag a group by its header area while the addon is unlocked.
Use that group window's X to hide only that group; re-enable it from Frames.
Checking Tanks creates a separate Tanks / Main Tank frame. The addon checks both modern role APIs and the older MAINTANK raid assignment used by Wrath/Ascension clients.
The main Reset button restores the main frame plus all saved group/tank positions.

### Separate Pets Frame
When **Pets** is enabled in Frames, player pets are shown in their own movable **Pets** window. Pets are never mixed into the owner's Party or Raid Group frame. The Pets window can be moved or closed independently and its position is saved per character.



PROC / FREE-CAST MIRRORING
When the default Ascension/WoW action bar lights up a spell as proc-ready/free/instant, the matching CoA Heal Assist spell icon becomes a steady bright gold and displays PROC. The spell must exist on the normal action bar so the addon can safely mirror the client's own activation alert without querying risky custom action-slot APIs.



### v0.8.6 separate proc/charge mirror modes
Manual action-bar bindings can mirror proc state and charge counts independently. Use /cha barmode <slot> both|proc|charge or /cha barbind <slot> both|proc|charge.

### v0.8.6 mouse action-bar binding
If Ascension custom action buttons cannot be auto-detected, hover the matching normal action-bar spell and run `/cha barbind <Heal Assist slot>`. The addon caches that exact frame and saves a resolvable binding when possible. Use `/cha barunbind <slot>` to clear it. This adds no continuous full-screen scan.


### v0.8.7 custom helpful-aura icon fallback
- Green buff/HoT/shield timer icons now map back to the configured source spell slot by tracked aura name, spell ID, or spell name.
- Custom CoA buffs with nil/non-rendering UnitBuff textures prefer the exact spellbook/cached casting-spell icon instead of leaving a blank green box.
- Built on v0.8.6, preserving separate proc/charge mirror modes and performance-safe cached action-bar binding.


### v0.8.9 persistent helpful-aura source mapping
- Remembers aura -> Heal Assist spell-slot ownership for the whole login session.
- Reuses the exact source spell button icon when CoA drops caster/icon metadata on later aura refreshes.
- Builds the small helpful-aura strip after spell buttons establish tracked-aura ownership, improving mixed custom-aura icon reliability.

### v0.8.9 direct helpful-aura icon copy
- Helpful buff/HoT/shield icons now copy the texture directly from the matching Heal Assist spell button already rendering in the same row.
- Spell buttons refresh before the helpful-aura strip so custom CoA aura APIs cannot leave an empty timer box before the casting spell icon is available.
- Missing source-slot data is recovered from the row's tracked aura, and the spell icon's texture coordinates are copied too for custom textures/atlases.
